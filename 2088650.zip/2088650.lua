-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2088650)
addappid(2088651,0,"844feca898f9d9185cad90f3f30f8ecd7c4c4b4a90fe2b424c27cd91f577b877")
setManifestid(2088651,"6551251334584919285")