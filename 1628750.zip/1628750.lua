-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1628750)
addappid(1628751,0,"24da49e6396a1caee784f025f0bddd623b4a41967cf8fec76c60cbf3d482e90e")
setManifestid(1628751,"616411982110693493")
addappid(1628752,0,"e61f73d792f01ae70ad3da46ec0b3d05d5de000ec022b74e70beb1e1a6a9fa82")
setManifestid(1628752,"8467228779355687965")