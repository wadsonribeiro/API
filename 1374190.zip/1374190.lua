-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1374190)
addappid(1374191,0,"0aa08f8c24138d753312f628631cde165b7532ec6303221c19f8398e8c3174fd")
setManifestid(1374191,"929217093962588791")
addappid(1374192,0,"42dfba8620509887648fce4bee5ac0254cef713d7b153293eeb4a1e2c51f1062")
setManifestid(1374192,"565749722208739468")