-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1288490)
addappid(1288491,0,"70bffd1e69bc22fa2799082f19aa9842897134e77cb4c638a7d58f9c85d229f5")
setManifestid(1288491,"3011907684275549449")
addappid(1288492,0,"d954c2f54eecf2b70510a591ff7febf5624d187a16175f7b62ba67a92c2a3996")
setManifestid(1288492,"3661830148076176198")