-- 17300's Lua and Manifest Created by Morrenus
-- Crysis
-- Created: September 29, 2025 at 05:51:49 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 12
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(17300) -- Crysis
-- MAIN APP DEPOTS
addappid(17301, 1, "e9af152ec4845c4b833f38a560a07fa0f39338e41e8e490f9f42714a32563d17") -- Crysis content
setManifestid(17301, "3196227748258693724", 6903180764)
addappid(17302, 1, "c65dbd17a66a8f791cae061331cc18b549ec7f04dd227fa02759710db0604813") -- Crysis English
setManifestid(17302, "393671967566404270", 194894743)
addappid(17303, 1, "e7a91196d977a8a3d264ccbf8c2e84e3c2b6032140ef07033efd491cc84a41ef") -- Crysis French
setManifestid(17303, "6094376140962052438", 179563699)
addappid(17304, 1, "fabb763e88dfadfcb50664671210976f877bcbb8ba16c3c371f4c9663fc500d9") -- Crysis German
setManifestid(17304, "4997311157219043932", 163951791)
addappid(17305, 1, "447f8f976b2369725d9521573b216061fb9b407ccb52aa23dc43aa1f60460edb") -- Crysis Italian
setManifestid(17305, "7852099966639642312", 181662557)
addappid(17306, 1, "92579b4ddbd123fbc1b9d3496b487829313d81b89c307b978901d3097c92f31b") -- Crysis Polish
setManifestid(17306, "8621728532225668307", 176625649)
addappid(17307, 1, "2190561b01781fc8a971efbaaf859711f280d53823c14b9f5024e08ee248f2df") -- Crysis Russian
setManifestid(17307, "5182295902409564509", 186768784)
addappid(17308, 1, "3342815b58d71a032b84af3dc23f2fff595fd3ee32ea59cdfd9a0fa54a167c72") -- Crysis Spanish
setManifestid(17308, "3299180412192283172", 181539200)
addappid(17309, 1, "21659859ce045cd03ca30d2b53410bbec90b3e5b793dba549190f504d87c9945") -- Crysis Czech
setManifestid(17309, "3578029986700264401", 182054549)
addappid(17381, 1, "26b79374987692eb49a7e6291ffac5c44f41d941ae57d8baef8303eceed223c3") -- Crysis Hungarian
setManifestid(17381, "6154308834345943448", 175992184)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)