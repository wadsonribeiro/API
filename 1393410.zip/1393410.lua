-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1393410)
addappid(1393411,0,"0d077d2e75e5d02614893862de4917255e66ce933eeb55b4ed2b8afbd946fb53")
setManifestid(1393411,"6114609519500065396")
addappid(1407020,0,"84c55c4b22fb43893e3170d737645b03abf17ff6de85d9044b1435f02f54235c")
setManifestid(1407020,"5460809327046144891")
addappid(1424920,0,"06aeb88bfcd05e85df747149507782d5293c9fdf035265a58a16a38628c0c0d5")
setManifestid(1424920,"3243461963985876825")