-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2487440)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2487448)
addappid(2487441)
addappid(2487447,0,"13ced551c5994f9d6b8ead260d5c498f0cbc9e80ca4e128d30ad1cfc52c91145")