-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(721430)
addtoken(721430,2057193683731982176)
addappid(721431,0,"43d818eb773e0225d5a52637325828e345bc8d8bc53caf7f662fae135c0203b8")
setManifestid(721431,"8332113347065252225")
addappid(721432,0,"2e63224bc4cc2ef7a896696725033ddb9df27eb5f22f30247fee58c490d9f31f")
setManifestid(721432,"7088011230532555343")
addappid(721433,0,"a08f929ecfb50c7ca51b4f7742a22b2c4263d8cdcafe2bf8a6c9c7a9fa911bca")
setManifestid(721433,"7150307781518812147")