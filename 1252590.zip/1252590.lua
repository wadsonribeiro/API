-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1252590)
addappid(1252591,0,"1353c71c573fb2e381239eab99baf5a21826d92e50cae9ab71a602fa72c3528a")
setManifestid(1252591,"6695281525627193455")
addappid(1252592,0,"cde4233d65113189a3738109fca60a353084ae4cb1c0af10a6153ba6571e6155")
setManifestid(1252592,"7886800640057570944")