-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(292230)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(292231,0,"6ed8eafa0bc119fb0bc19cc4fcda59c1fc5b9d057d7d0a882d6baeaf985b785e")
setManifestid(292231,"4791919313428483550")
addappid(372710)
addappid(437560)