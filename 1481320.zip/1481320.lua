-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1481320)
addappid(1481321,0,"b9cfff11870a6f997369c4d58d6d654723fe63ec2271bf8e90db3059bf9de5a2")
setManifestid(1481321,"3207685550948094524")
addappid(1481322,0,"86599c33dd16c77f321f7259fb15275c7cc5681a61abe10daaef85e924bb0f6a")
setManifestid(1481322,"5587574784280185466")