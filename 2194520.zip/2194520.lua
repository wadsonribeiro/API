-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2194520)
addappid(2194521,0,"37b0e0ec7e17d59a6134c8537144e8a03d3b659627a6f8cb219f6318c5daef66")
setManifestid(2194521,"6400901825798180743")
addappid(2194523,0,"3ca163dc7ae2e8b921eaf3da66b9d60d253a7e031689202dbb830ff20511c4c2")
setManifestid(2194523,"8721140348870055028")