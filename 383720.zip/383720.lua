-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(383720)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(383721,0,"37babd8de8e254519e648044ad4d2641c78899198d5ca3ce9c297f2042975571")
setManifestid(383721,"7305444865273661532")
addappid(383722,0,"922a1393ecb20d4dab8affd9859f3e710f161432a3d5a44ed80ae1bbc80a9bad")
setManifestid(383722,"1910871012084306166")
addappid(383723,0,"fd1c81f4d6eaced99b01f02a67e11469872c7f6420fa24492cd6404c1272eb99")
setManifestid(383723,"1152035454949104710")
addappid(383724,0,"d2b88eb2928eb34bd5e42f32ccb4a1410b542e05a541658871a1a738717569e8")
setManifestid(383724,"2026695135103582732")