-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1456590)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1456591,0,"1a0d009276884e19d0a9d4d576536fa6ad1d5442becae6a876b92805077f748d")
setManifestid(1456591,"4454508261813465980")