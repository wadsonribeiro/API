-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(644390)
addappid(644391,0,"8e4fadb80d1b0503ea2721e349689079be6f65af25c5ae462e9e8e4c9b7c8479")
setManifestid(644391,"6957705371746415713")
addappid(644392)