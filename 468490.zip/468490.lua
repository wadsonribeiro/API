-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(468490)
addappid(468491,0,"dae272790bf620aa3c147b34e003d242c58f07b029fb65c24b86d0f81ecb8cc1")
setManifestid(468491,"8783354820909909933")
addappid(468492,0,"9d0aee0913e3d9ce72615850790efa14b23e8ffd1224025a2a6d499fcfa22043")
setManifestid(468492,"3024819958811368624")
addappid(468493,0,"7639f3f19711946af1ff39c105de8a43a56c26d3900f6178292cb731cd9eaa0c")
setManifestid(468493,"2506923869532977636")
addappid(468494,0,"bc63186b281071c88442241c9466c40d1660ede3b52ad253b7c427626a5a1a3e")
setManifestid(468494,"2317129726250668104")