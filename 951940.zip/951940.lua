-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(951940)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(951941,0,"33bdb8a3fcd7b0d4fc80cb1ba01877f151dbc3c3cf19aa1f511587c228ac0146")
setManifestid(951941,"6796679256920953119")
addappid(951942,0,"cf3256867db3d767a989dc73a9462668909647126a13a3a6f5ba23d74a1e7783")
setManifestid(951942,"5811982101747849650")
addappid(951943,0,"5676805348bd0a40af724716a104c684f4421503891f82599ffafd4e3b2a1beb")
setManifestid(951943,"8369295911586687272")