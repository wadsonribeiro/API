-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1940670)
addappid(1940671,0,"4af5d4fb4f6764e1b0e306e35ab3608a152d429c7448440c443b9a9af959454f")
setManifestid(1940671,"6827901922023190412")
addappid(1940672,0,"fb12967f7b7ec5447c0cb961522e7b2e4e13fb5eb3f89459b8228c90d9274c5d")
setManifestid(1940672,"7013679204499855069")