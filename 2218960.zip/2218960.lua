-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2218960)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(2218961,0,"fc1e65089da2efdf8a8e42c0df5304ef0c9fad78dc5f91fb2e1e63f733f2f5e9")
setManifestid(2218961,"5477930154146304190")
addappid(2218962,0,"9888ad71293bc8d375f7a3327c9d73cb668628b745cae073f80e88fa1cc4f673")
setManifestid(2218962,"162130054495473869")