
addappid(3472040) -- NBA 2K26
addappid(3472041, 1, "98720ddedf5fb5a37faf70ca90602a9949e727a7f7b6b9171ecc2764ee2d3b21") -- Depot 3472041
setManifestid(3472041, "2205017740578223873", 74470607153)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3825290)
addappid(3472042, 1, "34db1ecbd759eab0b3e63e7304bc8fe901b1ca351a3d453affb865d97c5e62be") -- High Resolution Textures - Depot 3472042
setManifestid(3472042, "9074774104163492402", 27077715800)
addappid(3657590) -- NBA 2K26 Pro Pass Season 1
addappid(3657600) -- NBA 2K26 Hall of Fame Pass Season 1
addappid(3657610) -- NBA 2K26 MyCAREER Bonus Offer Season 1
addappid(3657620) -- NBA 2K26 MyTEAM Bonus Offer Season 1