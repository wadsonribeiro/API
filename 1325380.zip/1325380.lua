-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1325380)
addappid(1325381,0,"44d6a4df82303256529e45e93727e316f755f9c9cb86a6432e8838734ea4796c")
setManifestid(1325381,"3153129761376692194")
addappid(1429560,0,"1998dce64de3e82ce8e4f7b528b01c05d08026aeae93918baef3783d2b8209be")
setManifestid(1429560,"4464970119162841616")