-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(956700)
addappid(956700,0,"fba263a6935b15c4a7305a039e333f3a451d2457cf8a45ca150142bd0c4a17a9")
setManifestid(956700,"4819415246826131624")