-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2871760)
addappid(2871761,0,"3304f967022dedf1a991c25ebb6e0c919be8935b942c9dedfd4fea69fe167b08")
setManifestid(2871761,"8894085829451870055")
addappid(2871762,0,"550e896673f8acc7823aed0a3f7debe7ee22a93e5070e38d4503ced08d452d37")
setManifestid(2871762,"6376627940607455004")