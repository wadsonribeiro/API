-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(985050)
addappid(977051,0,"b08c62829c2cf6ec114e9ee8be942d8a69ebf20449f655481ddeec142f46e1db")
setManifestid(977051,"949745137295664055")
addappid(985051,0,"1b5c4a9ed06c4490242e6e01dc8dd35865a1f92d5b6cd107d8506ef0de45e3fd")
setManifestid(985051,"1948420736167760978")
addappid(985052,0,"6ccb069eab2a5ea9b0eaa732990a94548317725052567785f6e707da46537d92")
setManifestid(985052,"8964205574984978646")