-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2326580)
addappid(2326581,0,"ef53199e5f90be69a1e600e720e03dfa889ca33d36da567b32bdce74d91bd92d")
setManifestid(2326581,"6543368865403569575")
addappid(2326582,0,"e40b2d5fa707dba9114813c0eeb2a751688a9a5f3a0714c7df19e9bee2d5195e")
setManifestid(2326582,"1364117933477979089")