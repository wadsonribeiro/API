-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1887020)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1887021,0,"aed35018bec8dfba32cbcfbd28652714ae1771399e50c048f0cbb15aaee7119f")
setManifestid(1887021,"7001716283275344915")