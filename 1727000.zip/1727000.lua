-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1727000)
addappid(1727001,0,"bb6f2e0c0915428428f42d536bb7bde4b65fe8b04a826cfcc525ad2892ab3173")
setManifestid(1727001,"1434794410623781223")