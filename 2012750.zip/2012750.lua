-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2012750)
addappid(2012751,0,"a024a32350f19ada0411f8cbad53fa2848fe34ffc14a413a2cd8b3f6558379bc")
setManifestid(2012751,"4354907668296604751")
addappid(2012752,0,"f4763ce612bc41b1029aa950ed42e281fdee0a015e26bedc149497f94bfe808b")
setManifestid(2012752,"8496051620416905781")