-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2588110)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2588111,0,"0e3d101e35028e1d4b680680afeb63d7afe9578ca10a1a066173c711c10d98ac")
setManifestid(2588111,"7659582383598535606")