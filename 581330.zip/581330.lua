-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(581330)
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
setManifestid(1004,"7747775778018907449")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
setManifestid(1005,"2135359612286175146")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
setManifestid(1006,"7138471031118904166")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(581332,0,"0145198c9c38355860917f940f108b602768ac8bebc6c4565df37f2e394b97a7")
setManifestid(581332,"6093198283918183405")
addappid(581333,0,"6ea472d3ec6f661f0d7fa66a7411f12c888c8e207d1c277d8dc3c619cbf26651")
setManifestid(581333,"1237745673074878280")