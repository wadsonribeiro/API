-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2245460)
addappid(2245461,0,"8cc5f6998c3c8b8cf49c40e821733aaae780c5b9da65107285aa5968901fbec0")
setManifestid(2245461,"1532884562829855155")