-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2122141)
addappid(2122141,0,"0b4fe1b4cc92dd720a2bf2f38a1570be40dbcde8c3b233fc26db19dfd021e7dc")
setManifestid(2122141,"3343870358555079755")