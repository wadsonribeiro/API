-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1727830)
addappid(1727831,0,"0b771503378f1afc7db06c9e6faf57f7ac4f5757fa9f9b8defda91476066f7b7")
setManifestid(1727831,"5322970367638882517")
addappid(1727832,0,"19fd83e285a8406551e3e46475f27bde2eca431205c6079a0b3b80edfaed31f2")
setManifestid(1727832,"1073677983052367733")