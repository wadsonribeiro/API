-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1419750)
addappid(1419751,0,"17bce1daac2e0de80a00d44db1a9c33542ab0b34448ef2367a3cd632ea27ef19")
setManifestid(1419751,"1436143976600699513")
addappid(1419752,0,"a5ee1eeab7932cf159bcc41043f213713f5114ce61bb8e735e643780697cbd23")
setManifestid(1419752,"4807412650920925718")
addappid(1419754,0,"7168e9d710eeebbb6d259b2ecc75f2fa2fff60078f5ac6fc629f03294b4042cb")
setManifestid(1419754,"4649404164248971297")
addappid(1419753,0,"c31023e26380ecd8339fa6716994efa8c37ea7abc6ba22f0c743f3a2ec2ff906")
setManifestid(1419753,"3413468012808569359")