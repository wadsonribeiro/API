-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(295690)
addappid(295691,0,"ba24ff7409b9eef47fadde799c70b332a0a57a0e7cb1c4417c2479ff2b0da214")
setManifestid(295691,"7713145970476002830")
addappid(295692,0,"9fae6363e26fd3af8745680682293b2bf54c5af89c4d728f8b62f0079f530310")
setManifestid(295692,"7203199097664365236")
addappid(295693,0,"7690f933d94a93084958bf93471d4e27fb0a1b6c309b834edd8d5a77677d7524")
setManifestid(295693,"5703507564465980154")
addappid(343290)
addappid(459070)