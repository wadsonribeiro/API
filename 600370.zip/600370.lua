-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(600370)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(600371,0,"80c597b40936f62da545e75c91ecb46f467a1294bc1bd9f6b80f8f9830382c04")
setManifestid(600371,"4260239379264731357")
addappid(600372,0,"634e981778a1a4406a0ae9fdee820d2b867a929ed396dc22c89cbebc1795bc6d")
setManifestid(600372,"3967259591306420119")
addappid(626180)
addappid(600373,0,"3798fa421702d52ffe6e3cb5cd72a88f40adda1dc56e2b852dfff03372c1b30a")
setManifestid(600373,"3638276472011123836")