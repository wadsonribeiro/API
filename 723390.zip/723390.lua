-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(723390)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(723391,0,"29372aa10cf85ded05c12283142dbc490e8c54a934a784e0cf2240a65b4c59ed")
setManifestid(723391,"4943933081593682331")
addappid(723392,0,"b1ffa7e05f317c27cd2ad391edcdeab0a04e00f66dd4060a89c67dc0ba96baae")
setManifestid(723392,"5521670714336968061")