-- drainsim
addappid(2963800) -- DrainSim
addappid(2963801, 1, "378db61e0fba6945aa38162f21ab98cd80c6f68a85a64b0bdeffc76895b8fdbb") -- Depot 2963801
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
