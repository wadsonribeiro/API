-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(910450)
addappid(910451,0,"f0aa71d4fab32aa05b58ec747b30e22ccbf05a55775b87ff3aecbc412fe96f34")
setManifestid(910451,"3812816115757452642")
addappid(910452,0,"ba41a3345f2b302ccd909ed015966389f40a17b1bdf26352479b89d4ce7171d2")
setManifestid(910452,"5017321908226089441")