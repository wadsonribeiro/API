-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(288120)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(288121,0,"005167c8351e3f0fd276ff01b7e1402a674fd031152a911b75ea8a2123d2fd4b")
setManifestid(288121,"8031368467569961377")
addappid(306280,0,"92b508561cd6c0130758b38b4b6a627c4bff2f63b65b716f258c6f37202b4b74")
setManifestid(306280,"2775185409333673024")