-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(777640)
addappid(777641,0,"531ebf510e48c792346e4dbed891bf3b1fa23421a58b133474ebebc67f6b852a")
setManifestid(777641,"1880108102659661779")
addappid(777642,0,"7d36dc8a61456fdabc404881e13dea755577e14fbd8ff5caacc5cbb415ccc536")
setManifestid(777642,"8180855661052754314")