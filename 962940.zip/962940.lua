-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(962940)
addtoken(962940,18328894283685309888)
addappid(962941,0,"cbd924aa4c0da678b9d9d5e4871a9cd9dc42a1e456292dcf01ee934b02c2211b")
setManifestid(962941,"396337949376182953")
addappid(1009170)