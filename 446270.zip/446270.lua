-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(446270)
addappid(446271,0,"c5b3943e0521d7911373705a855a9c2682811efe72483314957293725406c01e")
setManifestid(446271,"5713464819940696986")
addappid(446272,0,"cca0edda3294d4a12a98c4812ad4e6ab52a658f9eec96696e5154b4d1cb0a2a8")
setManifestid(446272,"7465953279877304836")
addappid(713270,0,"7af504ba89b8ac23ac7f2ca4f9a2e1bab39f3b8c733ca7ca4c660111aeb75f8f")
setManifestid(713270,"6506322516833349469")