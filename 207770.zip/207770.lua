-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(207770)
addappid(207771,0,"4cc9b2c0ebc119f92777de9c82684c3b1ed0eb15e1425d946d6a7e4b1352ba60")
setManifestid(207771,"961575330175200631")
addappid(207772,0,"df27e04cead005474ad5ada3f6e5a5b1e56b4769b158138229add2682ce6951f")
setManifestid(207772,"4387780272520586465")