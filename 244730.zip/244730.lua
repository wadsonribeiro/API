-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(244730)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(244731,0,"b3a9b258894fe64f60a6075ff812af64daf0182c1dbb490adff8dc19e3245d7c")
setManifestid(244731,"5700648463406271194")