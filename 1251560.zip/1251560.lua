-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1251560)
addappid(1251561,0,"026a7b14bf38c74d41932c57a37477595cbbd01be83fedf78cce5aee69ecc6d1")
setManifestid(1251561,"6048457874058106498")
addappid(1251562)