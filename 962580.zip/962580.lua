-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(962580)
addappid(962581,0,"ecf7c33add3af3999496a2d4d329be64b95a454bf226f5234367c1512353ab67")
setManifestid(962581,"8883732309860419787")