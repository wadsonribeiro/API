-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2212700)
addappid(2212701,0,"b28765ed195c23a759eff15fb1d97b87c3116c43a0535d651cf6da3ef47c6697")
setManifestid(2212701,"6874772122054674902")
addappid(2212702,0,"032e4fd4778798467db8b6f3a72a1e597f77f2469605f39203e83b19aa7c8bbe")
setManifestid(2212702,"6662590627903475796")
addappid(2212703,0,"0e7b3a6c255277f84ccf02680044aa4476e5cf12e3a7844c346ad80dd830f63d")
setManifestid(2212703,"7029036661325606422")