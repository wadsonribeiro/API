-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2569480)
addappid(2569481,0,"b4555e4d8160f4120241d396c2fe1f3a278f6e939aa2976d26728821fc01be18")
setManifestid(2569481,"2103646130042696157")