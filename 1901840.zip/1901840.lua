-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1901840)
addappid(1901840,0,"bb563f0df0d9ff0b94bf5d2b300b96e66fd061540809bdc4a71b8a2f0adeb8e9")
setManifestid(1901840,"6647128919942344330")
addappid(1901841,0,"a10c157c1f142002a7af0d0249e1e5c9047e299503f199de5d6e4f6d6521b68b")
setManifestid(1901841,"6556337387026016756")