-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1446360)
addappid(1446362,0,"991d43f2818fb53410fdbf764d12b91b6b30f3dab03b7a215bfcce6421ca47d8")
setManifestid(1446362,"5967949189402861198")
addappid(1446361,0,"1691b845c80656d5c7af025c7d42c84d21bfd95cb3879385c97cda3b2af1cd4a")
setManifestid(1446361,"9103577191245238114")