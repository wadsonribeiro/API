-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(232970)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229031)
setManifestid(229031,"7746630274301172884")
addappid(232971,0,"a96712d03eeb9b91da31834884884c96c9602822e77f9c9ab2e780fcdbbf4415")
setManifestid(232971,"2784720250952548614")