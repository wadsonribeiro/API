-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2255480)
addappid(2255481,0,"fb056afd3833c38120e10e986328e0a2d18bbf8cdd54868fff07cef3b101e095")
setManifestid(2255481,"6294739389084177879")