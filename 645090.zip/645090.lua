-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(645090)
addappid(645091,0,"308e972820c9107d4cdf885ea44d863d7f105bea081d0df1e3f04166f3470e7f")
setManifestid(645091,"4425053266188922386")
addappid(683060,0,"161023177f8ef909dfef1e8c8447c9cb5e8de4627cd75e43311808db75c2a800")
setManifestid(683060,"220175361362944493")