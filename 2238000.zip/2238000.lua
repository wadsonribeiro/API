-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2238000)
addtoken(2238000,3732840838471537733)
addappid(2238001,0,"b041dcc49866b2da10cc2dc59764b9af203f8d7be6948c2f4b7a4fc3ae1bb8ba")
setManifestid(2238001,"4412427978090041009")