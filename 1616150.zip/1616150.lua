-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1616150)
addappid(1616151,0,"096702506349ad2265d252c7ddbeb33d791c99ed5fb697b5823a2f1e9c7e7457")
setManifestid(1616151,"1390993379818771667")
addappid(1616152,0,"d5d5c19fbfe3aead4cd7b1ea972fb6942f730451dd1f828cbe93b534eaaa8b36")
setManifestid(1616152,"515113033811398142")