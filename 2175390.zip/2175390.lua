-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2175390)
addappid(2175391,0,"ce7be88bfb664b41e4ce5b5a453ad7804fc7b8591758ed202b44c5e0f67cf1d6")
setManifestid(2175391,"3878588241274240295")
addappid(2206550,0,"4f7788fe7193fe042424fd0750244c5a5d06fc4eb1d529e5bb111ff12c7b266f")
setManifestid(2206550,"768054156389888032")
addappid(2175393)
addappid(2175395,0,"b6ab3ea21a2084e689eb973e5e220169d97332fca1dee4519fea993fefec48c4")
setManifestid(2175395,"7899513258379412057")
addappid(2175392)