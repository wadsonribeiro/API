-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(795580)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(795581,0,"8c08fa2e4a405250faa70b183d83a22170e6b42f30dc1c0a5d8a83dc76a23963")
setManifestid(795581,"2543006830550564250")