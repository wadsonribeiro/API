-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2477950)
addappid(2477951)
addappid(2477952)
addappid(2477953,0,"29a6b2e8b0e85d685a79a8f8a6d4c12122a964cd7ced11d742f8b45d91f1850f")
setManifestid(2477953,"6640697569107887506")
addappid(2477954)