-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1308380)
addappid(1308381,0,"65995160f08bf18570e286e97af51a585f24cb48ec50c47962e50e0ca4551d12")
setManifestid(1308381,"7021499985353978375")
addappid(1462660)