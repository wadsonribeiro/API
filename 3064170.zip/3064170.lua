-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3064170)
addappid(3064171,0,"f25ae3f4513737f66e1107a96bf9cc689a4e1ec85f8e8ca69b0ee184ebb39301")
setManifestid(3064171,"1595085330837568125")
addappid(3064172,0,"47bc30bdb9c5c13974129b9fbcf920edc0b1c3c984b5d3199cce95c29358f052")
setManifestid(3064172,"8147396401269652530")