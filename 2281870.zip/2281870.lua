-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2281870)
addappid(2281871)
addappid(2281872,0,"8b2fc382c02ead378fb896768e380a5dba74a2e791d4e38099838181194b8b67")
setManifestid(2281872,"1735859027409262983")
addappid(2281873)