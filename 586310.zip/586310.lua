-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(586310)
addappid(586311,0,"926cb83a8a65017e3c2d7604d098dc9b044dc19902a4c78efbce31e85b89c656")
setManifestid(586311,"2934217942280586126")
addappid(586312,0,"2438ef29d53536d45174a4a3773996b748dff014ef9a9077dab17465aec0070b")
setManifestid(586312,"8896444863602831774")