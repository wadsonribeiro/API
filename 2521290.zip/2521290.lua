-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2521290)
addappid(2521291,0,"556fb399ac5ea71a4a0f430734ee76c4ef0290263705d576db5fe0ee614cf8df")
setManifestid(2521291,"334912715597142313")
addappid(2521292,0,"d99796b7d9c4815e1c29d515f3548c3416de9556ee4e95257829083e5ef9968d")
setManifestid(2521292,"5227146609885047359")