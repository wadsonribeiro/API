addappid(2078230)
addappid(2078232,0,"a7eb0d5dab2bf1ac43efa6c5b2174fad39792483606b806c42be4dfccdbddaaa")
--setManifestid(2078232,"7576312893231938145")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]