-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(461720)
addtoken(461720,9549005567198269799)
addappid(461721,0,"7a31fbb9aa0189e2b9e36300d5f9c2d2821ecfa367920dc8af9f4e6ae213cd85")
setManifestid(461721,"4345645443250763173")
addappid(461722,0,"0508a30911a1ae4d31c835beb5d1bea117b32589f403c808fcd7bbed6a94efe4")
setManifestid(461722,"5726483128762827332")
addappid(461723,0,"842eb21dd8a143aa81ae88deab63b977a8f1821b0ae35458d357371fc6ff7529")
setManifestid(461723,"7560303616436819749")
addappid(461724,0,"fab5f7a0a0e506531757c56515ff061ba6c572831a30f361b3d88cfbed7d971e")
setManifestid(461724,"403769098020629284")
addappid(627700)