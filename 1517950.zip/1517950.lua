-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1517950)
addappid(1517951,0,"01cb3963c92215d2cb0d611fe73b703c08aa41ec8bcf499501e8b0b57e07a5ef")
setManifestid(1517951,"6875554534189703159")
addappid(1517952,0,"521c17a4bb02e546cd7ac6c0753ada907696e5af7ad9f9381ce4be60cfe61542")
setManifestid(1517952,"1706998524675233107")