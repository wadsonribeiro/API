-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3141440)
addappid(3141441,0,"f603a5a560df7af915bcbc892a39d3d4e4b7e0c6fab7e66d71ae58ac47beff90")
setManifestid(3141441,"6514541124494551888")