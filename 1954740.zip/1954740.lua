-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1954740)
addappid(1954741,0,"618521b0ec87aefe82fed4ed08f48f20189cdec1a7a0fb90b27c31888900d6bd")
setManifestid(1954741,"1026614026245899337")
addappid(1954742,0,"41cbc61953100dd24daba5d854a8efd72e00192c05ca0f297214ea9323230660")
setManifestid(1954742,"2398967629897795161")