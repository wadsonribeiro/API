
addappid(10680) -- Aliens vs. Predator
addappid(10681, 1, "e5f10e7978f6fa4e0a94de2f6bc517a3b83341b9d03be28b9ffcec182065bf86") -- Aliens vs Predator Public Core
--setManifestid(10681, "6345698269675206610", 15764330088)
addappid(34241, 1, "72bfa9f9508343f9810b654d17ccb493fd09011f38dd5ad3be02237c4a024bbb") -- Aliens vs Predator Executables
--setManifestid(34241, "3656293803170223496", 15287624)
addappid(10682, 1, "c535dbdc5d6dce3d9c88fba98ba1402cea72b32c23119ab33901ddf461783160") -- Aliens vs Predator English
--setManifestid(10682, "3585953053040061739", 381736344)
addappid(10683, 1, "143eaf0653b5d30796bfc2c9850fa2671172015cac11a363364257d795aa5c09") -- Aliens vs Predator French
--setManifestid(10683, "5412109705528272274", 381376750)
addappid(10684, 1, "bb0af99c48e29e60891211ae517d09e1e716013f07060dc9bfc51d22ab4fecbe") -- Aliens vs Predator Italian
--setManifestid(10684, "5592918781774967958", 374325666)
addappid(10685, 1, "c59dab85a643152546281817710447bb7cf04f0fc53ea9852b3aa29693dfe298") -- Aliens vs Predator German
--setManifestid(10685, "6140910970965935814", 381834822)
addappid(10686, 1, "2dc7ee5c7256cfaded480710147226a5f0e5b14728b8a185e35dab5c16dc0af3") -- Aliens vs Predator Spanish
--setManifestid(10686, "6748631130429380495", 368258234)
addappid(10687, 1, "f1874b33bb84e13a1736df5f9116c87f9a43f9e1d7bf7cf4698a351f3296174f") -- Aliens vs Predator Czech
--setManifestid(10687, "7083961076190895571", 381691350)
addappid(10688, 1, "328f68b56dd43362dc669b187889176fc843a1388d9ec69bb5d9569c3fdefd7e") -- Aliens vs Predator Polish
--setManifestid(10688, "4199302285919017037", 381741348)
addappid(10689, 1, "d31668e2e001984b488dae06ff7dd69f35c28692ca21feb4c7054b8d6edb69d3") -- Aliens vs Predator Russian
--setManifestid(10689, "7045409412578250241", 389576252)
addappid(10695)
addappid(10695, 1, "1256afb7b46e18e39a1045641f5e1ccd468d5be8d0bc43930ac80e654d3a40d4") -- Aliens vs Predator Swarm Map Pack - Aliens vs Predator Swarm Map Pack
--setManifestid(10695, "4882599868788274168", 1087609104)
addappid(10697)
addappid(10697, 1, "a8a65c4cd51acd106bcdb99a1a7209e320c016385bb4afdb442833da1d2395aa") -- Aliens vs Predator Bug Hunt Pack - Aliens vs Predator: Bug Hunt Pack
--setManifestid(10697, "5625098353603502981", 1109308349)
addappid(10696) -- Aliens vs Predator Exclusive Multiplayer Skins