-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(972400)
addappid(972400,0,"97aafe464b25f2b17cfb78098da016ae034000c5ef1b1a716ced22f2eb452036")
setManifestid(972400,"5594400012357397901")
addappid(972401,0,"ff208509f4e679bc09c6f36560db74b18888dd3320ae4c8d444d903cdbe10645")
setManifestid(972401,"5921080331427006753")