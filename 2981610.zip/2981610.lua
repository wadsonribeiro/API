-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2981610)
addappid(228989)
setManifestid(228989,"1332597174812030948")
addappid(2981611,0,"281693ff76cfae4dc13350a42baa22e576e43a3e849516cab38e216a585f2512")
setManifestid(2981611,"2249719802694282929")