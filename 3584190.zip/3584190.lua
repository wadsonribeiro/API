-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3584190)
addappid(3584191,0,"6170b384d1c20210417b87519a3a287d734640a60e194e2f980a9909b25d7eb8")
setManifestid(3584191,"7913902775318842593")