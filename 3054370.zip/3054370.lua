-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3054370)
addappid(3054371)
addappid(3054372,0,"7c01108b691d5d17e9fad58cf32a2bbe02e21e1f8d00642b5fedaf60dd3e95c4")
setManifestid(3054372,"3694615570183065863")