-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2181430)
addtoken(2181430,5309997566858435121)
addappid(2181431,0,"eeb073c90cf5e5522e4544993c080417011689f8444a4d1fffb3b7bada38e221")
setManifestid(2181431,"1518120818829168216")