-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(930010)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(930011,0,"e63fbba431a493768cf7212700f9ddebf5d43e05a9ca539bead687edbcf858c8")
setManifestid(930011,"1442570977271986355")