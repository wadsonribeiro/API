-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1973180)
addappid(1973181,0,"481a292fc47c131de99920cfe3d5d935e3d65cd845be48637ad68e19215638d0")
setManifestid(1973181,"2857408672142005673")