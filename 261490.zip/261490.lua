-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(261490)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(261493,0,"6e7dcbf878a9bbf4cd5a2f6a6cb783533b3b1554ab66812102f71729ac77a296")
setManifestid(261493,"1563201318503053709")
addappid(261494,0,"98d1e703976e63bb16bf52c72eaafc316ebe9184272856e33d8ab3cc7cd89ee4")
setManifestid(261494,"3633545108541900796")