-- 2957720's Lua and Manifest Created by Morrenus
-- Neon Inferno
-- Created: December 18, 2025 at 18:24:48 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2957720) -- Neon Inferno
-- MAIN APP DEPOTS
addappid(2957721, 1, "debc6bc38ba76f08ab82214d2a3a6487d58eb81b789d974029972bebc8341dcb") -- Depot 2957721
--setManifestid(2957721, "7299127778061131230", 3717601902)