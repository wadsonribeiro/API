-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1125060)
addtoken(1125060,15021389044876539844)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1125061,0,"c7da4dc8cc6d645b8054dc496dea2fb3092ed9361fa06ec2951c7921e1fce3aa")
setManifestid(1125061,"3920691669164548847")