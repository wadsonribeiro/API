-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1818300)
addappid(1818300,0,"5ce43f5f200bb97ebf8c805eb72cf2335a1a263dc65d4260e97e5d67ee6cc625")
setManifestid(1818300,"4534223742513087068")