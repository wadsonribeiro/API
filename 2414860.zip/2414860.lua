-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2414860)
addappid(2414861,0,"db7d28ad196180b35c4ab6df6a07af22e5e288c4aef124da4fb745a4793fb2f9")
setManifestid(2414861,"5677819848606065464")