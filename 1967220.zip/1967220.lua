-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1967220)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1967221,0,"c186d27d3af23cca8b3ef364c0392f9f9d5d161c465bb4f0e499cebd8c77b71f")
setManifestid(1967221,"5500817252796718771")
addappid(1967222,0,"ccb9e4ab039d2e242a089a3cfeff880e49a390aa82bda5a3ef874bc8c7e38d8c")
setManifestid(1967222,"1498655274713719449")
addappid(1967223,0,"69ae711ad4ecc0dc3778157baf6a50154389487f5c9af17efb4535e56111e423")
setManifestid(1967223,"1039238755414961972")
addappid(1967224)
addappid(1967225)