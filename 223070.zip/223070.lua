-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(223070)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(223071,0,"19986e900e311a4ca77e10ca726ad505327a44d92255ea0592af522ce1ca4482")
setManifestid(223071,"2868911022388338495")
addappid(200711)
setManifestid(200711,"8119246652698192918")