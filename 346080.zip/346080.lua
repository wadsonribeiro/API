-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(346080)
addappid(346081,0,"ac6cfe37b52a47e5ae9cf8a9a072fa441df927bc24c2eb247fc478d4b5159448")
setManifestid(346081,"3880281553419983176")
addappid(346082,0,"67d0de828481504b58e98a3bc6f7b11ca9c3f60a9941cb66e0588bd0de0c6b6b")
setManifestid(346082,"8134485608656822057")
addappid(346083,0,"607a1bf8adbded2617a5a63e076ae668a244de95f8283ac23793fa9fac83d1cf")
setManifestid(346083,"8331113147702282627")