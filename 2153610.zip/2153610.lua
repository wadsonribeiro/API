-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2153610)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2153611,0,"63ddac76d2c030b430a8215c8487b45622bb38d2912b4b03f9cf243aea554531")
setManifestid(2153611,"4730311614509241491")
addappid(2159190,0,"6ae7b7ad83be6aa8ad77b1b20af4919876ff7933f62d567196d45439865301a9")
setManifestid(2159190,"4811791509075477047")