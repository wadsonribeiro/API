-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(990260)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(990261,0,"2a1e109aa8f18d8d989c42c41232b0f70d707797347d3d9093275ac94c055f21")
setManifestid(990261,"384038797974962589")
addappid(990262)
addappid(990263)
addappid(990264)
addappid(990265)
addappid(990266)
addappid(990267)
addappid(990268)