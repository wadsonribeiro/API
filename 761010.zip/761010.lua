-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(761010)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(761011,0,"3ccacda6feeb34b7da50798cca8b49a3992c4fd774886dcd529716a46b901118")
setManifestid(761011,"3113389852585803529")
addappid(761012,0,"0d8cede1f652429d8f2bd7238d7dc5eba1e755259ee0cfd22a094ce626f7c5f8")
setManifestid(761012,"5399202784002453269")