-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(588690)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(588691,0,"9947ffb1a67ded53babb54d1ebbb57c662c64586b3114105af73fcba289cb34d")
setManifestid(588691,"2935253467439684889")
addappid(609440,0,"a089bb6f1c71102bd95d2419b112bf708c54cfd86cfe0b418a65ce0bdbb62130")
setManifestid(609440,"198448490522423958")
addappid(588692,0,"21f1173eac48f69d002f34eb8a386cadfe4b3cb34f99a3ca6d0970ca6fc446ce")
setManifestid(588692,"309794837971508031")