-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(489070)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(489071,0,"ed33def0635d436b88c42604499fe302488178ff7b1f88645c02e268d2ef889f")
setManifestid(489071,"8267196603154353681")
addappid(523040)