-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2366830)
addappid(2366831,0,"517f6b48800e248f99c6455cae2bbedbd5a18b3d5da815c553160fefa8880448")
setManifestid(2366831,"3775769384260144019")
addappid(2366832,0,"e41d5bb1324d2a008ca1a42ba9c937d587c453f3eb4c6c3edeceee62eb566492")
setManifestid(2366832,"5512860641779112186")