-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(454910)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(454911,0,"0e6398935cff4066fe3693b66c68ead3cf829d37b82c05b4d3831eb04655afdb")
setManifestid(454911,"5071478004519647036")
addappid(454912)
addappid(454913)
addappid(454914,0,"d20b323325a373c3d025775d87995e906e7cb506da2a86fe34903f964446f8bf")
setManifestid(454914,"1472797816453675388")
addappid(454915)
addappid(454916)
addappid(454917)
addappid(454918)