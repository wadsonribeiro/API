-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2763730)
addappid(2763731,0,"b052c6a1cfc842b3ec4bae5dd8c754940b10ea4374ad10c98738dd4baba1f4d8")
setManifestid(2763731,"3910486147056435771")
addappid(2763732,0,"ce6ef67b7ea9f4fcbff0596663458de4029093912127286dcaea341eac42a014")
setManifestid(2763732,"3107308177178267346")