-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1917720)
addtoken(1917720,2642935181571907477)
addappid(1917721,0,"1210ca7aefc2ae85451d2252b3a7ec0883e031e5288df487ca147cca56433887")
setManifestid(1917721,"6603204508423331766")