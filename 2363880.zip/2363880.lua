-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2363880)
addappid(2363881,0,"b79644fca8bc74cd923383158bf3571add465e383faad45980fca34fe45d29eb")
setManifestid(2363881,"6035074369196254120")