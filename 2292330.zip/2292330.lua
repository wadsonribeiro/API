-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2292330)
addappid(2292331,0,"d64cf6b7d0dde704f0e7482b5e808c7c92e4bfd640ca2abae72998e94cb89ec9")
setManifestid(2292331,"8222595374129827645")