-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1424800)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1424801,0,"05b14351850b755d45f4c0d15f6ec5fb1f228c2f5c2ad3358b2c1a2bc0dfdcca")
setManifestid(1424801,"3835565721977098930")
addappid(1424802,0,"6327f14abde99498df25b483e5639fa2d5f6fa899900b03c757647fe736aea48")
setManifestid(1424802,"2363000941244658290")
addappid(1424809,0,"d4fa0b028a25879d82f424cc9a2bec9a047948273430083fc78d56bcfd2eaf26")
setManifestid(1424809,"4359113238036435371")
addappid(1585610,0,"8e1a80aabe78427a1aee11bb95d11aa9469e5fc4ca29992d6bf79ca92336a223")
setManifestid(1585610,"7046320585586147069")