-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(896660)
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
setManifestid(1004,"7747775778018907449")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
setManifestid(1005,"2135359612286175146")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
setManifestid(1006,"7138471031118904166")
addappid(896661,0,"3fceadfc3b43eeb8b99b6252e097ae76be634b44da5de93e24e728744ab2d32f")
setManifestid(896661,"18007466826975597")
addappid(896662,0,"bfd072165d1948338279d6dbbb59f3eba8db112e9249311822ba40ba69593754")
setManifestid(896662,"1334377175072024333")
addappid(896663,0,"24fd9b099dacad85d14865546090b20856fc59b0ac21124311571d0b4172e704")
setManifestid(896663,"5373306441100025175")