-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1875310)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1875311,0,"a4fa397817fd35fc2d8975a2c1db8a528dc68750b4cc1391e2fb5e4f47f7410f")
setManifestid(1875311,"7376486828852379498")
addappid(1875312,0,"1a4ea584710c275d06c1a980e70c610492cb0b82de19994aceab6b30716f4fec")
setManifestid(1875312,"3248590837949749638")