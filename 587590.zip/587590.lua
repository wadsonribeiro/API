-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(587590)
addtoken(587590,1755668846247073664)
addappid(587591,0,"10107281de188477a108be7cf47c85c81a20640d739fa901a88189b8f8f0c0e0")
setManifestid(587591,"3687003502551533344")