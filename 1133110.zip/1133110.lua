-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1133110)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(1133111,0,"87ff8f13dade02518d19effd1d8965885129f7f4179e817f4487ffd0b07c8304")
setManifestid(1133111,"3579847354730955625")