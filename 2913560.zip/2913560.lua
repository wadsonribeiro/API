-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2913560)
addappid(2913561,0,"f59f5c659d77716e5d5e64181938fa89ed2f583ef5d98f1e6c03792cb8f60698")
setManifestid(2913561,"8022662911265460054")