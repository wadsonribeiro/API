-- Configura��o gerada por Onekey para AppID 3017860

addappid(3017860, 1, "None") -- Adiciona o AppID principal

-- Configura��o para Depot ID 3017862
addappid(3017862, 1, "b537907a613fd29911d2e311eb41fd2f0b309324601b0ef164c8520562eac290")
setManifestid(3017862,"6394818125548010371") -- Bloqueia para o manifesto mais recente: 1207483256999145647

-- Configura��o para Depot ID 3017863
addappid(3017863, 1, "0c010bdf1623542793fb5765875c715494c4a6c78856f75c124aa7d31f3021cd")
setManifestid(3017863,"7752177482456135655") -- Bloqueia para o manifesto mais recente: 7277804419344617298

-- Configura��o para Depot ID 3017864
addappid(3017864, 1, "35f0d11b6d2b729dd8e5f50a21e7b0300e8d6b79fc6ba487f4198ca6d3402c0d")
setManifestid(3017864,"673779864479266742") -- Bloqueia para o manifesto mais recente: 7469488182398135778

-- Configura��o para Depot ID 3017865
addappid(3017865, 1, "558521d6ef4cac7a1318bb55268dc878b72482482691e7791ea81bff06c73694")
setManifestid(3017865,"9108580810918908470") -- Bloqueia para o manifesto mais recente: 9108580810918908470

-- Configura��o para Depot ID 3017866
addappid(3017866, 1, "cc9112a06785fd0d7f6e24a50702f1f71e655e35caf8fb3ea09f6036680c0fe4")
setManifestid(3017866,"9217731964535062300") -- Bloqueia para o manifesto mais recente: 9217731964535062300

-- Configura��o para Depot ID 3017867
addappid(3017867, 1, "8ffa78f10846725bed8d48d1a182cf4088f770691c44561b2d167f84fdc60789")
setManifestid(3017867,"5456226873220833157") -- Bloqueia para o manifesto mais recente: 2781668816118486945

-- Configura��o para Depot ID 3017868
addappid(3017868, 1, "fb3bda82e733857d05419dce15179a1aa642b840af21ef69520346fe8a00e20e")
setManifestid(3017868,"803238751598154548") -- Bloqueia para o manifesto mais recente: 902058716550281427
