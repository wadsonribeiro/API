-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2459420)
addappid(2459421,0,"73a87df86ca8e806923eeb8c95e92c9bc1a3f0a75b82743b00019d499310553a")
setManifestid(2459421,"4821485379509124324")