-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2117950)
addappid(2117951,0,"ae5e2b15f69281a9824228cd739bab66bcfeda99f8be63860a56dbc02e2b800d")
setManifestid(2117951,"1269402885683395621")
addappid(2117952,0,"7f190aef2a2698004d7c882a0106e7856ba5f16933d24da57c1d4d7552c82545")
setManifestid(2117952,"3398387688886080034")