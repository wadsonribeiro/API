-- 1572920's Lua and Manifest Created by Hubcap Manifest
-- SuperTux
-- Created: September 30, 2025 at 21:11:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1572920) -- SuperTux
-- MAIN APP DEPOTS
addappid(1572921, 1, "7bdfa9a176d763f0ba8eed46e3f499979269a6632448a967d6cae7683c3acd4d") -- SuperTux on Windows
--setManifestid(1572921, "5157342537938687968", 257325398)
addappid(1572922, 1, "51afde5f8547e95b06e0806346809e974d418ee76461e3cb21c72b4ad738b4c4") -- SuperTux on Linux
--setManifestid(1572922, "8437320339285248230", 189248704)
addappid(1572923, 1, "28bb914a4fc39b08ecff45f0a35df7b2b93b904e10e8ecf877d73df2801e9ec0") -- SuperTux on MacOS
--setManifestid(1572923, "435038371539905602", 295052022)