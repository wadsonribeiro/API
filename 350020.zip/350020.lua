-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(350020)
addappid(350021)
addappid(350022,0,"894b8379864d5dabb724dd3721b48898972b7bb6fdf7d1c97b0d965852238b0c")
setManifestid(350022,"3046523522171366916")
addappid(350023)
addappid(350024)