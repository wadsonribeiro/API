-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(757350)
addtoken(757350,12624418487527438998)
addappid(757351,0,"2808245104fd57612bdce91f3cc02121e5bc03370ed7a8392266fd5c54f536c7")
setManifestid(757351,"5679484664261714264")
addappid(757352,0,"11c7997229c168afdcf2e312818f855fdee7e1d855f98a0cf045b183c7321e1d")
setManifestid(757352,"547978774088575192")
addappid(757353,0,"f9fb780b302486524a60a942797423af47d8f990ffc162ebb69b1014b6877cad")
setManifestid(757353,"3879336504591715351")