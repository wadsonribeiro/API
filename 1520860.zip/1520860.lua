-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1520860)
addtoken(1520860,13641337081709564843)
addappid(1520860,0,"9fce65aab43d3650d19e8feedd4e4f68b54a2003f1c9f1686e7c5e080247a6a4")
setManifestid(1520860,"1567111953610978806")