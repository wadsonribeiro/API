-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(639840)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(639841,0,"18ea458eff02eb4b815be659c81b2e44aeb750e00554c53ce35a68599322fc95")
setManifestid(639841,"5834561466923487379")
addappid(639842,0,"8514ec7373e3689777379efe76615beef5aae5c845456aec16fceab02ffcec78")
setManifestid(639842,"7440079180943049519")
addappid(639843,0,"003df408030491af27c664769478649082e01ab9f79536c986b9d9026168d6cd")
setManifestid(639843,"2842264679673904173")
addappid(639844,0,"0ddc4dfdc138b9a2b4ab7d79c41a4c6dbf8268e2350466db0c79a2e6c5ca2610")
setManifestid(639844,"6852746453016060843")