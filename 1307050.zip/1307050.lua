-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1307050)
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
setManifestid(1004,"7747775778018907449")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
setManifestid(1005,"2135359612286175146")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
setManifestid(1006,"7138471031118904166")
addappid(1307051,0,"1356237392ab0476e9bb1c3b443a78d6bc7b5aa7865b0842472cd46eff15c082")
setManifestid(1307051,"1523941918159576744")
addappid(1307052,0,"0ad5816f93cf193bae190992fa3f56a61de6a215d00b1307a882ac58577492cd")
setManifestid(1307052,"4991510105517689859")