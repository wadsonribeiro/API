-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2646640)
addappid(2646640,0,"c532ffc47cda2a8b782aa6673bfff36e2a9a8384f6e2e239517b81e122da827e")
setManifestid(2646640,"6067082717983203231")
addappid(2646641,0,"15833ce558facb5ab734d163578623653f87c6829d0ef7cba492550c086bc475")
setManifestid(2646641,"4715691897198229477")