-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(599750)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(599751,0,"76dbb4285bcfd8076fb5295603ab9b173a9d7130136d683ed38491695021731a")
setManifestid(599751,"1304560201973399275")
addappid(599752)
addappid(599753)
addappid(599754)
addappid(698240,0,"f601d6efa38105336282de197139c09f9318a355616b458f59cf259e89fd9a59")
setManifestid(698240,"1978615015481754390")
addappid(1255950,0,"7284e29b9723940a41fffd51382f7d2e0f4c7b7e8d2bcba21f1dff315f195cf3")
setManifestid(1255950,"5346366215909936475")