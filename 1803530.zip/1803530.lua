-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1803530)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1803531,0,"1e2755d5933e7230dd9610e12e951fe8ec26eff8b2f3192f56505c832c27c839")
setManifestid(1803531,"6704360211450044270")
addappid(1803532)