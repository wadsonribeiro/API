-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(663340)
addtoken(663340,8093531579842713310)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(663341,0,"3260a02649cb0ea2ccdac654e2d2d4848f3a258c26ed3a1fe210e935aae1f1db")
setManifestid(663341,"2419097291653936146")