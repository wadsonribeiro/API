-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(966560)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(966561,0,"f35c5d8c6dc56bcc6dc855f35662de83854d95581d5335bb6fe5e7246f7f3fc8")
setManifestid(966561,"3313675302295863876")