-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1668310)
addappid(1668314,0,"2cf6b5eb23d3cd3b557ca209d90e75de26fe9b5eb1a6efe124d37302df4dc858")
setManifestid(1668314,"7021080821997072942")