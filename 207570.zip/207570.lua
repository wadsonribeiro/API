-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(207570)
addappid(207571,0,"cc8f6871f6bba2a47a4b0987950189cdf0c17ce2a0f60b3b89d0498fbb505415")
setManifestid(207571,"8307359918131710219")
addappid(207572,0,"b26d599055ca94581fa51a60405fbff6304080e9e55c346a23f18294e1b8cc5d")
setManifestid(207572,"2232712507818075851")
addappid(207573,0,"b984a92771c19d58258e1e0a293314359df4895bca57dc7ef047dca32bdde447")
setManifestid(207573,"5681144404624345672")