-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(340000)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(340001,0,"2133fbec1526b19d8371840e55a6f28f3718a020d361a3f78d141dfdac7394cb")
setManifestid(340001,"6513585141498252703")
addappid(340002,0,"5c0a3371f161fa9a87c588a9df3f366db9f9787d8805e1e2ba6462ddbe442e5a")
setManifestid(340002,"7226509546985374927")
addappid(501260)