-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(709800)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(709801,0,"9e07cde01c907c97e127f9330532f523125c8ed9dd96d7b1362ecd2f1081ca90")
setManifestid(709801,"444657577910751089")
addappid(709802,0,"4f6447bf732082f8538cff52a3bce90fed514fe67fc47484934321d63a77c681")
setManifestid(709802,"9218130227161418199")