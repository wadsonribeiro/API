-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2357400)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2357401,0,"69add776d95d91e0cba5459327b642259840ca08bae4c1360d4b0f68b5b15f54")
setManifestid(2357401,"3039194975491971213")
addappid(2357402,0,"60aafb8d9b18aa1464f9defffd35d97dd6e3310b0c0feaa8caa54b2939709f50")
setManifestid(2357402,"5344775708756820551")
addappid(2357403,0,"33b58bde4eaa3c6ed90d704fc2f76998ac789968b18fd47b43b12795f0dd9ab3")
setManifestid(2357403,"3496013967266787152")
addappid(2357404,0,"0d5946468c5368edbf8103ac5af6c32da2e6bc6a2ebd0de7666b334d5d2c9ba7")
setManifestid(2357404,"1600030758086210134")
addappid(2357406,0,"5d62c6342e84912218f0107484af0bf38ba33dcfa40c56150d6167418c557349")
setManifestid(2357406,"1490933383138643791")