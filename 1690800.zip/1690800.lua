-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1690800)
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
setManifestid(1004,"7747775778018907449")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
setManifestid(1005,"2135359612286175146")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
setManifestid(1006,"7138471031118904166")
addappid(1690801,0,"3ced83d42c2942b25490dfd60bfb055b506c6a23c24651d19db8bc90c005adff")
setManifestid(1690801,"6717473099110440489")
addappid(1690802,0,"a294c2888bd47bdfff6d5c3b004542c13949bfd54879e9f41836195f840fbfa0")
setManifestid(1690802,"6204133154971956314")