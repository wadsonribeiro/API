-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1692210)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1692211,0,"792329d5ab00c0cfe731e339d2c392081b54db61aa67e505eef9d6b0a44524bf")
setManifestid(1692211,"3459663327649691146")