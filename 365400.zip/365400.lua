-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(365400)
addappid(365401,0,"1fb5cba5650ad7959fe0bbd11ce4f040dc9797b576f81c7f78a29b67e75f66cb")
setManifestid(365401,"299732883583023221")
addappid(365402,0,"6a76d841877511f6bd055a32b45f2f8aea412ce0d1b35ead7a52b67748d5cc58")
setManifestid(365402,"9138452762952427548")