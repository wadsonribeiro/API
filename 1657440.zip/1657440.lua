-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1657440)
addappid(1657441,0,"794213964d6c3975cc7fb68101a0922fce047a4a6065ea42205558b0151f84d9")
setManifestid(1657441,"6472180106378732512")