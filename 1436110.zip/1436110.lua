-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1436110)
addtoken(1436110,14701135545328475225)
addappid(1436111,0,"ed23c64e3379c991b0a0bf56512bfc6e8f7a656253a5e63218a59e46affcd48a")
setManifestid(1436111,"1302897397049820898")
addappid(1436112,0,"b8d0094601af4e147425b4ed0a78ea14499e8ba3bdfb7f0462a971de28fe6d68")
setManifestid(1436112,"2115228376620519194")