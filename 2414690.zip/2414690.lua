-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2414690)
addtoken(2414690,5132092568546615147)
addappid(2414691,0,"1e8a9240c368e2f0bec3178e566dfaa8c51de97df96aa9f716961b71504cab45")
setManifestid(2414691,"6838907318846640307")