-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1228580)
addappid(1228581,0,"57dca842a628d06175c5d06e691d3cc58b6abd70c3cee3d94e1f9fa0053d30de")
setManifestid(1228581,"3571647524641879057")
addappid(1228582,0,"16495dc8b563820bb25d5aa76a7fa63194c8c89c12982950850f52e75da8d04f")
setManifestid(1228582,"8689343520107435350")