-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(669980)
addtoken(669980,9293168110378902771)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229032)
setManifestid(229032,"3616495131483866412")
addappid(669981,0,"5ef21290e3021aacc859ce521709bc57af37154441c8d82055a4b8568fa839d0")
setManifestid(669981,"956793486821144482")