-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1758410)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1758411,0,"3f20cb9ed968b049ecbf6e02ccc9a74050eadbf497d03e5387917b52fda1d8f8")
setManifestid(1758411,"6412399250697951006")