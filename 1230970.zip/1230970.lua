-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1230970)
addappid(1230970,0,"9df9d2fa60d70f8a55e93d1a223c944cd386089c7b05f9dcff0d7142233a9423")
setManifestid(1230970,"8627452329309688767")