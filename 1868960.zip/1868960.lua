-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1868960)
addappid(1868961,0,"61def15eb898b89294304d031c2b7e3ce72211758eb97d5ea86187811308db96")
setManifestid(1868961,"3079188670848028585")
addappid(1868962,0,"fc4268bc15d1273c1f5e043e968fdf5fb626cfe96119ffb6843b607e74e028c2")
setManifestid(1868962,"8843570668716193968")
addappid(1868963,0,"6329a6a0bb6f8dfa347c6f1f16a9dbc569a59124c52c849b3488be85e87f1db1")
setManifestid(1868963,"3326600078981272137")
addappid(1868964)
addappid(1868965)
addappid(1868966)