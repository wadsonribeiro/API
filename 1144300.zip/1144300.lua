-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1144300)
addappid(1144301,0,"23d040c83263c90ade9bd184a2ccf087c8639e9f4c76b0b069ce21bbbed780a8")
setManifestid(1144301,"5329705079754136552")
addappid(1144302,0,"e732ef3ce1b0ef5c79c00ec927c48b39c637f70267ff671a329e257df058017f")
setManifestid(1144302,"2285937270932589987")