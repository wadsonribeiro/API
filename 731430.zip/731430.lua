-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(731430)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(731431,0,"0a99d19bff4e52f448a1ecfa9f4e503caeafbf97bc9a144740c272acb022d568")
setManifestid(731431,"1410560587207224647")