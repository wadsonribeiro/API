-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1657310)
addappid(1657311,0,"065842dc54202ce0afa1a8f4d11d2d7d129b79b49acd246d6dc3b2c33b853b21")
setManifestid(1657311,"2710098971904494955")
addappid(1657312,0,"4914532fd52edc4ec80eafc79326280f62b2c66b8ef672d7a62d765721643f01")
setManifestid(1657312,"6730158953108216754")