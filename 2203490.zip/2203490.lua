-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2203490)
addtoken(2203490,6162021649697971926)
addappid(2203491,0,"4f70ffbf2a06ae2f1f2a5ae21d6845406f98788a99cc2e4b4b8c6103b755bca2")
setManifestid(2203491,"6306213940813425507")