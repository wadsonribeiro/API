-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1662740)
addappid(1662741,0,"fd3c776c17ea67069e2dd66e73b01fc8550d0ea03836a9177300f549881ee05c")
setManifestid(1662741,"8053010797365671666")
addappid(1662742,0,"809525bc4d205dd59dedfb2c1bb41deb187cfc2735d11e79e5624761f4060f88")
setManifestid(1662742,"3227157793810842671")
addappid(1662743,0,"1cbc8c34b086ad376e3c6ad1096c05e4cc8d595776aed0b70fd624b0c4589e52")
setManifestid(1662743,"2722476445999305423")