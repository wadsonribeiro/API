-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(569760)
addtoken(569760,4848620735806236664)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(569761,0,"c137154f197c9b1510fd62ee5aff14ff68213d6d9d489baa316191ea9b52616f")
setManifestid(569761,"7846986004088450648")
addappid(569762)