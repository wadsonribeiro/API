-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3283260)
addappid(3283261,0,"c32c38f7115c77ebada7db8c73d1a9b03795f02da7b75624a70cbb176d2a1d9e")
setManifestid(3283261,"668437355029207699")