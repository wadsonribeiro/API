addappid(872670)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(872671,0,"87514c506dda0ed736b270bc5563c239ebe571e9c215a2c9085414ba6c22d26a")
setManifestid(872671,"8978397738746937178")
addappid(872672)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]