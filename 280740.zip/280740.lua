-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(280740)
addappid(280741,0,"35ee7e283200da3c20f00406efc63b079fd0a3ca3a192a20dc75de529412c940")
setManifestid(280741,"643216286453313550")
addappid(280742,0,"10e743b57959375286f0e65c9a206fbe1f97e3e2582b9c4576bc2565628e12f9")
setManifestid(280742,"8694603736528831053")
addappid(280743,0,"be555c47e1c4bf78c38dc277eb05ced05f18d5cd14d5ff0270c20739ad59ae58")
setManifestid(280743,"3451775592522251150")
addappid(280744)
addappid(280745,0,"3d2ed44717e501343e15da0f71fbc1a08375914e549eabc9245f0896097fe8b6")
setManifestid(280745,"7244146245344714399")