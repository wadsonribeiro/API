-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2696630)
addappid(2696631,0,"4ffce8bc14cf5dcbce4501361e1eef7358b6cb8bb58d3212d6ef4da2879fcc11")
setManifestid(2696631,"1861683744156781279")