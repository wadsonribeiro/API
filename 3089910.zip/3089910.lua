-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3089910)
addappid(3089911,0,"ad6e74ede75aba32203a011af40c506a771be84256f15775efce310170c4676c")
setManifestid(3089911,"6229163073173979005")
addappid(3089912,0,"cd045276bbdda167270fd46f0b129a781e705003f2af095fe71bec217d065b95")
setManifestid(3089912,"1071123769281934173")