-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(781940)
addtoken(781940,2091256137031605857)
addappid(781941,0,"1eb7df0cf5d245f9aa81dfa3b9e19fc30eeb6170e8937cbee151c6a33734b620")
setManifestid(781941,"5315454908516361882")
addappid(781942)