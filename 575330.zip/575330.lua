-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(575330)
addappid(575331,0,"ede43a7cdf729c9e9fece2e034b6ba7fb6f4dd777300e2eaa7d8efc3631a503e")
setManifestid(575331,"2514560747858018111")
addappid(575332,0,"5bc58789c350f8594348248f7cbc2b6476632e03419da9678dc25c24680870f3")
setManifestid(575332,"8770015101482468899")
addappid(644700,0,"4227e3ca1e3ed4742b03a9b53a0548ddc607c806d30466d26b4f74e35fd09cfe")
setManifestid(644700,"6092154399807034070")