-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2853240)
addappid(2853241,0,"690875d2ec8ba5f1852a5f06da0a3d5222eeade1bb6fead30f25019e29b6b423")
setManifestid(2853241,"1440624509783830531")