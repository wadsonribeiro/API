-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2164530)
addappid(2164531,0,"4b6848723cdf8cf1a7b7da508fb42c3aed657876992e3192a6d947a8dd7f515e")
setManifestid(2164531,"7615183011328470743")
addappid(2164532,0,"63a3fef2bfc86c8c6079e95ef878d40ba6a19502a00541e327533a731bf5b42c")
setManifestid(2164532,"2225638640293391554")