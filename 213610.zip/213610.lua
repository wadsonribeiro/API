
addappid(213610) -- Sonic Adventure™ 2 
addappid(213611, 1, "62f1345bc9ba1ad0629de28584b42ae616b50160113d7735b6eda7f0e9434117") -- alpha
setManifestid(213611, "2881461178350562369", 3253731096)
addappid(217900) -- Sonic Adventure 2 Battle Mode DLC