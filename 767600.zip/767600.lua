-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(767600)
addtoken(767600,12720633364357541)
addappid(767601,0,"e017b2298de950805566c8e73b48c3946c19e7e1f93ba917470d2424ef5b7d55")
setManifestid(767601,"2543005611611714383")