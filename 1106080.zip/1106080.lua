-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1106080)
addappid(1106081,0,"6aa1f739b0f068de667897a9ab3d27f5b9f35776fbdfb7a333a96c77d72222ce")
setManifestid(1106081,"1801210921800980923")
addappid(1106082,0,"7095289329ad631d1c448b3f8215d18a3d010da980c341cd6c9caff41dc8336c")
setManifestid(1106082,"2742540179516457288")
addappid(1147920)