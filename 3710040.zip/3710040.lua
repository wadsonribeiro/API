-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3710040)
addappid(3710041,0,"edf5119b6a103d72d5e70ae2e25c8730e40beb39c68fce26897f513582f1f20a")
setManifestid(3710041,"6022844282801282516")
addappid(3710042,0,"b79f02400069fcf4861a3f0f18c779b727b592ebf0e20450de891690acd6a087")
setManifestid(3710042,"862895774725916774")