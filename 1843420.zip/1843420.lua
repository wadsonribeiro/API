-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1843420)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1843421,0,"8fc644a4f48db6324255941a1cf1c8449f933f5163d98ccda25294cd8b59bd0d")
setManifestid(1843421,"3759911277674985325")