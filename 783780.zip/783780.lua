-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(783780)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(783781,0,"27ccb4801430135c5d867b37aa03c4ffea2f73787e8c06070ddf9a91ba412124")
setManifestid(783781,"9215999898842295870")
addappid(783782)
addappid(783783)