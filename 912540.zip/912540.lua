-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(912540)
addappid(912541,0,"a2cc9c4397c1aba71953063b342b2638b301f795798475a721e0a5a6a1364433")
setManifestid(912541,"5399336268074654699")
addappid(912542,0,"76df1f76ea37dc51a168f5a67bd7c40065400547a8718e720e95ea62c31b74ad")
setManifestid(912542,"1502354477762701985")
addappid(912543,0,"6df3b3c4def3325e47ce14e517a6c73f67fe4ffb21de65aff6f86436ed6fcf04")
setManifestid(912543,"6740370550279539406")
addappid(912544,0,"e4bffdaf951a478e6d7dedb9debb6df4c15f5fc1eb192ea202cfd62429302784")
setManifestid(912544,"8174987582984342919")
addappid(912545,0,"10ea07ab2bb68959b90c669ef9095ae987df86ec1a52c2c5288bbf53c65e8211")
setManifestid(912545,"930427278381079634")
addappid(912546,0,"9ec2135cac5b243039cb39f5f870348f507caba7abc5f5f4fe4526cadefd0fc3")
setManifestid(912546,"1399605360143729538")