-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(963450)
addappid(963451,0,"9614b572662d29cb3b2cdbae90fb8f1401c12ae2cf6401e84773dff11cbf40ea")
setManifestid(963451,"7893557640977851383")
addappid(963452,0,"157a2da8918c71d621a6c5275d4ca8ab01a2c6345ecd8a5d9aa42492677ea119")
setManifestid(963452,"7211672141665188480")
addappid(963453,0,"621076f2bf8bf32d71856b74b8380f4a7f34ee6c0c3f14262ea441b8b078891b")
setManifestid(963453,"6527125694998440365")