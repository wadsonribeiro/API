-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(311700)
addappid(311701,0,"1d49ad425da5645446805a607f4ec34efa0f369309611feed439e50832ec1ae8")
setManifestid(311701,"4102537223214629401")
addappid(311702,0,"0c0b7bc90ebd492b4bfef72d9973fe28f20e119493812ea7f3005a77088d1865")
setManifestid(311702,"956798352322204270")