-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1885640)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1885641,0,"90dbde502283ae78b9880e8411d37a1a9bd68699163188ca5adf5d4bad3adabd")
setManifestid(1885641,"518506850791745298")