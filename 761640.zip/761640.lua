-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(761640)
addappid(761641, 1, "50c491343eab246f5114f72107ae9b7867e3f1ef5dbdb5ba03a43ea5193ec52d")
setManifestid(761641, "6666013054242944722", 0)
addappid(761642, 1, "c01b91d31070e3451dd5b0dc7c2fe7f682a1650211d90c24aea1281ad79becfe")
setManifestid(761642, "3338943002604318437", 0)