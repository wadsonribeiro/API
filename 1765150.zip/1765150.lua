-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1765150)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1765151,0,"bfd76a5bc14ce7a2f23d569a3283e4b962a4395b6d79491fb37e7240b9c7c31b")
setManifestid(1765151,"1343754514175921884")