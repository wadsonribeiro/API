
addappid(268910) -- Cuphead
addappid(268911, 1, "5f5e2d0105e9fcfbd0c7151658efd92af0181865fe434192f8e2c5d24d4940da") -- Cuphead
setManifestid(268911, "2961019062399342472", 4044947883)
addappid(268912, 1, "6378a6f3808fd925e8fdc2cd115d7b60f1908a6dff6b5f6c1fb0af7f392db1e4") -- Cuphead Depot MacOS
setManifestid(268912, "8936126933278923535", 4055632137)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(1117850)
addappid(1117850, 1, "c40d10dcd40756563a4956777e0bb4333e48d34c00e2836edd3d5fdbc0eba095") -- Cuphead - The Delicious Last Course - Cuphead - The Delicious Last Course (1117850) Depot
setManifestid(1117850, "7764187989484304781", 1747323887)
addappid(1117851, 1, "1d08dafb023ed4a43d3def619d54ace53b3b4bced035e744da83b4449f26cac7") -- Cuphead - The Delicious Last Course - Cuphead - The Delicious Last Course macOS
setManifestid(1117851, "4830840309801799910", 1747322969)