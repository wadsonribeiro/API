-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2636230)
addappid(2636231,0,"a46bd998a77962635109e8d6a7dd193292c76ca14afb7ba17857c152e6d9df30")
setManifestid(2636231,"6206001950747676811")