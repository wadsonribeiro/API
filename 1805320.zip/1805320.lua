-- R0mested
addappid(1805320, 1, "599b4f76f1f0ce31faed38ccceab7ccf4bf1b3d55cd0ab8f32e5c0946917bbc3") -- Romestead
addappid(1805321, 1, "ea667c299933261c2a9c4bc7cacdfb85edcacd2ace53d6724caf767ba25ee827") -- Depot 1805321
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
