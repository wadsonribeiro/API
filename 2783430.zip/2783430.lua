-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2783430)
addappid(2783431,0,"5ee1167616fd267d65629b0e75a88e4fa801949ef2737ecd631be1d219bd0152")
setManifestid(2783431,"4348205378621053538")