-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(684460)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(684461,0,"8f51547478bb06da8eec3e40b02405ed70b48461a91b0c9566969fa47337f4a7")
setManifestid(684461,"8044609865353656918")