-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(322460)
addappid(228981)
setManifestid(228981,"7613356809904826842")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(322461,0,"7fddd6fa7e6905db8a68c6cdfd1e13c637e2b93c732382d67dc27840492b434f")
setManifestid(322461,"5369064901799270825")