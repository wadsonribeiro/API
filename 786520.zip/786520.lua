-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(786520)
addappid(786521,0,"d5364f125e631463d60b44943b449ff1677c7ad2df602a916bde6c887485e752")
setManifestid(786521,"5407133973783463703")
addappid(786522,0,"6a946b05b80a12e0dc95a2628425c7a6cd768559f5fc481e8c2c842397e0968c")
setManifestid(786522,"5888273201143666278")
addappid(786523,0,"7f6f53a4160d6b35bf5671f7a8dc60bbdbb91de0f12186b1f7835513fb3e3fa2")
setManifestid(786523,"5690411872288604589")
addappid(786524,0,"300a4b8f8135bd12eeb4d2f94d9f69141753e8e1a4b332107f6bad37ac232531")
setManifestid(786524,"8988569989823064059")
addappid(786525,0,"6f15459a13b4ae24737cb2f8918a8f9008a83a750e07ddbf73dda5b4fa4e1afd")
setManifestid(786525,"3671924945858449972")
addappid(786526,0,"ad885be1fa6a4a6efaaa6c29f144dc683d3992c8092062e46e11889cfb236fba")
setManifestid(786526,"5194991772744802458")
addappid(786527,0,"ba0a511c237ac6aac322d428052ea5bc0b476f31f0450b73f657c7697d7299d0")
setManifestid(786527,"6834164308165693654")