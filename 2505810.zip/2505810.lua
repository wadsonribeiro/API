-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2505810)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(2505811,0,"59f8c604ded88394db805b9dd4cbb630d78dc40f3e64cca069d20519ca279e37")