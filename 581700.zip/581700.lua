-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(581700)
addtoken(581700,14074891797495668583)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(581701)
addappid(581702,0,"d4a0c001c0b2ff5900f4d62931383c5800df6c0773fd817dcebe5208e887dc95")
setManifestid(581702,"9159432226657826517")
addappid(581703,0,"999ed89cf209e6a70f43f96df16825dc354c6e16700995495e0dc34a865b870b")
setManifestid(581703,"6065437689322405545")