-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(319260)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(319261,0,"230e10ac59160c7eb6a48559a2d3dfeff762286b159f481d39af4033e6e6153f")
addappid(319262,0,"5266366b21c25abb6122b798e85ebc43df799883a6ef8e89dd9aba575ecd3d2d")
addappid(319263)