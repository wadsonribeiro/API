-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1817630)
addappid(1817631,0,"5321ccd49b55eebdead9838f3598307d6972a7d6d39f675fb2b90bc91bb4d71c")
setManifestid(1817631,"2429875384782306556")
addappid(1817632,0,"85baaffd9a690bb46144403e72afd653d4d2669dbefd4c4fd92bcee9b77b3736")
setManifestid(1817632,"7271364085851227655")