-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2665920)
addappid(2665921,0,"8b4fc52f9a1e1ecaa1515c44de5e3075573fd07956ba10808b8bc6fdd190664c")
setManifestid(2665921,"1661347380769934684")
addappid(2665922,0,"303398f638cf64a6d1d774a148dc839c75b77987226633d34a681924c4357a74")
setManifestid(2665922,"5700356957694210553")