-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3193810)
addappid(3193811,0,"13bb24aec83dd1d97fb89aa9cde9ec167fe8b5725e5fa5cfd190dbfaf483f85d")
setManifestid(3193811,"1987733506382615523")
addappid(3193812,0,"1da5b04d5bf13510469f27a0d3e622897963d54b82e34d39a2330fc0153b6f49")
setManifestid(3193812,"2912969025784508134")