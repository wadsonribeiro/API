-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(683160)
addtoken(683160,1461524691131436402)
addappid(683161,0,"100c37ca79d05b35478055017e4e29839b34c87d28f93191c87f5bc9f1a7621a")
setManifestid(683161,"6715388855812992363")