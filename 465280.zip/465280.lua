-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(465280)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(465281,0,"ecbe6e14974be564079b8f942587dcaea0a171a6f9854a11a5593563a96a5d41")
setManifestid(465281,"2474858291792795055")
addappid(465282,0,"a2fa63c5d1cba792fc2a478a5844a58998978792e2bf1814bd6a9a3637af2734")
setManifestid(465282,"3338545793157802606")