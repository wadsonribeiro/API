-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2370810)
addappid(2370811,0,"9f314acb0a6a4ce0ae2bbacaeda67eafcb8f8992a8f022bd1bbf0fa71c565097")
setManifestid(2370811,"1635655544239141079")