-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1371140)
addtoken(1371140,512102189532180098)
addappid(1371141,0,"a8b8a9769e8e329b0a500efc876dfde9743c5397244928b4223e1266a11d87ce")
setManifestid(1371141,"5339088718147152154")