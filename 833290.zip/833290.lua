-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(833290)
addtoken(833290,2030903386742200006)
addappid(833291,0,"9146d4cbcc7319aad33411124cad7edad618d66fbe55106e1a4940fb8e16650d")
setManifestid(833291,"508775781473215818")
addappid(833292)
addappid(833293)
addappid(849150)