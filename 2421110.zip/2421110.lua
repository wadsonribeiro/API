-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2421110)
addappid(2421111,0,"6eb6bdf7ef449997381dee05eb390b6edf4ab3c63a01a405e3d3bed6f3758ce1")
setManifestid(2421111,"6739474455842642566")
addappid(2421112,0,"affef32b711b876c4fdeca7a27bc4c7f7b54a44c89b50fad6611a31857753abd")
setManifestid(2421112,"4932605250913082368")
addappid(2421113,0,"5d24a16a5db1de41d1634b4367affe1f2baed241fce0eb9b1cc8c0899b51d36b")
setManifestid(2421113,"2087803871526411030")