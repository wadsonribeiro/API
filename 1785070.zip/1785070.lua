-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1785070)
addappid(1785071,0,"47ae42d0d63bbab871f294fadc33a185dc1f28f51854ace0c5e833709fc71513")
setManifestid(1785071,"1306754800114748573")
addappid(1785072,0,"1fdb983af82eb36f8a0e48fabf1e053ad86c8b776726c2d8238bba99182db325")
setManifestid(1785072,"5802538300264508446")