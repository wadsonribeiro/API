-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(897390)
addappid(897391,0,"2fbad2384a340948fe7bf64021fbff4541cbfb8a6d328feaf47d84a603aa3838")
setManifestid(897391,"285972280962462820")
addappid(897392,0,"251297fe27a6347855229f1756fd76458bea32599aabf1ac8e04774cc2925213")
setManifestid(897392,"1956497648513788301")