-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(434110)
addappid(434111,0,"572b38d940cc0e9ad6a7bd49e597ac11cc4cef27d7f5dc6feae180f7b15e5f8a")
setManifestid(434111,"4391137839142853503")
addappid(434112,0,"29f525ec89fcfd9e4cb3c2a6790f266638bd5bb6eebf96952951269cd5dced86")
setManifestid(434112,"1448138584439862541")
addappid(434113,0,"5e4599c99629926755801f44a055fbccaf136535279f1a0b52c36befaf6a2ebb")
setManifestid(434113,"3507829981109814930")