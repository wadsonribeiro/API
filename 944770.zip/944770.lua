-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(944770)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(944775,0,"c0282a8b8dd157120813890689f24deee202f634e2ff7813b21e93edfbf0bf13")
setManifestid(944775,"1089691567417247671")
addappid(944771,0,"b7f6633a57a61339726d6dec99855b090a1e032b29c56c2941e837685adcccd1")
setManifestid(944771,"4835300934589613609")
addappid(944772)
addappid(944773)
addappid(944774)