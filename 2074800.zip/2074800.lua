-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2074800)
addappid(2074801,0,"1c60b83f26af04b13f22f7ba49b20d81e388536c3a589207af9dd2f02dd5b0a6")
setManifestid(2074801,"8372416081746424388")
addappid(2074802,0,"b567884ad3b5b31ae469d224aaa710a68ddcdcafb189becce36f65f44ba3533a")
setManifestid(2074802,"7630446700186080303")
addappid(2074803,0,"55392481a32eb1b72981655861f57107a3552212bdeb686bcfa9970c8edc4a90")
setManifestid(2074803,"8110522090973143535")
addappid(2074804,0,"3701a04d898b85b754e84a1bfc620f472df8a7ebe6a51be214d985b815d99a86")
setManifestid(2074804,"2175912862221900798")