-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2352250)
addappid(2352251,0,"2bae20726d09958edf89ac11d8ad0963c65f0f1970bcd1a740782b0e3363ba35")
setManifestid(2352251,"6747011711965273570")
addappid(2352252,0,"80b09078d653f550ccd39b2e0ca0d9713ae284a1738b43dbd184254e5f631ce4")
setManifestid(2352252,"2450305453708342668")