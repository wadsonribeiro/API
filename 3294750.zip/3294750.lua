-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3294750)
addappid(3294751,0,"bc77851a21641b36d48167e5a675ffd734c0085698e57ee99347e823905d48a9")
setManifestid(3294751,"5476218556145809410")
addappid(3294752,0,"c65a3834d38aa0dfa65689409672239249b7e9545893641dc26f54a6e65f5d57")
setManifestid(3294752,"1051439307988260873")
addappid(3294753)
addappid(3294754,0,"6866c714a67f122f29b0c4193e5fddde462e104b6dff6c55e4ee5c2196bff71d")
setManifestid(3294754,"8199922918638717272")