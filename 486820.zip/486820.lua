-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(486820)
addtoken(486820,2546510014463970706)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(486821,0,"f5dfd88a17941de0bfce8cce4ef91e192e3f22a6c31b6da972e5949eb917ec44")
setManifestid(486821,"2033578050301522956")
addappid(486822)
addappid(486823,0,"cbc39cf3dc7d46ad78152b382d31a0ac338da70ec8c405e084147797b97fca8a")
setManifestid(486823,"8382701189196195427")