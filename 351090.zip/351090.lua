-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(351090)
addappid(351091,0,"93357ac1240e75cc643b8eb11f22d07c1f75ee124850c7e53f5ceb0e8b095dd0")
setManifestid(351091,"2683067227698081057")
addappid(351092,0,"7ec14e1709d8847e2395351c427c3c24aaced802d107d9a0bbf85347ad5a4a15")
setManifestid(351092,"509429536127640438")
addappid(351093,0,"2516ebd28e5e796ba3d7c1fe3e47f31a22415679f9efc4ae168b04f87a12518e")
setManifestid(351093,"1346519506738142913")