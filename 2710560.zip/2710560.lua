-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2710560)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2710561,0,"17fa3e65a25dd93cef4fb7c7ff54a48db4f57c0dfd7bc082610cb519a43e3589")
setManifestid(2710561,"5963704276229701500")