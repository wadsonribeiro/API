-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1453510)
addappid(1453511,0,"981df31aec65f27a16aa21b59565682001cfaa8aff868d81fd41831aed64e2e9")
setManifestid(1453511,"2614920675432109948")
addappid(1453512,0,"2d5a2dbf93ddf76cbf016d5c106e8d66f9a5e18209804a13c5b8ebd277613abe")
setManifestid(1453512,"1694634259613011553")