-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2658710)
addappid(2658711,0,"442b02484ee74753315b5dc2200a871df8361af4f2d1cc069d0b29d4aef99a75")
setManifestid(2658711,"9019980245649242432")