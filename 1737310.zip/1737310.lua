-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1737310)
addappid(1737311,0,"0e5aa2073783c7829d971ff3a0ddd288bf46ec687b208b5a09d309d87193c773")
setManifestid(1737311,"6624419759866266615")