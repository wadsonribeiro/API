-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(236830)
addappid(236831,0,"849a7289dc7ea62ba5d9a0658d0dc1b4d01bb089cc33430dc27734c0792bf143")
setManifestid(236831,"7948884474929330735")
addappid(236832,0,"4862a5b29b8c97c47b2b9f9d41a6632790cc5ce32ecb9f3991a05f75f7e00dce")
setManifestid(236832,"8943473563000838078")
addappid(236833,0,"db71c8d47ba8efdd112d2afa24189bd00fe88766d8edff806b7627db1675ae7b")
setManifestid(236833,"342717057267795701")
addappid(236834,0,"3318aee3b474bdf6f51525659dad832857f9d0dbb106b5aec5ab84368f9249ad")
setManifestid(236834,"4581434971159332323")
addappid(236835,0,"852fee6aef8f696cbda9d33c0d310d69aca90fc93dff7b17b62d553a6025ffe8")
setManifestid(236835,"9059417141733145409")