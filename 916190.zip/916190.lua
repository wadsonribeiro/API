-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(916190)
addappid(916190,0,"a6b297bd0c53fce42612ef9a3d06d11a25802b3e24319123f5c4ab1511181839")
setManifestid(916190,"9078418595481119991")