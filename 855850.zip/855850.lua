-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(855850)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(855851,0,"d26dc235ae9f4eba530b237835063edb9805353feb9ed60718fe3a56c2db583c")
setManifestid(855851,"4576621475361195725")
addappid(855852,0,"b6a5c9e12db54271291a6e6913077b114da61d6287148688992ce2da403f400e")
setManifestid(855852,"7512547676896898381")