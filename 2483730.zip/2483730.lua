-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2483730)
addappid(2483731,0,"f5a5c09a28760aa3cc0410a57d04dfba3879f0df7b7988db89121c13a1767eb2")
setManifestid(2483731,"4343668357395360400")