-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(661370)
addtoken(661370,9648390877025566115)
addappid(661371,0,"1ca646b575bf88c8276e12f795487ec396e3779bdd3b0f065e4d0758478393f4")
setManifestid(661371,"8429282086448436737")