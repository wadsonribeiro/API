-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3476660)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3476661,0,"556d09c6efd437abe16e6b4a0b3e179a2a471aacb4d522a9c536a2db40257c72")
setManifestid(3476661,"4426249071176323022")