-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1875500)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1875501,0,"a3553677696a6893d3a61639a91d5dc3d9da198842f24bfcfd0375749f41540f")
setManifestid(1875501,"836297907894378246")