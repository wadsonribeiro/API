-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1415140)
addappid(1415141,0,"2a90e8b2d6db25ce6c383eaed806148fe431f3b8ee6f71de6ee982fb1b05bfdf")
setManifestid(1415141,"7975801578922591569")