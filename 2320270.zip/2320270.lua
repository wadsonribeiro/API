-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2320270)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(2320271,0,"5d7d4d581af97640c2bfcccc54e825f51b11502ccb34d62daace32dea37f13d8")
setManifestid(2320271,"4440639074702172345")
addappid(2324720,0,"ab5ff41aa2959290c69697a536d07053713debb34bd03d22dd1e75dc2040fe25")
setManifestid(2324720,"2586233457113350682")
addappid(2335440)