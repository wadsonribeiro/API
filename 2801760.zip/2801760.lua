-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2801760)
addappid(228989)
setManifestid(228989,"1332597174812030948")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(2801761,0,"2afe75804ee105dfc3767c728d1211771a66bd203f407545a9003893e0ead489")
setManifestid(2801761,"7982314857529922637")
addappid(2801762,0,"78c8266d845c97ccc35d0c05b38b3ce3147fb4a86007e9a5849d27b33f3af02e")
setManifestid(2801762,"1961498356212141599")