-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3314480)
addappid(3314481,0,"81e6d9c278bc4b5570282fec0897873368855d80b92a1b5970370a51665c667a")
setManifestid(3314481,"576660813323671152")
addappid(3314482,0,"5d4dbd9289aa3f2db54773d2641ca4dc6f5547760bf6341658ffb89ef30e4c0d")
setManifestid(3314482,"7148413564911858075")