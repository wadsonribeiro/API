-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(907470)
addappid(907471)
addappid(907472,0,"095876dbe0ac9eec87ae1128f2b438804db50d2761f67a7d30adad1171969b36")
setManifestid(907472,"3117915582924326444")
addappid(907473)
addappid(1025040,0,"5337ad193c841d82159c829f5d8d1e2a01d8918e991bff97e03d191af04325ed")
setManifestid(1025040,"6683885968926104431")