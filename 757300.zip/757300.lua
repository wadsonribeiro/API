-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(757300)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(757301,0,"5491c0cd98003bdf7138d63eaf1a72c1d31e27dbdc6658a019fa5a3cfe5b45b4")
setManifestid(757301,"1336451020632204480")
addappid(757302,0,"b41b02334a0e8f2358e99cba291247600ed85538c1685ec36ee0547f3c2bb6a5")
setManifestid(757302,"2142594458218280980")
addappid(757303,0,"7a527c53dca7cd5cdd73e8197fc55d1fa94208e583e3b3bf5f4fcb696f11da8e")
setManifestid(757303,"6851050102754766146")
addappid(1049050,0,"72209a33375b7120672b2de8a304f695689110b2be2a6dc94acba5cbc493e8ba")
setManifestid(1049050,"7182550537217859934")