-- 1530770's Lua and Manifest Created by Morrenus
-- Star Wars™ Pinball VR
-- Created: October 02, 2025 at 22:58:01 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1530770) -- Star Wars™ Pinball VR
-- MAIN APP DEPOTS
addappid(1530771, 1, "3f1f94f500e657606c5a485ae6546c4fecd886a9e766701685e0eb6a29dbedbd") -- Star Wars™ Pinball VR Content
--setManifestid(1530771, "8177993621298953418", 4563496745)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
--setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)