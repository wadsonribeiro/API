-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2776970)
addappid(2776971,0,"9e39ed8c277a480283c4d1ab37fa6c50bd603ea4faa88def09b4a70b00fa4960")
setManifestid(2776971,"8176997639221248952")
addappid(2776972,0,"038f373d3beebb9e3517186c75182d35c13b8caa3857adb7a423a8164dad85f1")
setManifestid(2776972,"8957072015201812268")