-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(449630)
addtoken(449630,13987131576927134219)
addappid(449631,0,"d1d972083185bc0c12e7c5c4b9b218d61814255e88616c94835e898fd31a12ae")
setManifestid(449631,"8906800380605238274")