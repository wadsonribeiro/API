-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1637410)
addappid(1637411,0,"ed5297be5fef4c9201cf3c2411ee855e57a7be2f1d4c2852e2c596a49f5df233")
setManifestid(1637411,"3156629820191055690")
addappid(1637412)