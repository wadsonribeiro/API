-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(696840)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(696841,0,"c553399004149b220ce7a05cc6bb9397f10f52ce9db61a5bf284874314f4274c")
setManifestid(696841,"7973920051893189096")
addappid(696842)