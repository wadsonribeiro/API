-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(609920)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(609921,0,"841da19f9c4dbd845c65c4ca2a5ee49a5640ff5cebf496595f7ac59cc533414a")
setManifestid(609921,"534456931700321992")
addappid(609922,0,"ba996086aae081ae22bbc64b96367a8aade0ab0f8204fad2a4dc386b6e3baebf")
setManifestid(609922,"2328064413886776285")
addappid(609923,0,"60269df9ad02bfb88f134c12cef3199c4ebfcb0bfed950c29de4597c4453a91f")
setManifestid(609923,"7245192958189052167")