-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1770860)
addappid(1770861,0,"74e418e932e40ba24cdb09c446253f02217dffcf82fe16c7c59af2b2eb37fef7")
setManifestid(1770861,"6660361276021396551")
addappid(1770862,0,"53d4d8204b4ee28e6c0bac74aae4999ebd14e987bd74281ed5a426763a85ec85")
setManifestid(1770862,"9091364249949908046")