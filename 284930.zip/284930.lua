-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(284930)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(284931,0,"7d60911244f5e5d2656de34188d1cf1ddf884410c4911cbafb44010da72c4970")
setManifestid(284931,"5733313288824432149")
addappid(284932)