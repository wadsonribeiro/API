-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(982900)
addtoken(982900,562707970773503503)
addappid(982901,0,"97a005d6dcae614c074aca2093984f5c88e823081d394c66c92835dc73d19e15")
setManifestid(982901,"1757797566220876325")
addappid(982902)
addappid(982903)