-- fickle card legend
addappid(4087980) -- Fickle Card Legend
addappid(4087981, 1, "27bb07dcccbf9439f1089605160d670d870b306e14aee47c9db12f5a90ad08f7") -- Depot 4087981
