-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2497200)
addtoken(2497200,14297249910695508853)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(2497201,0,"6a5986ecfcf8e22fefdf99598e35afdb128045a18edb0af02da379b20554c370")
setManifestid(2497201,"7036363985444213760")