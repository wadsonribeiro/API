-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2312680)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2312681,0,"6633d9204d26ff8aa510a87685b921389afed002ba5833ba773b29b987957ab2")