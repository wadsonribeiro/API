-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(945700)
addtoken(945700,2550027226226130451)
addappid(945701,0,"ee5ac2e290c93cdba0776c9aa93507defe13c201f530ab72906c27dee3b53cd9")
setManifestid(945701,"8097103986622890372")
addappid(997100)
addappid(999470)
addappid(999520)
addappid(1000680)
addappid(1000690)
addappid(1025640)
addappid(1025660)
addappid(1025680)