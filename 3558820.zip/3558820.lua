-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3558820)
addtoken(3558820,17041046302464287435)
addappid(3558820,0,"ab5ed1844b76e916ea4ee72419ba812c40aa5ee6454c80c008ce407bbb6c3787")
setManifestid(3558820,"2431488219338558653")