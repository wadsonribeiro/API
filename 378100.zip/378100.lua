-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(378100)
addappid(378101)
addappid(378102,0,"5af467096fce3c27603f38d3a433baf209c11740b94ded46f6b0f036962236e8")
setManifestid(378102,"1875464339507366654")