-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1724320)
addappid(1724321,0,"c590dd8bb5b7295f31f32b3cf4a1ca294a944891e8b61aedb9fd288492fd8f65")
setManifestid(1724321,"6189788004526277920")
addappid(1724322,0,"57ec54beb96ae23bf195dbfd600b64ee0907917d3a22fd5cc7942f276727425f")
setManifestid(1724322,"8734120786130098173")
addappid(1724323,0,"5a91afe24be98668665fd9080eb32e9f31f8f7073ab8c51f8d75a9d901893fef")
setManifestid(1724323,"7505151262659542927")
addappid(2694450,0,"c2c1fe4f85d172d437454f739d8898e9faf96b79b757d3708a3f20463a7f1722")
setManifestid(2694450,"5832621430348101988")