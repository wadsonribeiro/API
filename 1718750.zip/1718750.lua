-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1718750)
addappid(1718751,0,"ab0615136b7d6c19dc1ab67b3a44f44f0abee36fb3ec3f05b88bc5443a3b1c77")
setManifestid(1718751,"7005504885285080954")
addappid(1718752,0,"456ab3c8b1bce017b615cbc8161d9e4a6c3613f65e5efa3eecb18f72ae205559")
setManifestid(1718752,"6981978383291469042")