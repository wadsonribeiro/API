-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1293820)
addappid(1293821,0,"1176da3dd5dff5613cc4a3ee5de01bcaa3c0bafaad5da05e5a3c677ddb5d8c43")
setManifestid(1293821,"8388880111326806072")
addappid(1293822,0,"507af5d90a51c20c1cd90b867d9b4c918d262d20644d65e5021fd15816c141f7")
addappid(1293823,0,"aa27c51a92804367933052431b8da114d35cf2e83ba0d1023708a468394dabcb")
setManifestid(1293823,"3671059500400086693")