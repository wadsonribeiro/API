-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(362870)
addappid(362871,0,"a1e4d8ec2af4f2aa3c010cbc833324f6bf8d2aa47fa03ab597fc28eeac041769")
setManifestid(362871,"837722761356681434")
addappid(367490)