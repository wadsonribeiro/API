-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(987480)
addappid(987481,0,"fe2417b3a9299099ee0cfed0695bab55dfb9337facc01047807cf2025402f5f6")
setManifestid(987481,"8333316812400985169")
addappid(1887140,0,"bb0dce0774374e6d2c3b5b2e94844e826eb07f7260af3d0d39955a2936e9e69f")
setManifestid(1887140,"1059554214963598831")
addappid(1887130,0,"d5d4ca49d3cbb53b394bf8f2dc7d53946e49900066e0b0e469eff5e870c24cbf")
setManifestid(1887130,"6025727755721569407")