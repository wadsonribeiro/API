-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(311860)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(311861,0,"fc76e4660fbac88fa2baa81ee53bf4c3f4a6f2bbea74bd42cdbc1f0b2a850afb")
setManifestid(311861,"3087064667638749873")
addappid(311863)
addappid(311862)
addappid(340661,0,"17ea499d61ed126e8495c0d7f0011cd523e6399b7cc549dcfe04039db929447a")
setManifestid(340661,"1732829467474465749")