-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2301210)
addappid(2301211,0,"60cc0e4be0ac791d9e64d250967c563fc44f463d0abda3ec21ce94a46a8f8ce1")
setManifestid(2301211,"7777312817554088400")