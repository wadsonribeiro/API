-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1284240)
addappid(1284241,0,"14321934e4da0f71bd5e7b8b7993a16e5058be97387a72af4eac4b94ab565fbc")
setManifestid(1284241,"7462899222230908990")
addappid(1284242,0,"7f4216a606bcdac32fde0c0360e670f528ce3b0a1235c570787418bccccd7a33")
setManifestid(1284242,"6634269325730909554")
addappid(1284243,0,"7a6893e35a04bc48ac7ebc3668bf6d57f363c9fec09b975c34e2aac2ae962cb3")
setManifestid(1284243,"1804035960000474871")