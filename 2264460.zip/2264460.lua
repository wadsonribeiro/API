-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2264460)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2264461,0,"c813c010d66f1f64d99ebc21bcb6b7bcc255b40e24e434ef63eeb68ed7f79f26")
setManifestid(2264461,"5100856849165578862")