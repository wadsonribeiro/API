-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2164430)
addtoken(2164430,1297456240578370387)
addappid(2164431,0,"59e6193cfb81d063c76b5bb81a2de23df4cb8d76fd9493444dd2aef9820d3e40")
setManifestid(2164431,"6822418169626790284")