-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(302380)
addappid(302381,0,"8e5119e90726fc95842985c103b7abee4e4089ffc1cbe38025468ad457ae814d")
setManifestid(302381,"751226053034886819")
addappid(302382,0,"e00b4976fdc1a922bb623513950bf00415f21e3acd5e76e21bff2fb07334ccef")
setManifestid(302382,"4669346902860974874")
addappid(302383,0,"781e961b2e35c6eb76d18bed6d583163817a5193d1397c45e0e1a5b657f0736f")
setManifestid(302383,"2961843504902116291")