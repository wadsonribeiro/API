-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2259220)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(2259221,0,"bbd64003d3e0c7af948ba92154cd1ffaa3c0f2dc0c720079eb84f9a0748107c9")
setManifestid(2259221,"1169254118336062127")
addappid(2259222)