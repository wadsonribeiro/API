-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(570780)
addappid(228981)
setManifestid(228981,"7613356809904826842")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(570781,0,"a212409474ac059a4bd0de6f78c80e44daff087ff475cba093b874f2b0cf4bb5")
setManifestid(570781,"8877140608368440086")
addappid(570782)