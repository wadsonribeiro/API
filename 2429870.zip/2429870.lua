-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2429870)
addappid(2429871,0,"cf828864cfa61a8f8b0f6ec7067eada7c180d74e33627b282b336243c0270292")
setManifestid(2429871,"5421217093576198736")
addappid(2429872,0,"3fef517d82308924710e53570c6ff94f4420efb3995f89ca3dabac6771abbc49")
setManifestid(2429872,"3949874839281641706")
addappid(2429873,0,"f8f1f03737e1d310eee3ce38c1d400488b99859a69ee9b5f580252baf39d0c42")
setManifestid(2429873,"2807806851646108928")