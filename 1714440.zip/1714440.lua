-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1714440)
addappid(1714441,0,"3d83800ddfcb3abf88945c06d8e9d5ed27df883afba099f7f42409d5e04d243f")
setManifestid(1714441,"7202277118410342398")