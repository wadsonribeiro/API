-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1244510)
addappid(1244511,0,"44064b8770448a30c9019a5391b77c242c84744e5e7fd0bd79be31ccead4ca93")
setManifestid(1244511,"3012953661216009310")
addappid(1244512,0,"b80fddcf1a2e85662e13252fa2f4aec9540ba16540f6559ccea2ed0aacbf4d10")
setManifestid(1244512,"9170298407502747918")