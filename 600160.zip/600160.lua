-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(600160)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(600161,0,"14af86643fa3e68f2aa748d453cef0b51ce6cc74d06c49f6de950cec052c948b")
addappid(600162,0,"759633425737a478d146375b416efb0bfed16d06311e4dad603cee57183821df")