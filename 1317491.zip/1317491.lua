-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1317491)
addappid(1317491,0,"0dfb5d4d99eddd8c9858f8a41c10eb59cc830e2daea03ea16f3e7d0d16a53f8c")
setManifestid(1317491,"3743121837014161839")
addappid(1317590,0,"1ded82cfca7788b1b40e5618947dbecd6846993bd0439b672ed6ffe2d6be4bd9")
setManifestid(1317590,"2801812046321972300")
addappid(1317591,0,"0f1d8e0f02323c14fcd9b833ff607a322a07bccf28f6d67fe988ca7386bc5c9c")
setManifestid(1317591,"7374641775798710616")
addappid(1317592)
addappid(1317593)
addappid(1317594,0,"f8ea2790f3cdb395998edd5d0c23d87f93c8de268f4e65ea20917f0aac4946c6")
setManifestid(1317594,"3570641932725596620")
addappid(1317595)
addappid(1317596)