-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1161870)
addappid(1161871,0,"3b5bb1ccaa5784b49ae8a3e99ffb595f086d6cd431463998cda90f5e826d7c4c")
setManifestid(1161871,"1476010365815920548")
addappid(1227170,0,"78eb1e62e670960676b840f2898f5f3901de14ee0537e4d1e41fb2eec3e1cf17")
setManifestid(1227170,"6318936913310117347")