-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2012640)
addappid(2012641,0,"70baa27966c1b39f6dc07bdf7bbeba675f3379d51caf86cca218715353ca4dc5")
setManifestid(2012641,"379440152049790553")