-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3065790)
addappid(3065791,0,"d2394988a819ec37f57c498a5f0b04c3ffa659f359bdeae45db54b34b0c9c4ac")
setManifestid(3065791,"1626720029095827531")