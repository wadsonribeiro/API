-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(287440)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(287441,0,"ad651fc1699980f55566252d54f5ceb744621c44b666f837851e4cc5ced3236d")