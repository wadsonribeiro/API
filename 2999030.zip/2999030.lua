-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2999030)
addappid(2999031,0,"8b8386310bdef28e1d892fac876e1fb231ab87901d9cc711eb0f5edcacacb836")
setManifestid(2999031,"6891934237537380301")