addappid(1342490)
addappid(3766270)
addappid(3766280)
addappid(3766290)
addappid(3766300)
addappid(3766310)
addappid(3766320)
addappid(3766420)
addappid(3766430)
addappid(3766440)
addappid(3766450)
addappid(3766470)
addappid(3766530)
addappid(3766550)
addappid(3766560)
addappid(3766570)
addappid(3787730)
addappid(3817280)
addappid(3817290)
addappid(3817300)
addappid(3817320)
addappid(3817330)
addappid(3817340)
addappid(3817350)
addappid(3817360)
addappid(3817370)
addappid(3817390)
addappid(3817400)
addappid(3817410)
addappid(3817420)
addappid(3817430)
addappid(3817440)
addappid(3817450)
addappid(3817460)
addappid(3817470)
addappid(3817480)
addappid(3817490)
addappid(3817500)
addappid(3817510)
addappid(3817520)
addappid(3817530)
addappid(3817540)
addappid(3974080)
addappid(3974090)
addappid(3779150,0,"7f846f37bcfb01890a3bf2c2a91724c2342f38d3085da2354f573476227b405b")
--setManifestid(3779150,"951698471833675111")
addappid(1342491,0,"c6540bdf8c309fb168778b2fbe5a1f6fd5802ca36eb9ac410f78e2bce2d4b57f")
--setManifestid(1342491,"3441974307937026626")