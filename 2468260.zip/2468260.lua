-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2468260)
addappid(2468261,0,"9aee5b18f7cc6edd7f9a2ae26689c0e1d0faad3894db3d5a027869ba4e282a0f")
setManifestid(2468261,"7075302437682831363")