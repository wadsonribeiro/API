addappid(3949290) -- Ys X: Proud Nordics
-- MAIN APP DEPOTS
addappid(3949291, 1, "d0d80228ab18573e394fbad3b4b594ed136caaea01a0018c11f5c6d5dd7f1921") -- Depot 3949291
setManifestid(3949291, "5703632458595102503", 8318422046)
-- DLCS WITH DEDICATED DEPOTS
-- Ys X Proud Nordics - Isle of Seiren Mascot Set (AppID: 4360500)
addappid(4360500)
addappid(4360500, 1, "5cc8ae3c422f352bf863f9f5d5375e08e13f04aa958aa931b9c75224f3fd8e65") -- Ys X Proud Nordics - Isle of Seiren Mascot Set - Depot 4360500
setManifestid(4360500, "6942946786323120547", 0)
-- Ys X Proud Nordics - Balduq Mascot Set (AppID: 4360510)
addappid(4360510)
addappid(4360510, 1, "b79b40ea64804753f8889f141e890777506b935a5581ebeb9b9a9c349b9a5912") -- Ys X Proud Nordics - Balduq Mascot Set - Depot 4360510
setManifestid(4360510, "4554454394152832934", 0)
-- Ys X Proud Nordics - Freebie Set (AppID: 4360520)
addappid(4360520)
addappid(4360520, 1, "2901901b11ec3ca86ecc8686e471b11b40c79be8865d71a12fcc2ce18540466d") -- Ys X Proud Nordics - Freebie Set - Depot 4360520
setManifestid(4360520, "8070916009776487170", 0)
-- Ys X Proud Nordics - Costume Pack (AppID: 4360530)
addappid(4360530)
addappid(4360530, 1, "67eb82744f89f1fb0ee46a6c67eaa400f2f6cbee4c947e00eb14f3d63ee9b299") -- Ys X Proud Nordics - Costume Pack - Depot 4360530
setManifestid(4360530, "5071719528936885914", 0)
-- Ys X Proud Nordics - Sandras Pack (AppID: 4360540)
addappid(4360540)
addappid(4360540, 1, "4f6c9b71446facb92e40e481543837a0f6a1da71327bd97e3fd1376075b23585") -- Ys X Proud Nordics - Sandras Pack - Depot 4360540
setManifestid(4360540, "7028733845523510377", 0)
-- Ys X Proud Nordics - Starter Pack (AppID: 4360550)
addappid(4360550)
addappid(4360550, 1, "9739c03fd27ae0577014559c4a87df540c13ccd33ac2a10838173f8575b6601a") -- Ys X Proud Nordics - Starter Pack - Depot 4360550
setManifestid(4360550, "5654394984709247232", 0)
-- Ys X Proud Nordics - Intermediate Pack (AppID: 4360560)
addappid(4360560)
addappid(4360560, 1, "1167bc6a2f8e9be20c220a42e5c8f6ad00da9648a0f169ec8a6a9c1dfdbc1ce9") -- Ys X Proud Nordics - Intermediate Pack - Depot 4360560
setManifestid(4360560, "4987141314910204989", 0)
-- Ys X Proud Nordics - Advanced Pack (AppID: 4360570)
addappid(4360570)
addappid(4360570, 1, "fc3355fa7b0b39008d938ab20d806dfaee14731cf4a6d097fbe70e37868fa7e7") -- Ys X Proud Nordics - Advanced Pack - Depot 4360570
setManifestid(4360570, "8179494025301155894", 0)
-- Ys X Proud Nordics - Mini Art Book (AppID: 4360580)
addappid(4360580)
addappid(4360580, 1, "471ec4cb6990e5e2916e814f392d41fe9dac7874b93087361804af9456750485") -- Ys X Proud Nordics - Mini Art Book - Depot 4360580
setManifestid(4360580, "631926832490011298", 38393370)
-- Ys X Proud Nordics - Mini Poster (AppID: 4360590)
addappid(4360590)
addappid(4360590, 1, "d2b87b93536c6e06806a109c0320b362af7757bf6f1f2b0a8a92a2f5e9350af9") -- Ys X Proud Nordics - Mini Poster - Depot 4360590
setManifestid(4360590, "1680953349918251382", 15488848)