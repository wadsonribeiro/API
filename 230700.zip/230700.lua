-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(230700)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(230701,0,"1495bee7fdfce903697c1b4fed277a0c235d79ec99d56778b2908241c8dd4e55")
setManifestid(230701,"849931476712452120")
addappid(230702,0,"6009d51196d35a931ad40719a072d31880e1d680e866bab99994533768e72dd8")
setManifestid(230702,"2271186099936044047")
addappid(230703,0,"fd2c6241a498e6b05fcda1bf6b710a21c48b9afbf06ff4e01294de7ec26e4271")
setManifestid(230703,"3953156145743629465")
addappid(1281900)
addappid(1279250)
addappid(1279251)
addappid(1279252)