-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2971920)
addappid(2971921,0,"ae017c7fc02bef5c2870aaec7ed0c2401336e55a3c9cb6d0eab9cbfd279629ba")
setManifestid(2971921,"2710516134369899335")