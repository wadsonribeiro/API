-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2437880)
addappid(2437881,0,"a1219d6c8cdb271d0bcb07e992645f5c743f0d17e898f195c2394228ccaee92b")
setManifestid(2437881,"2175563785688487583")