-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3489690)
addappid(3489690,0,"320a1dbbb4df1a88789b0cd16767222f25ee94e1a7580a7101e730d2ea8eae0c")
setManifestid(3489690,"6393352586855729878")