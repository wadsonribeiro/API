-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(375320)
addappid(375321,0,"56f5ae1affcc64c5dd5fa3d217b6164db71b82e0859f20bf8c2c1d9e32f05ce4")
setManifestid(375321,"8690827031433587025")
addappid(375322,0,"7ded5a788a0f74b43d414cdede765ead32df74d2fcc070cb1253a7020c346356")
setManifestid(375322,"1880347652317536438")
addappid(375323,0,"f06bb7723e5761c29e381f2643d8b17587fe593d8c08e861e4d616f05fd11dac")
setManifestid(375323,"8997163268938164220")
addappid(375324,0,"47a69cfd3a0fb2fae6318e818a99eee8c0729abdcff8ed23daf7f1144f0f732a")
setManifestid(375324,"1147977477203500160")