-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1802950)
addappid(1802951,0,"fb657f699fe25481ccf0b823d1af4cba436fe4fe09df22d53afc56de0090f685")
setManifestid(1802951,"5506586106801962629")
addappid(1802952)
addappid(1802953,0,"cffc63ef1af1ff047f7d54f5aa054f97ec0a0aebabcfb7d6e8ef73bfd32915e0")
setManifestid(1802953,"293429065620719609")