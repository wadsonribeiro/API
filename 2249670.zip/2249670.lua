-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2249670)
addappid(2249670,0,"ba19afd01a4ba4c1fa503aae33bb5287a1427806032f3f9541c587060e0aaa88")
setManifestid(2249670,"3894543063390602840")