-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(331790)
addappid(331791,0,"b5bbd83176ea6a0a6adc50d812ec132de54a43c339e2ea386b1a5bd61213a0ce")
setManifestid(331791,"8216777050545959799")
addappid(367250,0,"22fd0771634dd63cd5e3e413962ddc129e814f2911240661e1a89337e68b9f92")
setManifestid(367250,"9094809948422590089")
addappid(376530,0,"c439e292cae4a0800d935ae5580c054056ac4af044d6b730860256ed467e0d44")
setManifestid(376530,"119582299521704477")