-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3345230)
addappid(3345231,0,"1106da74ae8c19a0f5cbe83e7f6d857d2d02135bf9dfb26bcf14c80482a07afa")
setManifestid(3345231,"7049020760055571310")
addappid(3345233,0,"222f95ecae669474af21d5848ec3f6041130aebdf16d139bd00a3aeac63ce51f")
setManifestid(3345233,"6367156545543275960")