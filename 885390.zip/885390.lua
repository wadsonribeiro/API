-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(885390)
addtoken(885390,12881993187721358444)
addappid(885391,0,"4c2fc559882e7a1efbdeff1e8128901e64c51143e7a81452d0031eaf2c6887e4")
setManifestid(885391,"6339739506420385210")
addappid(885392,0,"d95d05892406d52bcc180c4f604759be236d7e72d6f3b9f729d555bfcb7d688e")
setManifestid(885392,"7494292274254774200")
addappid(885393,0,"6e3c22b1dc858be7c940f23daa884834116eed9fca11c7e5434e28fba9e42974")
setManifestid(885393,"7395697490826243444")