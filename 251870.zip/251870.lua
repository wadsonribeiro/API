-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(251870)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(251871,0,"4e40d60aaa1a9d674256647afaf13eb38293ee8bb58c9ab4472e6416c0a5b013")
setManifestid(251871,"5993284922428924190")
addappid(397030,0,"904236b024cf656685515d6f539cb0067511d8c6212cf7945c2af980d426d4e3")
setManifestid(397030,"6406181565234059677")
addappid(534840,0,"2fe242a4925a8594cd0c405886e171c66959cb2cb24f1cb06acc1255488fbddf")
setManifestid(534840,"2560990693287073466")