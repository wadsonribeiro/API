-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1473990)
addappid(1473991,0,"ad67df13d452b8124904173d542b03243aae5a58b0214aa9d2b507357561ac0e")
setManifestid(1473991,"5713113474549727841")