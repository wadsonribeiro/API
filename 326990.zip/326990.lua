-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(326990)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(326991,0,"e4754df44010162883347eb614ea4db9fbfb729f87d40ab0cfb7eb9b9477a877")
setManifestid(326991,"1488544606963559964")
addappid(326992,0,"24a5947c51a4e8cde352f98b80caf616b164a6a884aa22997c3165da143daa50")
setManifestid(326992,"2543683165412472426")
addappid(326993,0,"932b9da02bb7a6ab673a00cdd6d1cdbc991e960f31378df54e499cee4427c1a8")
setManifestid(326993,"2198408421159721246")