-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(598980)
addappid(598981,0,"5eef890e869bba07fb135158a507ede6b276453d706d5c4e36f2ac5a66e43963")
setManifestid(598981,"3495409927232323908")
addappid(598984,0,"8cd74454dd76b1413f9e9edce77dc07524709e46e9cca1523699953c636ad7dd")
setManifestid(598984,"8268134536508433387")