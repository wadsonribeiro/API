-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(680700)
addappid(680701,0,"21fa13cd367fc4d49fbfe26eea9029dd359407bd2577ecc683ff7fc8480c2e8b")
setManifestid(680701,"6412751106392775585")
addappid(732700)