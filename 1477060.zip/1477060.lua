-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1477060)
addappid(1477061,0,"b0b7ce194617b7723c96ed969a0aacd2fa53ae60572c9ce2da017eb042d8f75a")
setManifestid(1477061,"9004673269038783403")