-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1093740)
addappid(1093741,0,"b5412e46bbc207cafc3c146d7af81ea39c2b2a7a36cd23d40009a1a57f90277a")
setManifestid(1093741,"7420234798992152605")