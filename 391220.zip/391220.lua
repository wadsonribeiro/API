
addappid(391220, 1, "471c9dc9264dee70d998fa09da81085cbd8635f7eac85e0aad3037c29c26510a") -- Rise of the Tomb Raider
addappid(391221, 1, "4b20550dff2d439457b19fd7ce04667d20b9b234e8be4ef0284632a2b99cfdee") -- Game Content

addappid(391222, 1, "f4e85421721124a989c839016776ff38b30720aa7f8a2f31abc68109641ae515") -- Executable
addappid(391223, 1, "548e5f09aa216df75d9c5e329210136ead85abe8669a6dd6a10448226e595028") -- Debug
addappid(391224, 1, "ad3fbd6c645319a5728681f01632e85945306f0c8243bf624e34e1a9d652d38c") -- Game Content English
addappid(391225, 1, "a6fce33f31f484aeb2c88a1291f51b72312c52d896f18e6961233d96b9ff0e99") -- Game Content French
addappid(391226, 1, "bb3ebded5e09339b7a508658189823d1ce6006586cabab468cf5b0b530b3ea1a") -- Game Content Italian
addappid(391227, 1, "b484c6cd699f5beb0442f75791501057cdd1f0653489e87df1f3a4950004b2d8") -- Game Content Spanish
addappid(391228, 1, "9288004613d2c8b604f3605ba3bb75cf5955f1c6cf9690852bc93a8b6be9309c") -- Game Content Portuguese
addappid(391229, 1, "f9a8112598b324236b84c4c202d0344c0073d4ca6331e33a4923d59019fd9d50") -- Game Content Russian
addappid(391230, 1, "077e6fc47932216765677778caa4fe0aaa3020f7d866426af20e2ce9032f08d6") -- Game Content Japanese
addappid(391231, 1, "0848f2ab802a10ecc63fa98d4e3303f31c34c045291d1dab4430a7556bca10c7") -- Game Content Korean
addappid(391232, 1, "fb22852277547a64f7cac5aa0d058b4078dc1ac29c38e630fbfb815f27aa0dc2") -- Game Content German
addappid(391233, 1, "930d4adf23dd7ee05c1d9f169d6f162c77472295d265b5e16aaa469f1ecc1942") -- Game Content Chinese
addappid(391234, 1, "9661bcee9bdf0ff25f0d2b24a078a8d348a4edd5f1404863bd1af3fa996f651a") -- Game Content Simple Chinese
addappid(391235, 1, "432e46edaec0522daf64ae73158b9d2323459f9c20cd7636f12bf2f418b10deb") -- Game Content Polish
addappid(391236, 1, "e79951c00f7b7dd890bf7e80937f3fd66b86e48758e04f3aa34b1583998d0ef4") -- Game Content Dutch
addappid(391237, 1, "edcccc4fa0af04b22875e776489ad0eb5a1fd589faa5e5b444632d2a4881087d") -- Rise of the Tomb Raider LAM Spanish
addappid(391239, 1, "8808e80de68e7a918f1695a4cef456cea509d4a22350f7c524a38e9e2c72160d") -- Saudi Arabia Overrides
addappid(406201, 1, "a0d1cf061376d1e3eb1255c7fc027146c8c5d7476bbc32f66b9c050759eea2fd") -- Mac - Game Content
addappid(406202, 1, "08d992706b86c8607ba23e2f025b2d4420e4376b2ddba8df16982418a712f180") -- Mac - Executable
addappid(418681, 1, "e960dc7686411545b722858ee2cc4f19ee94f52afaeddd5db89436a016249f03") -- Mac - Apex Predator UK (418740) Depot
addappid(418689, 1, "9e478cbdcff5b5c94dd6f44611f5eccf34c237daa1006f3c64a102b46c57e3ec") -- Mac - Air Drop (419100) Depot
addappid(418691, 1, "dd9118c8f999c83857f43354acd0bda0f517bbf1bc3727f6bc22d6944371d20a") -- Mac - Game Content English
addappid(418692, 1, "30fd2d444a9cec549365dfe508273fb59d9f626ea15bc016d9d62c6dd4046814") -- Mac - Game Content French
setManifestid(418692, "17026752736112632", 846171132)
addappid(418693, 1, "dd7cb480b627a87a4a280984fa238126b64dd310e145922c054da9b98a3abe78") -- Mac - Game Content Italian
setManifestid(418693, "205345161368202436", 856412156)
addappid(418694, 1, "ca091b3f878892f67a637df2b65de023e9943b3eb33a3fc467430baf0a35d8a6") -- Mac - Game Content Spanish
setManifestid(418694, "169309165006712900", 858033212)
addappid(418695, 1, "2ff342de1b8cb6f914198416aae7a81277073d365488b2dbe02746589b829161") -- Mac - Game Content Portuguese
setManifestid(418695, "159807319806050175", 854303516)
addappid(418696, 1, "55153502b126e93b241cbe0ab4db07f5cc6bd267ceabb2eef0a8c4f90481a053") -- Mac - Game Content Russian
setManifestid(418696, "287462484679590851", 838812636)
addappid(418697, 1, "df35260bf0552febd959a10a27374d80836dce4f6a62030ed829b1e5834116c1") -- Mac - Game Content Japanese
setManifestid(418697, "24259875548083893", 855682104)
addappid(418698, 1, "7ba576616544db98408a4c1ae0196e4930ad944c948320844f0a29e009f0997b") -- Mac - Game Content Korean
setManifestid(418698, "358921103046038785", 836482044)
addappid(418699, 1, "56c968fdb63f4125df54f2cde07383b58ffc8a5263ecd875f3e1bab40f458b47") -- Mac - Game Content German
setManifestid(418699, "23918736631012744", 840141420)
addappid(418701, 1, "aa45c2047058a9db25538fda4ee9bff970df03971c1976fe44023dc640fb7825") -- Mac - Game Content Chinese
setManifestid(418701, "484963426894976687", 850650524)
addappid(418702, 1, "110fb217efd40272e947715fc1cc35258b0d9c93e60eac7e1d60e9167b8cf26e") -- Mac - Game Content Simple Chinese
setManifestid(418702, "55177290492148553", 842982508)
addappid(418703, 1, "6b2daf7ceac1b773de79973a25e9b7cddf9e6b15e2d3150b31802f8cb82ee3ac") -- Mac - Game Content Polish
setManifestid(418703, "146868625520025557", 856990444)
addappid(418705, 1, "07b4911df615f12362f76a854ff76b7ffe48a4abf5dbdda68cf2e39578b95574") -- Mac - Rise of the Tomb Raider LAM Spanish
setManifestid(418705, "659327018627932221", 856261740)
addappid(418707, 1, "8e0cb16176db44623e506fbcee81bbbe02d4276eda278f290a044845e18a95b9") -- Mac - Saudi Arabia Overrides
setManifestid(418707, "6272051870745712588", 187277188)
addappid(418711, 1, "259dcc42a20941078d42a146d1e54f093920cdc5219ddbde5c618b0f52ea43d6") -- Linux - Game Content
setManifestid(418711, "5640750343099000175", 20471816605)
addappid(418712, 1, "3e81a7630dab83f4fe90892999d11b0b9b6f739e6576f0b3da1340e61a307dfb") -- Linux - Executable
setManifestid(418712, "7392977764999912661", 366801058)
addappid(418718, 1, "1b271aebb2d440063ea3f6670ffe1a1b4bdac8d3d0edadb4b6d6f2b54dad3990") -- Linux - Apex Gamestop International (418730) Depot
setManifestid(418718, "12374941091954185", 387)
addappid(418731, 1, "aa364a0c4c8810e7687625846aa30f55681830b4747a221f4afa82e77e37639c") -- Linux - Game Content English
setManifestid(418731, "19708515709860292", 864015276)
addappid(418732, 1, "d9b47eea35183d2ba23d86e6523f3eb833a555e7a19d9bff7b992b9b89c19ea2") -- Linux - Game Content French
setManifestid(418732, "220152240934282361", 846171132)
addappid(418733, 1, "32f80c8acc8ccfcf77c365e6f1db19b543c52491e6cb63bf16520814e3a5c0f1") -- Linux - Game Content Italian
setManifestid(418733, "194460484124545610", 856412156)
addappid(418734, 1, "21df8c59d28fc767df88686838750c640cf4f09af12872d5953e94565ceec68a") -- Linux - Game Content Spanish
setManifestid(418734, "15774690292967377", 858033212)
addappid(418735, 1, "f6c7979995cdd3b2263b61d06dd6e4ec784b5a9193640d2ddf6ed37d341395b7") -- Linux - Game Content Portuguese
setManifestid(418735, "444076963789533616", 854303516)
addappid(418736, 1, "6beb3be0fc37cb290a92b6e3384073c9fdf099da996f42023a46271a03216f27") -- Linux - Game Content Russian
setManifestid(418736, "667678225186524344", 838812636)
addappid(418737, 1, "ff2ff3a74eb776ef8afe5ac57c86a8f7d92cfbcc991c1a967051dcda395953e6") -- Linux - Game Content Japanese
setManifestid(418737, "231418129521000173", 855682104)
addappid(418738, 1, "d4e76f0c1f80db95e5096a4d141870813a7a8a9fb693e0ba92a9e961fa410861") -- Linux - Game Content Korean
setManifestid(418738, "213576900245979111", 836482044)
addappid(418739, 1, "804655c1bbf3ca5a9861c5c104abc359adecd0e500a33bc90cb5abda80d6bb97") -- Linux - Game Content German
setManifestid(418739, "498821977448874064", 840141420)
addappid(418741, 1, "b16060cce2a0539938190cb184ebc7e041846dbbe0ac386bb677b511430b7f8a") -- Linux - Game Content Chinese
setManifestid(418741, "284893599092064941", 850650524)
addappid(418742, 1, "815815fb22bbd2ab04d8e712b4d28a77711241664f55f1d974bc3bf88a943458") -- Linux - Game Content Simple Chinese
setManifestid(418742, "182010283594917688", 842982508)
addappid(418743, 1, "8c431f3e05adc445a799f99d14d5cc4d6e750925cc90d62551cba9e1da769d15") -- Linux - Game Content Polish
setManifestid(418743, "333814133725336179", 856990444)
addappid(418744, 1, "afd230813dff1a2743914318d0e35b62cc132626a739a36f2011d2574c044141") -- Linux - Game Content Dutch
setManifestid(418744, "5674783858863345085", 0)
addappid(418745, 1, "50113df47ee173976f5b6afdd2cdaf20d2ca5365f9c0681eedb85210d382ed5f") -- Linux - Rise of the Tomb Raider LAM Spanish
setManifestid(418745, "356187523817903614", 856261740)
addappid(418747, 1, "00a7b1527bfd42eb26b9dbf586abeb178eb28417966f147ffff9a5d76f003f64") -- Linux - Saudi Arabia Overrides
setManifestid(418747, "312637269899635799", 187277188)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Sparrowhawk Pack (AppID: 418680)
addappid(418680)
addtoken(418680, "12301003022257728778")
addappid(418680, 1, "c334c6d817272df8958fa655d8095ba4fb1cfca2e0d640e9cc745068054a5786") -- Sparrowhawk Pack - Sparrowhawk (418680) Depot
setManifestid(418680, "378942671148969575", 371)
addappid(406207, 1, "67060caf396b70bdb7ef2173b63b7db69b3ffe82e131ae2e39b3e77c881c57ba") -- Sparrowhawk Pack - Mac - Sparrowhawk (418680) Depot
setManifestid(406207, "207342535593864879", 371)
addappid(418717, 1, "a3b4c26bec81c06ff9f7fe150854b577cde304ad6f74c5e6f8f033c5cf8339cd") -- Sparrowhawk Pack - Linux - Sparrowhawk (418680) Depot
setManifestid(418717, "196087258367907", 371)
-- Hopes Bastion Pack (AppID: 418690)
addappid(418690)
addtoken(418690, "14257662420320135979")
addappid(418690, 1, "cee2a48588ab6a3a3149a6590b713a78a68ee52e6287f579623fd4191ee56944") -- Hopes Bastion Pack - HopesBastion (418690) Depot
setManifestid(418690, "65115631254540684", 375)
addappid(406205, 1, "4928e7bc8c8cb1829af32c993a40e0e1e83ef9b40171c4c465ed840e72912cf6") -- Hopes Bastion Pack - Mac - HopesBastion (418690) Depot
setManifestid(406205, "92092700736411187", 375)
addappid(418715, 1, "380b5162513d58b9e500821357fd16baef22e0a09da054e7a5d6e7e408f122e6") -- Hopes Bastion Pack - Linux - HopesBastion (418690) Depot
setManifestid(418715, "54789389209863147", 375)
-- Tactical Survivor Pack (AppID: 418700)
addappid(418700)
addtoken(418700, "18405081464328861625")
addappid(418700, 1, "0ddef51c1e14d68cdacddc47dd2874fb82d267220354224a5570616f5aaf9e6d") -- Tactical Survivor Pack - TacticalSurvivor (418700) Depot
setManifestid(418700, "898782230419067554", 397)
addappid(406204, 1, "915d3a08f592faab9d9337d28ca3dea185cc7c0ce3bb4d2f10049d489ef896ed") -- Tactical Survivor Pack - Mac - TacticalSurvivor (418700) Depot
setManifestid(406204, "235011932828729614", 397)
addappid(418714, 1, "41beeafbece0ae3c02fdd751da9be951ad1a4b78bd9f9366ae8b3f33d39b7a90") -- Tactical Survivor Pack - Linux - TacticalSurvivor (418700) Depot
setManifestid(418714, "65951016426039747", 397)
-- Apex Predator Pack (AppID: 418710)
addappid(418710)
addtoken(418710, "17593108361864258591")
addappid(418710, 1, "a6fa76e87a255ea8377abb69a068ac207ad3e9c4799620795df58e8fc34eed7c") -- Apex Predator Pack - Apex Predator (418710) Depot
setManifestid(418710, "51443339483951151", 387)
addappid(406206, 1, "6bbe32863c03f88b9ba74fb1c8dbb0d95d8e72dd936c13ef1f512b11302eb5bd") -- Apex Predator Pack - Mac - Apex Predator (418710) Depot
setManifestid(406206, "86883524746510348", 387)
addappid(418716, 1, "4ba71f22c4c14e549bf8156fac1e74ebb0aba53743969ce7a7b72e6cd52c89b4") -- Apex Predator Pack - Linux - Apex Predator (418710) Depot
setManifestid(418716, "255044434464154730", 387)
-- Wilderness Survivor (AppID: 418750)
addappid(418750)
addappid(418750, 1, "38b7e58955acd182e5cb9876b6c3b062227feb7005f5b19445c079eb996d67fc") -- Wilderness Survivor - Wilderness Survivor (418750) Depot
setManifestid(418750, "4490860606175189512", 426)
addappid(406209, 1, "418d1a3cd9097968c6950e02af9250f2c2142479d2c1865504f52b1bb62d2f53") -- Wilderness Survivor - Mac - Wilderness Survivor (418750) Depot
setManifestid(406209, "165830735221096045", 426)
addappid(418719, 1, "0447ca019b5295eb38ae4c9bf94a3532b3f71e96b88d274c1c1f5cabc43de9be") -- Wilderness Survivor - Linux - Wilderness Survivor (418750) Depot
setManifestid(418719, "190060527985473319", 426)
-- Siberian Ranger (AppID: 418760)
addappid(418760)
addappid(418760, 1, "dda476c21b84d2eb6d98b34870ace2798f7ef92f6320a69ac29aeea4a3346c10") -- Siberian Ranger - Siberian Ranger (418760) Depot
setManifestid(418760, "9102585270140874084", 418)
addappid(418685, 1, "99bbb595d0c990894be2f2ca44ed81638c5d9ca7330b184d9587067c4caf8ee2") -- Siberian Ranger - Mac - Siberian Ranger (418760) Depot
setManifestid(418685, "688684846377209851", 418)
addappid(418725, 1, "77990b748498ee69a62afaed827c69329643af283d4a849161d998466d8c4685") -- Siberian Ranger - Linux - Siberian Ranger (418760) Depot
setManifestid(418725, "87354691823539208", 418)
-- Ancient Vanguard (AppID: 418770)
addappid(418770)
addappid(418770, 1, "4bec24bf67a9f50aeee6d1f2274b524dd02b54ea06cfa22e78b7d1bae7522585") -- Ancient Vanguard - Ancient Vanguard (418770) Depot
setManifestid(418770, "8227735745325821939", 430)
addappid(418684, 1, "93e03d950ef1f5c21febd58578c1b0168913fab19d24e4fe3c91d17f9edd8d92") -- Ancient Vanguard - Mac - Ancient Vanguard (418770) Depot
setManifestid(418684, "234748042072976737", 430)
addappid(418724, 1, "e7fa30198e5249aa3ee684eb818c07b51a8d97e629a81de18b9aacc49ea15d4b") -- Ancient Vanguard - Linux - Ancient Vanguard (418770) Depot
setManifestid(418724, "1332933314892876", 430)
-- Prophets Legacy (AppID: 418780)
addappid(418780)
addappid(418780, 1, "7a99ef0386046a7684afb7f47db824a0e22e39d978dc4b8acf00c2cf5976d0d5") -- Prophets Legacy - Phrophets Legacy (418780) Depot
setManifestid(418780, "7818447123364089517", 414)
addappid(418683, 1, "e8367b40c7b921edeb0150c39af5d1455ec0fdad64ce7b1c9d27425d94605f3f") -- Prophets Legacy - Mac - Phrophets Legacy (418780) Depot
setManifestid(418683, "755832660793684514", 414)
addappid(418723, 1, "c940a65ca87057b0c95915bce2f1ac4ac456a66ea209da921e0d7b2c77139e1d") -- Prophets Legacy - Linux - Phrophets Legacy (418780) Depot
setManifestid(418723, "292573332135546896", 414)
-- Endurance (AppID: 418790)
addappid(418790)
addappid(418790, 1, "3d690a0e79f9e89b31e14f8a35e8da3a6adf9e852d158b65e8c745b344bff448") -- Endurance - Endurance (418790) Depot
setManifestid(418790, "4863695610568968480", 553832200)
addappid(418682, 1, "c761d75897563507ec608d02a65990977ec0bad94b74e5a91ec110dca3f42911") -- Endurance - Mac - Endurance (418790) Depot
setManifestid(418682, "1028611266795863913", 553832200)
addappid(418722, 1, "776eaa6d50e5535a4c69acc1278a4ab264ace000481de831813f4e90cc0721db") -- Endurance - Linux - Endurance (418790) Depot
setManifestid(418722, "170564897590864783", 553832200)
-- Baba Yaga (AppID: 418800)
addappid(418800)
addappid(418800, 1, "bc37ded59d21226903be042ab971b44ea22b653ce69b8140684a200405ae0bb5") -- Baba Yaga - Baba Yaga (418800) Depot
setManifestid(418800, "1128899172093090204", 1238879151)
addappid(418686, 1, "7b438f31580157b8c12a51de3ac0a2b193af802ba37d098550fe34209cf8a21a") -- Baba Yaga - Mac - Baba Yaga (418800) Depot
setManifestid(418686, "72631022377414561", 1238879151)
addappid(418726, 1, "7fcf9c2295b3c8c6baafd257c73c7dfd3718c760b1cbb79716520f3cf1a216ac") -- Baba Yaga - Linux - Baba Yaga (418800) Depot
setManifestid(418726, "10904134873385159", 1238879151)
-- Cold Darkness (AppID: 418810)
addappid(418810)
addappid(418810, 1, "5b9790e432814942095453c12202e256572ecb17b110879a0c2ad4ffadba99f1") -- Cold Darkness - Cold Darkness (418810) Depot
setManifestid(418810, "9124905136754144422", 618986484)
addappid(418687, 1, "ebb481506e66290a4dccbed95338e42bef1b7986d5d01cae7d6642a415102232") -- Cold Darkness - Mac - Cold Darkness (418810) Depot
setManifestid(418687, "873409895737513332", 616919044)
addappid(418727, 1, "0148b1205f64050634858cabed7c97d39fd666c6396aee6a592d97b7362b4f15") -- Cold Darkness - Linux - Cold Darkness (418810) Depot
setManifestid(418727, "243497959333404937", 616919044)
-- Remnant Resistance Pack (AppID: 419110)
addappid(419110)
addappid(419110, 1, "b2dca5e25e63b9c58d5736b7000b897efa81c670af1b18c4a3a330f7d0a98a0d") -- Remnant Resistance Pack - Remnant Rising 419110) Depot
setManifestid(419110, "4202803323130042", 385)
addappid(418688, 1, "f6b8ee36856cdecef160e929ff3d0dc2cf5c2ab2ef910e7ee4d9074bc03b3530") -- Remnant Resistance Pack - Mac - Remnant Rising 419110) Depot
setManifestid(418688, "57474434102667673", 385)
addappid(418728, 1, "6057c7cc0533e1b098315684d57139fa2c4d12e7c34b1a6b3e8137fab40abb64") -- Remnant Resistance Pack - Linux - Remnant Rising 419110) Depot
setManifestid(418728, "625379033836074028", 385)
-- Season Pass Card Packs (AppID: 437800)
addappid(437800)
addappid(391238, 1, "bc60059dcf545829a337a732d4c545041d08fbbb95982844853596233c3bd0a8") -- Season Pass Card Packs - Season Pass
setManifestid(391238, "5737154611580587931", 213)
addappid(418706, 1, "92f8d506ed9aa845376dfdc30b59474cf4c2bf9d869d6ca8d9c14715c1031774") -- Season Pass Card Packs - Mac - Season Pass
setManifestid(418706, "298905414625688581", 213)
addappid(418746, 1, "2c9fb8a0ce207077400de55a13e5352e5ade0a52f2b839841b84853d85355682") -- Season Pass Card Packs - Linux - Season Pass
setManifestid(418746, "188953858239603301", 213)
-- Rise of the Tomb Raider 20 Year Celebration Pack (AppID: 505540)
addappid(505540)
addappid(505540, 1, "a579b9897694af78f69f4910404eed7d1714f838926af41ad3be9ed5a3344782") -- Rise of the Tomb Raider 20 Year Celebration Pack - Blood Ties (505540) Depot
setManifestid(505540, "280490579396787619", 1897461476)
addappid(418708, 1, "0f32e17ec5b8b87838e7c2d875147b1cc57d26422e0db872ef3c126b1a1a6d33") -- Rise of the Tomb Raider 20 Year Celebration Pack - Mac - Blood Ties (505540) Depot
setManifestid(418708, "451826079657370082", 1893897380)
addappid(418748, 1, "25340f6531fbaaa8db0b0b7adc9f859832098bae3d64ef8f7d22f88d7618248c") -- Rise of the Tomb Raider 20 Year Celebration Pack - Linux - Blood Ties (505540) Depot
setManifestid(418748, "140386892066141374", 1893897380)
addappid(541750)
addappid(541750, 1, "3dd761de5147215c14e567f25111321eb66d5ce04efe45a5694e978fc724c27c") -- Valiant Explorer - Valiant Explorer (541750) Depot
setManifestid(541750, "2547732432675892584", 302)
addappid(418709, 1, "0f9e954abf8bbc9e5be696c94f765d1c0ae348883bb420e47090f40853416dc1") -- Valiant Explorer - Mac - Valiant Explorer (541750) Depot
setManifestid(418709, "519081546379224304", 302)
addappid(418749, 1, "1712973f4e37264b7bb3104eb4af2f02f2da4d7725b461e3bf12755c4d6a69b7") -- Valiant Explorer - Linux - Valiant Explorer (541750) Depot
setManifestid(418749, "73052998062838263", 302)
