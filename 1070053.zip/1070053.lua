-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1070053)
addappid(1070053,0,"c3e3ea09caa4fd97446c4f9642c5e659f7d89f251555b35d49c97d105e5496a3")
setManifestid(1070053,"602253138527284497")