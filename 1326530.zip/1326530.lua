-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1326530)
addappid(1326531,0,"f226013803e45c51d0e87d183d88f99d0d5815a2280cffbb51cb50e06818880e")
setManifestid(1326531,"1638546989099934118")
addappid(1326532,0,"9307f8ff74f654c0df0d04b390b903c31abaad3186536d04df77777c19e73246")
setManifestid(1326532,"347372517839957979")
addappid(1326533,0,"494136da1a9551d2fb37aa3e4f7cf4f040186a42fb306c7cd9de1f618ea71d9f")
setManifestid(1326533,"6343926078982352437")
addappid(1326534,0,"ab89539059433007261f73b2955b8fa7c52de0209dc2071dd7c0370eef1f6425")
setManifestid(1326534,"4189798097380496368")