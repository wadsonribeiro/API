-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2706170)
addappid(2706171,0,"8bac962c79191db607320de0e50e8a4e2ecbe0ae551d23c1c869c3dd541ad093")
setManifestid(2706171,"4300660962314181191")