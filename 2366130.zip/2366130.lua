-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2366130)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2366131,0,"f6d46f01f1affdb38613d74aa1e1bf79f10dcd127b5ba3157ce8346367315266")
setManifestid(2366131,"4790731118762742846")
addappid(3126610,0,"3387884958ec10954eeabf784bb84032a0b9008f5cf0bf64f2672003b43ec7d9")
setManifestid(3126610,"6834073385055533717")