-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1077450)
addappid(1077451,0,"8d68f5b55af2aa7a48aec8927455fa2cd5c50a7f627b47bd0f1cb239b3a9e738")
setManifestid(1077451,"3445137232701666764")
addappid(1077452)
addappid(1077453)