-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2569740)
addappid(2569741,0,"b99b09ce4900e27aa8182212de0d6a0b48e5be981040b083eafee46847358b8f")
setManifestid(2569741,"2501974358022591175")
addappid(2569742,0,"f54cb1f987cc7aba92ad0214385329ad6f33460483ac4a16a29bd840fb305b6a")
setManifestid(2569742,"4957953720875813950")