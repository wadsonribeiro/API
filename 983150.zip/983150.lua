-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(983150)
addappid(228981)
setManifestid(228981,"7613356809904826842")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(983151,0,"e2bde360273ad3f3af808caa270c483b0a0a90bcadcc1673ff5c6a64c3d8e15d")
setManifestid(983151,"527911435527801951")
addappid(983152,0,"0f3a63c36045a8372c6ddf054655640ec45467d4cac8dfef5c45b2e6e9939d86")
setManifestid(983152,"7654068638944749925")