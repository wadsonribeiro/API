-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2102150)
addappid(2102151,0,"0d0a2dbad7c6efb7b550547d20c15e45291edd5f7cb00011b1090c29b0d0dba3")
setManifestid(2102151,"2699698450018635884")