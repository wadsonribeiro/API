-- 2814990's Lua and Manifest Created by Morrenus
-- Screamer
-- Created: March 26, 2026 at 12:19:08 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 8
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2814990, 1, "81996cb61dba4d7c437699a35d4a956b1aecd56ac80abff0d7643b12fd645b39") -- Screamer
addtoken(2814990, "15061794339831788405")
-- MAIN APP DEPOTS
addappid(2814991, 1, "951656b29643ce6814f73241af3c3c14488f2c0f82567cd3bee3c56766fdb971") -- Depot 2814991
--setManifestid(2814991, "3011763130758614119", 32024543108)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
--setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4078390) -- Screamer - Chromed Style Pack
addtoken(4078390, "3432686091981140468")
addappid(4078400) -- Screamer - Iridescent Style Pack
addtoken(4078400, "15907728628561769644")
addappid(4191550) -- Screamer - Green Reapers Customization Pack
addappid(4191560) -- Screamer - Strike Force Romanda Customization Pack
addappid(4191570) -- Screamer - Jupiter Stormers Customization Pack
addappid(4191580) -- Screamer - Anaconda Corp Customization Pack
addappid(4191590) -- Screamer - Kagawa-Kai Customization Pack
addappid(4193240) -- Screamer - Digital Deluxe Upgrade
addtoken(4193240, "14048698191075159081")