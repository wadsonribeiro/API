-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(715010)
addappid(715011,0,"881d0e5310e68ad8a8204de7af81bc280e6240aaa290b2ce4b2e99ee394b3afd")
setManifestid(715011,"5950099319529103433")
addappid(715012,0,"db0ddbc833a1ef1cc678120900c51581e2e417bf17bea488a958dffea3a59b57")
setManifestid(715012,"8588392054285153215")
addappid(715013,0,"e5fb3c90575bd24933d34af9da13b6b98c956cfedbcbe0f9df29c6b8636c55a0")
setManifestid(715013,"5413191321813393432")