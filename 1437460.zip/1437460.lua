-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1437460)
addappid(1437461,0,"5c6dad29eeb42150c4b1c90f0a10d5789994d8eeb115862c1d2a25eb879cf914")
setManifestid(1437461,"1639120493453303512")
addappid(1437462,0,"fba57e0a3650e266680bdde64a1885bc927d873245799f54122dab277cfaa818")
setManifestid(1437462,"3752560325507641179")
addappid(1437463,0,"a8fccd5e8e1a07983b12067183503305ca670206c65cd4f90772ee8d91845313")
setManifestid(1437463,"5478112229006060132")