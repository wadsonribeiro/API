-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1315450)
addappid(1315451,0,"1fc363152898fbb30c83771617a096ebe8aba895ba0b75d75b8f8bdb24c4c4d9")
setManifestid(1315451,"3641304260702781532")