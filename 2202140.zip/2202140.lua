-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2202140)
addappid(2202141,0,"1251e6d34914c7e7a106445f2b397ee32b418e4cc3e098cc5b60e9ba756360b6")
setManifestid(2202141,"1866336197155489700")
addappid(2202142,0,"9835f51057a2dee7f67395198851cca45cf8271223cdd1ee6bf4ef5b2be7b122")
setManifestid(2202142,"7184308624241254197")