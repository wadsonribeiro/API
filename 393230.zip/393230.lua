-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(393230)
addappid(393231,0,"d1961fb5bbe9482ff78841fc24dd817079c07e85a3b3f8136b640fd2c3ae2f56")
setManifestid(393231,"6975481694860262067")