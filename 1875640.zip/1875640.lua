-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1875640)
addappid(1875641,0,"beb40e3eb632378bb0be4e78e725569632441933a952ca9406d368795514dcbf")
setManifestid(1875641,"2155298812294689784")
addappid(1875642,0,"83fd9918a5fa659057698ce8e25e2c10f2e70d6316d17a98d4931346224b9919")
setManifestid(1875642,"4349202887025400628")