-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1410460)
addappid(1410460,0,"09302a9340f1af9debc8f326e038ee2fac241b1c72661076d31f5320dd18868a")
setManifestid(1410460,"3675795718833313531")
addappid(1410461,0,"e75213e1750a8f4a3c89b56955fb87cd23b71b679da8501eb54a22dbab04e9d4")
setManifestid(1410461,"7519132492502343241")