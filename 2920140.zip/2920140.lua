-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2920140)
addappid(2920142,0,"99a96d4997575107789dcafd5fc1595ae6afa35cf5bc7bd04b0d903750968abc")
setManifestid(2920142,"5291220401983868867")
addappid(2920143,0,"431299d544bc7affc29ea2974653ddab35c3510f430884aa9c62ab69b897d60a")
setManifestid(2920143,"2389902232250447477")
addappid(2920144,0,"2d7a32235bf3007b5f95dd5d3b1743dd428756e959c9b40c0b67a69dfaa97277")
setManifestid(2920144,"1920414609220040270")