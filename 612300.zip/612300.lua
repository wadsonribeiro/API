-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(612300)
addappid(612301,0,"b2869e24140c126a6a63aa0051e3f5e35afd31900c9a030371ef5c21c83a4f9f")
setManifestid(612301,"288154925267696080")
addappid(612302,0,"0455c705f430b6f7264c37196d15dc3e5c9a8131f55ea970940c80562985df1f")
setManifestid(612302,"3898919966663970560")
addappid(612303,0,"b8a3f787333bf7d98d815640fffc21123953376e89b739df3da9514eba52fa75")
setManifestid(612303,"6327247140170588180")
addappid(612304,0,"9b06e14ae43558d3fdfeea422afc8c5646cd8e4d794eaa72eff271fb9b6b8375")
setManifestid(612304,"779277377463393480")