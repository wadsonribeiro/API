-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2488520)
addtoken(2488520,17731320530619852544)
addappid(2488521,0,"a2b6d87f86ca0a85031b592070b8a77f88e741eaff207b555ce3dad8eb7d8faa")
setManifestid(2488521,"8110103133700831113")
addappid(2488522,0,"a83d7ae843a8ce85ebbb3cde04b685a0be56036671999c3a43b74a4f25874dca")
setManifestid(2488522,"468187998898867897")