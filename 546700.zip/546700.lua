-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(546700)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(546701,0,"b7b4d1be771a28baaece469e5807bdb415aae9bb242bdfa20c0e7893f3dec2b1")
setManifestid(546701,"8303385514867658461")