-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(759300)
addappid(759301,0,"9d267af7d88841190156c1285cc24003d194154ffee032cf5f3a5450ea1d55d3")
setManifestid(759301,"7688723380396448267")