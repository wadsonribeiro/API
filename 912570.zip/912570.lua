-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(912570)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(912571,0,"0fee296aa361e41f67ec0b4d46a61ca82cf1ddc50bffbb80856d76bc4d7a2fbb")
setManifestid(912571,"2468365614529021507")
addappid(912572)
addappid(1237600,0,"cc5959a3ca11d0d58bc80c2a33c3fa446fc6d24f51ae958296220bee3c37e3cf")
setManifestid(1237600,"145504281859504394")
addappid(912573,0,"1385167787a93e05582293b2986d7c4ff23541e65f09edb245e70f80d25355bd")
setManifestid(912573,"8534697358461907197")
addappid(912574,0,"b841d9e52adccf535ff97904c4f446420591150b99ec9a4236f62fb8d668eb48")
setManifestid(912574,"6111804383521872029")