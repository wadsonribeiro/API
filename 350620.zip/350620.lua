-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(350620)
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(350624)
addappid(350621,0,"302a3334a187ec0154ae4da0a94763ebf54d4c3af29e8cf76aa72127ded07d2f")
setManifestid(350621,"6257928644148821818")
addappid(350622,0,"1dd33a7b67739b0c223d905929e111b280df829accc8ba4a1e7f8b19e3f3f71f")
setManifestid(350622,"4721984597988333291")
addappid(350623)