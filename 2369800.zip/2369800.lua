-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2369800)
addappid(2369801,0,"c27907ff2085b9ee6ebbdb933a4c507ef415933d9064f9de935089f465949159")
setManifestid(2369801,"6798516217062449736")