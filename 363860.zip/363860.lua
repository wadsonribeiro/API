-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(363860)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(363862,0,"95d289db6425849619bee0c01f4ad1a6394913957d879f06484a6ff93384841a")
setManifestid(363862,"2778815742396136400")
addappid(2586060,0,"a26be4be39ded04c4002abfdcd3320daffbaa976a3a7a8af65c2babd18e874a7")
setManifestid(2586060,"6567350903637025109")