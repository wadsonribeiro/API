-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(301480)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(301481,0,"d061416744aa7356cde4abd1ecb81a2b50b34dbcd4e92a1cbdf54a015c7c1ba7")
setManifestid(301481,"4137242361747691237")