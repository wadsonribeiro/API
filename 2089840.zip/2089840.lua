-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2089840)
addappid(2089840,0,"cf0ee3bde87a208b2bf9425b695b287a2997de71728df89f826fca1667197f85")
setManifestid(2089840,"71486794841630932")