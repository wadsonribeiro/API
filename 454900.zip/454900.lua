-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(454900)
addappid(454901,0,"0bf31be0c4cdb7e13b33a4cadf90306e0e409e89d928a70ea42c182961672210")
setManifestid(454901,"1967350777630072630")
addappid(454902,0,"3f3a72333d92c61681782197c871913c8e166c698760de344c1e53ad26ced563")
setManifestid(454902,"2890376083547389267")
addappid(465530,0,"ba217c9326c24f9aa7f248186dddb14cb97a940448ce1286c3912b52c17bd607")
setManifestid(465530,"1920170723285272414")