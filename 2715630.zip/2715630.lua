-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2715630)
addtoken(2715630,7149732792033697515)
addappid(2715631,0,"e0b9f7221d6f6084cc2e35d2510a9f2b33949aa381568e27086b8957cc2b2159")
setManifestid(2715631,"4412916538278076828")