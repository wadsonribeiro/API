-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(775820)
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(775821,0,"6ff0ca16f7a3135634ccc81c00c706b8a3153d834e20e3267ef03affc9a3b292")
setManifestid(775821,"7266045494221744360")