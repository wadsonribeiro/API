-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(656200)
addappid(656201,0,"cbf5d41a254e849bd1d217ee52191c6ffb42051e844f647e0ba964e28f12bd6a")
setManifestid(656201,"2094999812894312727")
addappid(656202,0,"399808ef39abd836a9384f8f5d9e2c20066d97c7384858dc666ae55bdae35501")
setManifestid(656202,"5970776447717723257")
addappid(853840)