-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1784780)
addappid(1784781,0,"4330221c494f82f83e76c8772ca222439607af90b052ccdb9c809582656ad8f1")
setManifestid(1784781,"6795706626792980206")
addappid(1784782,0,"21c574519db4c1ba710e1f55336f6357d08c49325583c409f65702357acbc97e")
setManifestid(1784782,"8342142780219785764")
addappid(1784783,0,"d26e7cb767ea4690ce9379ce51f3eddf5625e7f4d04603818e612aebca3c4077")
setManifestid(1784783,"974166118491739761")
addappid(1784784,0,"25da03fab69891766b53411095f43230cfa7915a675810dce980c2301e4c0942")
setManifestid(1784784,"2839000658357406192")