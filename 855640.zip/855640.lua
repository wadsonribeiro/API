-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(855640)
addappid(855641,0,"ed559eb443a29cdc89660d913c48a117726ab1b6f7395ba8ba1b18cfd512aa31")
setManifestid(855641,"4056165474328260669")
addappid(855642,0,"8e69404f2416b61877dfae2d3ca4b1c823e6f4cded2402fa50dadc806f0ff5d9")
setManifestid(855642,"6784609931669783836")
addappid(855643,0,"18ddb9cc36828f251c4347aa5a074efc4468baf6d6f2a2ae0bdef674657da6cc")
setManifestid(855643,"7363287475928860466")
addappid(922580,0,"91e38986a3dac96f8b6075c82f2fc6088f24f1d42e830f0eddeba2f4c5655e38")
setManifestid(922580,"1660844027751589012")
addappid(922581,0,"1f20777246011f0e969fe0c7b2a2080d570692177d9e7cedfb8e0cf973fa10e0")
setManifestid(922581,"2501990948161003914")