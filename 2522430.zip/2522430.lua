-- 2522430's Lua and Manifest Created by Morrenus
-- BREAK ARTS III
-- Created: December 08, 2025 at 13:50:34 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2522430) -- BREAK ARTS III
-- MAIN APP DEPOTS
addappid(2522431, 1, "ab926bec697a2920bfdf8acf4f347b40bd08f01583311ed8a418f9a8c7863c90") -- Depot 2522431
--setManifestid(2522431, "1470200279327402627", 9489102995)