-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2095160)
addappid(2095161,0,"b2a92d43f9c75d8c867399ff8336bc71df28008e13d3d869884e9be426d790c7")
setManifestid(2095161,"7414062884294932395")
addappid(2095162,0,"c8b08070a76ac20c2dd894d0568646d6b7e07273887e00aecbdbff4c41828a77")
setManifestid(2095162,"8624311728166300062")