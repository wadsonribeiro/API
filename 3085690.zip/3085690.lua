-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3085690)
addtoken(3085690,2210460564311816212)
addappid(3085691,0,"547bb181b122ad77ee9ae30d382e1f669da64a760c5fb32734826ca2aa6d3895")
setManifestid(3085691,"5767447292192503120")