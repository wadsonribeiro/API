-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1883750)
addtoken(1883750,15194195589897799496)
addappid(1883751,0,"8e96988f2fe236e1e289acd0717154fade6322d31cd668d93f0ed2abe053ed17")
setManifestid(1883751,"5794036165565110319")
addappid(1883752,0,"cfade55246fc5a42b8a5aaf882bdd58e66aaad0ac3bf31b4e2acd466078456e2")
setManifestid(1883752,"6037809207890816610")
addappid(1883753,0,"989dd7e693adcc899e808c96f19a6f75b40e9a4a30cc2faaa713b51e8b36a92b")
setManifestid(1883753,"8855764125780662409")