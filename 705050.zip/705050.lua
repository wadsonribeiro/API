-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(705050)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(705051,0,"4a267676eed68ac292478581b0b3c31cb0d55e21fd0cc5c60f0320a0d47f304a")
setManifestid(705051,"2168063607816956284")
addappid(705052)
addappid(705053)
addappid(705054)
addappid(720460)
addappid(705055)
addappid(705056)