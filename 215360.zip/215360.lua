-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(215360)
addappid(1251,0,"948100db7737b1e42b84518e4ad90b8957d3cb1c4bde1417ae44ffffdbf30a92")
setManifestid(1251,"9033622738747915238")
addappid(1254,0,"b3c37dce88bf0a0c729934617c3c50af30f9671b31dd95baeb88e338a5fa84a0")
setManifestid(1254,"92904673321000717")