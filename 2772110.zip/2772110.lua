-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2772110)
addappid(2772111,0,"c5d90c71f9f94003e5afcab8444a31e1f1ba3d0c9d692ae2bec2affe4d14a938")
setManifestid(2772111,"1344129567630775271")