-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(463300)
addtoken(463300,10592778028528926841)
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
setManifestid(1004,"7747775778018907449")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
setManifestid(1005,"2135359612286175146")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
setManifestid(1006,"7138471031118904166")
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(321401,0,"5ddaa6e2d3a6273936be783b3fe4adc297950578ac85308dd7a55c34781dbf61")
setManifestid(321401,"9011757822611619073")
addappid(463301,0,"976c898fffe18cf4f683553a8c4521dc3fc06584959cbbc05c37346779c2d1f1")
setManifestid(463301,"3636511801604319021")