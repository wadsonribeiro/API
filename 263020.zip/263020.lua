-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(263020)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(263021,0,"6db0181ebfd85337eb5b4b91f1b4b8ec04dd8dc41695e8c30e2221b4565f8643")
setManifestid(263021,"2781022140568307718")
addappid(263022,0,"fab2e198c798884e1197f7b32957af1fc09e13871744ff6fb003105c62f7e2ab")
setManifestid(263022,"3779227514543613065")
addappid(356970)
addappid(263023,0,"3869d956e021ab7014cb179d5ef0ee5d33a0205d76c2f3d0a71b105332a48344")
setManifestid(263023,"3289353568989290022")