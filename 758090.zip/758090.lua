-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(758090)
addappid(228981)
setManifestid(228981,"7613356809904826842")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(758091,0,"5f812f0e87d22b6339d47a8fbc98617f2bee84d2599596d2c0b7cbfcb983e5b8")
setManifestid(758091,"6674576860099850574")
addappid(758092,0,"1ed4dd35b3330b6509117d17489ddb2bb18e5e263ee45159da01355fedc685b8")
setManifestid(758092,"4391342546092272605")
addappid(758093,0,"bfbe141313219ac2bce922a2858677a35c0366b46ff23ad84c83d83dee4dbec1")
setManifestid(758093,"336454683553251386")