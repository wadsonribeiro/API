-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3295540)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(3295541,0,"e07e0d237a6b208045af470142db7aa2e49439c71623179ac3791a03eeb7e2f2")