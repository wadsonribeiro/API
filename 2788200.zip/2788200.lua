-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2788200)
addappid(2788202,0,"4db19e21b150da36b58db830b8814b1f5c5f5a4429d68163e49af1846474bcc0")
setManifestid(2788202,"7010370954233041539")
addappid(2788203,0,"f71ec3f7d9f9c923d8972bb187b3a9c0311de7ac95d7d0888ab7b4cd96d3dcf1")
setManifestid(2788203,"5380823857908037279")
addappid(2788201,0,"94524a33c35734810f99932c97ae807fc362f7243e51334bf288205289681b5b")
setManifestid(2788201,"6178873292888907023")