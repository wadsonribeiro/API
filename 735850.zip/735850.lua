-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(735850)
addappid(735851,0,"e010af53bb417511e8423ba27266d44e661d22a68a98b326819f7b217880c9ee")
setManifestid(735851,"8541691583390630116")
addappid(735852,0,"2c2dc1505f185f5cad2823d5a1f7e85e86ada759921b585bca53c6bee91aca4f")
setManifestid(735852,"8655017979476061493")
addappid(783380)
addappid(783390)
addappid(783391)
addappid(783392)