-- 3274580's Lua and Manifest Created by Morrenus
-- Anno 117: Pax Romana
-- Created: December 18, 2025 at 06:16:03 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 6
-- Total DLCs: 7
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3274580) -- Anno 117: Pax Romana
-- MAIN APP DEPOTS
addappid(3274581, 1, "29f1b2f2b84b5981fe5e3ebadc14b925e747eea87b6556a95001d576acb9beb9") -- Depot 3274581
--setManifestid(3274581, "6803865345134614885", 114479102779)
addappid(3274582, 1, "f04b6ff10311fb1d95b43528e4681da8a1b615a31d69275af308d77f93602a4f") -- Depot 3274582
--setManifestid(3274582, "2191802103118564389", 466188075)
addappid(3274583, 1, "dc97a69d99aeaea85bf8ec545b63e9a140606870c2f17f9fec7967c463060618") -- Depot 3274583
--setManifestid(3274583, "7473084111823980076", 505210880)
addappid(3274584, 1, "e8679d4318f2f44fc44ff183048c09321b4b84000680a1675fe1dd5463d2f24e") -- Depot 3274584
--setManifestid(3274584, "3294402892590575562", 516290841)
addappid(3274585, 1, "b08a4e3e71782afe4166e047a91bed2a236df33c2b0d0fe02a7ca3dba1a15912") -- Depot 3274585
--setManifestid(3274585, "4021469520517740450", 726298047)
-- SHARED DEPOTS (from other apps)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
--setManifestid(1716751, "5215205166610204519", 259068216)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3749050) -- Anno 117 Pax Romana  Year 1 Pass
addappid(3749060) -- Anno 117 Pax Romana  Year 1 Pass - Ubisoft activation
addappid(3749080) -- Anno 117 Pax Romana Standard Edition - Ubisoft Activation
addappid(3749090) -- Anno 117 Pax Romana Gold Edition - Ubisoft Activation
addappid(3875910) -- Anno 117 - Closed Beta Ubisoft Activation
addappid(4168120) -- Anno 117 Pax Romana Standard Edition Launch - Ubisoft Activation
addappid(4168130) -- Anno 117 Pax Romana Gold Edition Launch - Ubisoft Activation