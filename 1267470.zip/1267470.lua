-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1267470)
addappid(1267471,0,"d102fe7b5f8bd3273989af2e4a744e2ef7caeacfcbb1a0a87c469d499d5fa895")
setManifestid(1267471,"1840483791714425965")
addappid(1267472)
addappid(1267473)