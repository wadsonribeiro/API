-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1639880)
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
setManifestid(1004,"7747775778018907449")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
setManifestid(1005,"2135359612286175146")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
setManifestid(1006,"7138471031118904166")
addappid(1639881,0,"9f45c1b5438f2a6ffdd7dd4075f7d3264801bdb7b0a0fa6ab3bd189114356ed6")
setManifestid(1639881,"3042536151349433990")
addappid(1639882,0,"87aa1a9b639d6ed3d086001246b084c2a233d1240e7e7eabdcf1dcac1cea572b")
setManifestid(1639882,"9095599722234959438")