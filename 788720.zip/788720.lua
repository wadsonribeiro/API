-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(788720)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(788721,0,"47edec0e05035df91b0665a2d82f2531c1f4e406833853ddb8d6a1462e67a129")
setManifestid(788721,"5854474959015306505")