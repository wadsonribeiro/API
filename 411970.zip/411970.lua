-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(411970)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(411972,0,"ae277e0b84046085547cf81784a51c456a28ce2530c40b71298b7f99d5dbd024")
setManifestid(411972,"8091975492722457348")
addappid(411971,0,"b157f4cf8f6f978cca7d0f9e57a4970f8a7dc03273aa0fcead7cf6bab4dcf6f2")
setManifestid(411971,"203995010445816043")
addappid(763590)
addappid(2467140)