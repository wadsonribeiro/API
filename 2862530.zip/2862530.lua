-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2862530)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2862531,0,"c3a57066b260b3b1ef6825aaf03c45370df0fd218373cb595e5994e9c1f93630")
addappid(2862532)
addappid(2862533,0,"487ad00a2b6dd32c9f33a23864ad57d62e55eab7dd894bb91cf80828dcfc0932")
addappid(2862534)