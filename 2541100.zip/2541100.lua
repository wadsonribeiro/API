-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2541100)
addappid(2541101,0,"642449b507293d2df72087f049c3e1a81a12675a14dacf68c47285c3f04a10d0")
setManifestid(2541101,"5261868627439017393")
addappid(2542180)