-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(783190)
addtoken(783190,6240632287014068151)
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(783191,0,"c3218dfa8f2a3486ee6f90f3f6434250805d7a4766deccbb90e0f275ad68f9fc")
setManifestid(783191,"3225958054766259098")
addappid(783192,0,"5ecd55c864f09b03c83c08b6ea19cf6c8debe76b96041380c6f76449fdf85c4a")
setManifestid(783192,"6062563568361260874")
addappid(783193,0,"0bc96b439a8e46b88ab6e551badc1392ce447848dd0effafb43a57f11718f0ac")
setManifestid(783193,"584796705674282224")
addappid(783194,0,"9bf1157ac1d6ca7517121974a1aa24575387e61643c1791544eaafafb6da6a5e")
setManifestid(783194,"1032442589849275686")
addappid(1165051)
addappid(1165052)
addappid(1170890)