-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(856630)
addappid(856630,0,"0965c1c18cd64566b71ad0c7be8b9957bc2cc97c0d5e1a26b3c6ff772462ed08")
setManifestid(856630,"3929789898129931020")