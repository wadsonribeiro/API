-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(869880)
addappid(869881,0,"99a25066986c62e044971b607099c706f771068140691fffa7314056659d851d")
setManifestid(869881,"5259234687639271398")
addappid(869882,0,"a8f30cadd759cc672fbed516cb7d750e30b43b54a043345f73700b1e7bb08371")
setManifestid(869882,"8185431780124949494")
addappid(869883,0,"393a1489284d6b34cc52154ff1a8435668719d7d1925b5d4acda7ebe30b61d70")
setManifestid(869883,"4756221094073794159")