-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2160420)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2160421,0,"f4d1d3ed5e70b71644e60ae7d4571e2d59bd9e799052cbc890fd7ab730002b33")
setManifestid(2160421,"6707063296843441134")