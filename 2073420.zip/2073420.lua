-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2073420)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2073421,0,"43690d178736876f0aa1aed7c14955cede464fe372ddc3d2094bcaafef7130de")
setManifestid(2073421,"5908461361783264913")