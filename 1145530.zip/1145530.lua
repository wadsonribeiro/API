-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1145530)
addappid(1145531,0,"9848c83008677dbd72b40fb2ed236e09aac3254cf8418669d65b6267036afa7f")
setManifestid(1145531,"6932359434625716475")
addappid(1145532,0,"4ff376894e7043d69725e23a30aa33ca945673bcc35777970094d9a514f05884")
setManifestid(1145532,"1271326539437973040")