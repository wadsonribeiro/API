addappid(2896260) -- ODDCORE
addappid(2896261, 1, "c82ef318eb2b98fa3a40efed97d8f237b4e34de5005b21e17c5c661bbb4e831a") -- Depot 2896261
