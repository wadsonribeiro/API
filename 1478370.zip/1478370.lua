-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1478370)
addtoken(1478370,2245950402086196349)
addappid(1478371,0,"687ee70adb532fc84040e313d557bedba33105a40a9c8146e5a959f3247e4732")
setManifestid(1478371,"5717860416096747491")