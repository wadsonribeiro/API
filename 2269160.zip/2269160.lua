-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2269160)
addappid(2269161,0,"ba76a0e071cf4a3ce5b2fba99dfcc93b7a8feff832ca1ead11287535905808c6")
setManifestid(2269161,"1922097107546944174")
addappid(2269162,0,"6b228d309f6db8c2a67dd465342c634e229807f7fc4a5045e83601299b2a692e")
setManifestid(2269162,"1657046650396929867")