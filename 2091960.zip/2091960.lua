-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2091960)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2091961,0,"bcf71904a6d9f0a1d340f9b34a9c3a123ff237d1f95d6706f299f01c846bbf93")
setManifestid(2091961,"1296793394273968759")