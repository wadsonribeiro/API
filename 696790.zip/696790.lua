-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(696790)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(696791,0,"b7ec5db2706b5303c8a4a1f3822c0ad0589840034fe9ea04184ec89800af0ca1")
setManifestid(696791,"3994940788901871329")
addappid(696792,0,"a6042b91a4f46ed3ddd06902e1a3fd9b8ef92533080ac744e59b3aaa1d980bcd")
setManifestid(696792,"5686368785904568784")
addappid(696793,0,"fb028e1843c08899a15ec1844e97ea3d135c824b7fc402521755c1c991b6be5d")
setManifestid(696793,"5139519145635417906")
addappid(696794)
addappid(696795)
addappid(696796)
addappid(696797)
addappid(696798)