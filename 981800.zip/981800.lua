-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(981800)
addtoken(981800,11454580926987288707)
addappid(981801,0,"3cb05857da1e8363b8bcf812f0a9489d0fbd3981cf03789f6ef8a491864cc041")
setManifestid(981801,"6569798241739297199")
addappid(1056210)
addappid(1056220)