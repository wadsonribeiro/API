-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(884600)
addtoken(884600,17104946179167907133)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(884601,0,"0c8b21c044474c0138a4c316598a365d1bae4f29e078c2071012995d898db4b6")
setManifestid(884601,"6709498037136255252")