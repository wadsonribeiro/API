-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(558620)
addtoken(558620,9221413588458630650)
addappid(558621,0,"05e48a79e5df9ca213f138e1ef6381d4a925d3b689933dafa7e6dfde1bc5e974")
setManifestid(558621,"4885929151405112036")