-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2769070)
addappid(2769071,0,"db3b1bc89e7fa02dd540b91fa670bf2c274362de407f47af1b0f7ac4c71c4f01")
setManifestid(2769071,"2208576956425372680")