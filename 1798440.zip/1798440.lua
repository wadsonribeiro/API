-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1798440)
addappid(1798441,0,"3ea0861ed6a367ee7b24c9f69973121efdf6c0210e3f8b273e7082f6eac5ca4e")
setManifestid(1798441,"5018414049401672869")
addappid(1798442,0,"b8ada4218c4ba707180e3fdd1fe2232b8a7180575d7182e49d10b6b7df668910")
setManifestid(1798442,"2748830488439643145")