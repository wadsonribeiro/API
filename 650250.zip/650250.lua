-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(650250)
addappid(650250,0,"7909ca753eee62e8ae0e48f743391461543218af870c443bb939276ef1493775")
setManifestid(650250,"723168302207096796")
addappid(650251,0,"4a487acf1276b1a5746ee715aee403245042aaca858a403b129b56ea2b056352")
setManifestid(650251,"6647963661251113436")
addappid(650252,0,"aae6368971c43a562a16ca206743bf8963713a619d97f428ae9c92303081cda0")
setManifestid(650252,"8959178247163920329")