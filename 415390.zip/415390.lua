-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(415390)
addappid(415391,0,"abcd9ac3788235ea43ce438b420ba49233c15000def4c8bfb7ca3ef74fa73846")
setManifestid(415391,"997548086496250160")
addappid(415392,0,"fcce9cb73f38d3b07c3ab392c62fd6cd5a8ba80cbfd2b984d7cf5a355798be32")
setManifestid(415392,"579486739947369129")
addappid(415393,0,"4080720949017b865ded20cd7db420a2c3a51a6e18a2361ab991328b3cf8d959")
setManifestid(415393,"7851008395670946719")
addappid(415394,0,"1930689f5fc213e0ab2d2d54f838fc279482d49b23b94878902555ef1a43a391")
setManifestid(415394,"4456644361717205668")
addappid(415395,0,"0f2563c795c2d0ff7228b1c8c30027840d0bd0a4793d6398d0972e9ee03cb9e7")
setManifestid(415395,"6799779273483236987")
addappid(415396,0,"87a198a6f4cf9125a90d73472b054071e508a91222531fb9ee3e8b3cc5d8f465")
setManifestid(415396,"8089064182970926229")