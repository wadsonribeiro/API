-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2442610)
addappid(2442611,0,"198d5ec40f27dd9558dfcdd93e0b8ac85bcd0a62a8036056d9e6e42cd7e3aec3")
setManifestid(2442611,"314872763947177326")