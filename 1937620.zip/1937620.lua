-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1937620)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1937621,0,"0542f95132634466a9bc963a57c86beaa7b8c8e9ccfb025d51cfab0a6c879fd0")
setManifestid(1937621,"3834020561347710151")
addappid(1937622)
addappid(1937623)
addappid(1937624)