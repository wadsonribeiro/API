-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2297350)
addappid(2297351,0,"a0d9562462cd8e2af0ea9521211603d8e48ce98b315f7574d8d9ec7513e7a79f")
setManifestid(2297351,"2728496299867653474")