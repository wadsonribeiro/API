-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(860890)
addappid(860891,0,"9142a0e86a8b973c9d887ccf6e038c5e77a482fe359542e9326e13365ed43c06")
setManifestid(860891,"6096378447342621888")
addappid(860892,0,"b390a5e8fdd3806a130738f79c9f0a89801c1b23bb079ae53d2095331ac7b99d")
setManifestid(860892,"7042352031130474518")