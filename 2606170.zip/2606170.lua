-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2606170)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2606171,0,"34f63d146fd51f29d54d3c0d7f8b3f4e803cd2c61412a9a86a6c896bb14f6cd5")
setManifestid(2606171,"3474745192202406412")