-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(488050)
addappid(488050,0,"a1d45989f6a6eb213bf21f074cf5c02d36546d6dd4c7cebb48d86e25c5e5c4ec")
setManifestid(488050,"5575113993500526477")
addappid(488051,0,"67e42d404db5738626f8cb42b46752bb4d499a6d5263b6284e663a69355eda7a")
setManifestid(488051,"8199121252227923347")