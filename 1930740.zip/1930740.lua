-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1930740)
addappid(1930741,0,"de4025ff3f73a3b1cd0ce08d51e3efa8f3f0a017b07c6a0f282cbb1e0b120c19")
setManifestid(1930741,"8873066998099892411")