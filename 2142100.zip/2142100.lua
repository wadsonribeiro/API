-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2142100)
addappid(2142101,0,"bcc3fe18a4cc6a8c52cdbec90ae05a40b7edc3db30ac34865e5d60873aabf6cb")
setManifestid(2142101,"2880557158607208175")
addappid(2142103)
addappid(2142102)