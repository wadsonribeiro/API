-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(904900)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(904901,0,"094d67b2e5dc7b5d5627e467a92000bd29327c7a6f432631f56019cc74dff657")
setManifestid(904901,"4696200561018640025")
addappid(904902)
addappid(904903)