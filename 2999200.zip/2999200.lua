-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2999200)
addappid(2999201,0,"3ccfca714e3c4940792c01b1af9275f52c104e9d0a6b0d63142ee7849d087351")
setManifestid(2999201,"1763936911730368887")
addappid(2999202,0,"3ac654ebb1f9dc92f03763f2b6213baf8ce1ee1e2a21e2999150e7fd3b2df6ce")
setManifestid(2999202,"2640382397318413571")
addappid(2999203,0,"7a8d7fdbbbf0e5d008d37c238ca21232ffc557788b82dfd38e27e2c0be09d1a4")
setManifestid(2999203,"6091841552402603303")
addappid(2999204,0,"008a12c0562b4f9a21e0c984b640101416710204c19ae89d0ef8af46b3ee8500")
setManifestid(2999204,"727549239455406886")
addappid(2999205,0,"b883b37e87fd69abedb0cdf6e252b7f62f399f97dfb94acf98b89114c79546dd")
setManifestid(2999205,"2554377506050201308")