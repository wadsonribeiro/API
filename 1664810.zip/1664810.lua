-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1664810)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(1664811,0,"3349b516bf375e50212ad5ecaebdc86b322962e0604a86ab84dd4a10043543f9")
setManifestid(1664811,"6561434116753961204")