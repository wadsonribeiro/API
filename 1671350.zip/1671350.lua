-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1671350)
addappid(1671351,0,"6bf27780460f234a2a1f168dfae569d02865db73cca7ce1f613b4cdb06fcec94")
setManifestid(1671351,"8673748418367646435")
addappid(1671352,0,"56afb2e2d84f633952a6b7c53e1da726571c44256bb0cf753df5dc0610388e25")
setManifestid(1671352,"9124699972351878885")
addappid(1671353,0,"9cb38a6fc1d959bf52aba591332700a1ead60c2ccf1f13196f1c8e5d27b68e4d")
setManifestid(1671353,"8601012582230773814")
addappid(1671354,0,"deb6273c55461622df48625cfeee1da5dfc4d132ff86ebfd322fee31800d0ec8")
setManifestid(1671354,"590891462823639597")
addappid(1768370)