-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2185340)
addappid(2185341,0,"e09431d789178215a3917304933ea2cb411008bd4ca7b6eab4b61a245c54e56d")
setManifestid(2185341,"8759164766722687135")
addappid(2185342,0,"efba33cc096e30d58c13f30b10c476b7f54591721489c41b021fb2ed24a5ab7d")
setManifestid(2185342,"6539756343069371532")