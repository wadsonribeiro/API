-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2564570)
addappid(2564571,0,"febd7c95d401830b10297655b4bdb21aca73020d4608259d893ebdff8bbe05ec")
setManifestid(2564571,"5427321075135792381")
addappid(2564572,0,"57bf39c5e5673551129bfddebf1efc8e8369a494b32464fd1417ad3b89d11c26")
setManifestid(2564572,"2115641761126130867")