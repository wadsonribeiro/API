-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(961460)
addtoken(961460,6141774378484943588)
addappid(961461,0,"a7f07d264d949835d120e681157a7d72d8743e6359e454a6dfca64926907d822")
setManifestid(961461,"2128687947090058329")
addappid(961462,0,"2d3553fb2f48ab2661fa34dca6515df13e528bfb21c4643e3173986081584a24")
setManifestid(961462,"3411974260838096220")