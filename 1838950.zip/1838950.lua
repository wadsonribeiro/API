-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1838950)
addappid(1838951,0,"71f2c4fc73d2784abf09df64a27bdbe2167bb0659df2c8ac2167b37fc93f5cc7")
setManifestid(1838951,"5591209106320636841")
addappid(1838959,0,"d73fa23c900a9ea0cdcc228262e7421ae5b9e93328c025a8ae14f6ae8833f81b")
setManifestid(1838959,"4908957202757761307")