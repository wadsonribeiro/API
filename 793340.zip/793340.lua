-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(793340)
addappid(793340,0,"bd06bb1698afa2af01978471b55053f3d92f35b4656938851d9ffb37668ae31b")
setManifestid(793340,"3922383297427665115")