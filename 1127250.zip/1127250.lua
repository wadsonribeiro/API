-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1127250)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(1127251)
addappid(1130220,0,"5c715ee27c33f20acc9c55b45763df0e8d2ac57165b199dd3b931328bdcd38f0")
setManifestid(1130220,"1515572061874901683")
addappid(1127252)