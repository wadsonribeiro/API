-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2106760)
addappid(2106761,0,"3b277b87e2b4347f4f7b90ac9224172dba52aad2116e4d0cae955090ef831129")
setManifestid(2106761,"5135635367003909521")
addappid(2106762,0,"adcea875e38fc3479b7ecd4fed58478a67fc11cf31fd8726def978246039ded7")
setManifestid(2106762,"5039193971786636964")