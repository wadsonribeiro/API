-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(423852)
addappid(423852,0,"67b4b465e5a7105b24c5b996696901047c48bcb06a65da3c8415c37b58dbe9ea")
setManifestid(423852,"8554867693098092737")
addappid(2501440,0,"bbe867cae1866bf5a889613e18e4433c378e7527211cda7ed93d997336898d96")
setManifestid(2501440,"9187568905456704855")