-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1780470)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1780471,0,"ee5ff53f1e661e5d15c70e57ac19243f1c1a483a532a14275d8101e70d75aaf4")
setManifestid(1780471,"8129395103012015168")
addappid(1780472,0,"2e4a4a04aad464032d3f349faf5c0343cd9f6dcb530b0d036cca36ca34bd4f50")
setManifestid(1780472,"716862315807889145")
addappid(1780473,0,"80c87d8e93fd14a34be24f7feeb2a720c155330286355834d316f83913fe16e9")
setManifestid(1780473,"2857682109586511972")
addappid(1780474,0,"c34093655b0272422428be3c8fbb23bcb3bc1d9078e5040a15c0973fb4ea5c96")
setManifestid(1780474,"4081257541715126829")