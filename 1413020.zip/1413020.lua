-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1413020)
addappid(1413021,0,"0d6bc35a3066242f011963d1c2de69716c460faa59fe5249f1a1dca90e3fb8ef")
setManifestid(1413021,"8381680240948400417")