-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(841030)
addtoken(841030,6354317433327105899)
addappid(841031,0,"348b7c5c56761eba5d3f892088030508e6d8b82a668cf0623e7e61f4afb3f80e")
setManifestid(841031,"8984381298794096235")
addappid(841032,0,"5c684d4a457cdb7de8a664745c4e91be35aaa557101e7cb9847b84570205161b")
setManifestid(841032,"567679021695195055")
addappid(841033,0,"480b0fcff1a26c4db7708f15999302b195cdde91b72d49826474940c69e6d219")
setManifestid(841033,"3264138989503561454")