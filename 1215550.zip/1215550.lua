-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1215550)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(1215551,0,"06487509eabb4560424693e3cc9ff27109b58bbd736ea3d1202e397514427cef")
setManifestid(1215551,"915376756195949310")