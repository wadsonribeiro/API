-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(938370)
addappid(938372,0,"3f628704c667e6a5794e302a89b36ebffab58a7e914b9e65fa9a3c5f658d0c08")
setManifestid(938372,"3635787562417949984")
addappid(938373,0,"d328df05b5326655af4cbff5c9f4dffb6df392f5b257a0fdc15b07ad610dd338")
setManifestid(938373,"6289016977698964476")