-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2444170)
addappid(228981)
setManifestid(228981,"7613356809904826842")
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2444171,0,"e28b874d27af16f241333de28ccfd453b67f425a37a75e68fa5cd54c031e3afb")
addappid(2444172)
addappid(2444173)