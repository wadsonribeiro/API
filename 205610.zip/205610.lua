-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(205610)
addappid(205612,0,"04c0f0ea9d0f72a59c832a1fb3d4641e1218e1be5d13c85cabb83f84de8d0149")
setManifestid(205612,"7914637285045534105")
addappid(205611,0,"fce2e1c6978c7b56c759a52560797a75b5ac5e4afb58dd1851c318ec3240f8d7")
setManifestid(205611,"3252123628758744460")
addappid(205613,0,"cb12c407069a6ccd4acbd10cf41a92d7653e7dac80c4ce1623adf9fcf48e1fd0")
setManifestid(205613,"5154117208515558574")
addappid(205614,0,"a6aa9abdac7af81ca43f8101829b41ea3df04b56ab3a1d1e0de1b011638ecbb4")
setManifestid(205614,"2598267753271468498")
addappid(205615,0,"aee997aa95e851eea19598566796f5916317f8c62c7b6a0d0cbd9610e1082189")
setManifestid(205615,"5414828940792408436")
addappid(205616,0,"85607f4afac42768ca367175ad5b4fa82d42347b847c31c5bd8602b27a71e8d5")
setManifestid(205616,"2173125789028261673")
addappid(205617,0,"bdce209ab4d9d8f7224a7f24b8a033a2634bef74697b2e86a8b3d29da84ccd46")
setManifestid(205617,"9058467169396468036")
addappid(205618,0,"85f722bd0bdacbf413d1c40c48832997113941132bda7243d8c22cf5e76e1705")
setManifestid(205618,"4139614710031696175")
addappid(215972)
addappid(215970)
addappid(215971)