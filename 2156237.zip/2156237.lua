-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2156237)
addappid(2156237,0,"5c84080aabe7b1efc605722c7aab0f72e20c6cca311556f1a7511987d3d57457")
setManifestid(2156237,"8727385072536338542")