-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(948680)
addappid(948681,0,"570d7b2578c10dd5bda006abb6d082ca36edb235c3199dd817d6d66bd3f71d3c")
setManifestid(948681,"5531293508781173869")
addappid(948682,0,"dd9ccf33ad4b95653fa4c14d267ac9c3b39791ba20088dae50d7804f213298c5")
setManifestid(948682,"5062539984328593890")
addappid(948680)
addappid(948683,0,"4aa195ea1741c34b8959f5623de844a063b5dfad2fdaa615438c5c44ccaa900f")
setManifestid(948683,"6113504142127697334")