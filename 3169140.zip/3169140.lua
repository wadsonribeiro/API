-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3169140)
addappid(3169141,0,"966dd5db779b33da0d073935e78016f81961bb77ba4a9e1b07e1d9282c2880f0")
setManifestid(3169141,"5090508592556984914")