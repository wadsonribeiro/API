-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1657270)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1657271,0,"0f108a8a5b02fb1481d67f5d7b36ed7c6738d5ebec02f7ec0ef28c8d80bc6712")
addappid(1657272)