-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(663730)
addtoken(663730,17141734689742217793)
addappid(663731,0,"611508e152bf71125fe74f2a655a7182e9d2b24ca9f3c319a2d89a99a0ea1b24")
setManifestid(663731,"1498006640894474732")