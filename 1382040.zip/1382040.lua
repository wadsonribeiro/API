-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1382040)
addappid(1382041,0,"c1eeb79769e90750a0d4732d8f28d207aa090112979b066efa907fb621b256ec")
setManifestid(1382041,"372922912922430349")
addappid(1382042,0,"daee3f6c7e1f517d707c998cedc1bbe7ded7db22e958d46942fc23d3d7b33ef3")
setManifestid(1382042,"2325658935379667117")