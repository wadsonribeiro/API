-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2878720)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2878721,0,"5757a13d5bfbce858447481dc7a46d3e95b3e1c9161eee2b0d01ab34adb52990")
setManifestid(2878721,"8902027878250236898")