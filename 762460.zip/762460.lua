-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(762460)
addtoken(762460,17597975187693958736)
addappid(762461,0,"7e8f0245d29b15029a97e46d55ffb3fdad06249a10c6de3a0688c3e99541e30c")
setManifestid(762461,"2717593397280415463")