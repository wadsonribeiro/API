-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(571210)
addappid(571210,0,"082606aa72135f108e57d042e8437b3eb2ee1a4f224cc4ca222f4faff6c1fb9b")
setManifestid(571210,"2763134548086025837")
addappid(571211,0,"8fbc972dcc104af3d6568e1c5a1dd6d69577694aa531f3adc17c0a67be892beb")
setManifestid(571211,"986127183796138182")
addappid(571212,0,"a5e0fc80db6078bbfe9226ff0529cfd5b22ea6419b381b8b269a159ccef10872")
setManifestid(571212,"82718006781165356")