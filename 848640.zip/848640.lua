-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(848640)
addtoken(848640,10615998046693339384)
addappid(848641,0,"a65e01903339b90c99f6dbfe0a42d3677055babedc2fe29af916c226f97f19ce")
setManifestid(848641,"1040015416418699499")
addappid(848642,0,"87e262d4d4358b73153e01ab6bb0aa39a92589862eee89f90a2f4452898cbac5")
setManifestid(848642,"5949150094453198996")