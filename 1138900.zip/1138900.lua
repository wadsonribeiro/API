-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1138900)
addappid(1138901,0,"c2402dad61a478c4d4764be90f02d737fb4fc679ac5c3c4688c5c6ad23e91d15")
setManifestid(1138901,"144264230728603933")
addappid(1138902)