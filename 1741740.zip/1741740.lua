-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1741740)
addappid(1741741,0,"f071a5e307a7cad44c760c0165b2d75207ba7e841b94e5b549cf3af42d694a50")
setManifestid(1741741,"4059378669774937583")