-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(690140)
addappid(690141,0,"41fd6db8fe3519c7d344521d16c13e4cd51d7b09d956cc32ec8ebfc429ca3686")
setManifestid(690141,"4900631823895484439")
addappid(914830,0,"4a9d4da90752a3a04a9ebf9bd66d27615c4da82caaac4e80610bddffe096edff")
setManifestid(914830,"418335909327912374")
addappid(914831,0,"ab3d2d142773e8678b75c89d8df84829b763675986a17c8edb3e8ce493e0087f")
setManifestid(914831,"5668323947977698689")