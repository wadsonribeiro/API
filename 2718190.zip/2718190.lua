-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2718190)
addappid(2718192,0,"d63025827307381911d27f31e5931f0321a5cce32a46aa5b103bb9e1e7081bfb")
setManifestid(2718192,"9126142397060825934")
addappid(2718193)
addappid(2718194)