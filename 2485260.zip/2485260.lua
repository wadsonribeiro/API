-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2485260)
addappid(2485261,0,"dfce03ff0ddb55b1cbd4ab89dd7d6a50f52f7252ca3c68e4dd92c8ebf4153e62")
setManifestid(2485261,"6667115084376946625")
addappid(2485262,0,"f1a3813409332edb6b23df992699f0054de5609c0b66dd7d84d8d5351714d3b3")
setManifestid(2485262,"187578023187784974")