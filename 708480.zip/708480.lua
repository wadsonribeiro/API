-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(708480)
addtoken(708480,16332264464492035283)
addappid(708481,0,"495c732c8a6a303efb36eb58d3d29e51864930c9d4df971e21bdbc7cecfa871a")
setManifestid(708481,"7659469240300027761")