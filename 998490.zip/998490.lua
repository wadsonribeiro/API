-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(998490)
addtoken(998490,2912174375501061954)
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(998491,0,"db3c18ebd2b9d537ef01b37dab69904f1b13638d2497fe02735f81581888bc84")
setManifestid(998491,"7809385396664752977")
addappid(998492)