-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2576220)
addtoken(2576220,5859420124983438485)
addappid(2576221,0,"232c9344bcfc09fcb3ff5e1c7b81594c2cd082ea9e73782e3416cb7d7a2bbc37")
setManifestid(2576221,"2414153495441796248")