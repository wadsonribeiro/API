-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2173260)
addtoken(2173260,12608355139572892373)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2173261,0,"bbd69d58d726d73c2e83e15b3c00b6e3e91471458a61e1fc07893c584f1faa46")