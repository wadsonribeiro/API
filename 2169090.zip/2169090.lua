-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2169090)
addappid(2169091,0,"a1d5fe077e67c81f538c116db600b84c92be512ddd7d6e5bd0b019d06bc8e1fd")
setManifestid(2169091,"7096995695339111768")
addappid(2169092,0,"ae860c496ca9c4599afe20772bdbeefa31f8d026f1dc45fe7df7241825e879f5")
setManifestid(2169092,"7982639630408690488")