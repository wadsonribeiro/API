-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2485640)
addappid(2485641,0,"efe613d352823afdaef4572d31b7efaefc2d43a19d0bd9efbfe9e4875e994a13")
setManifestid(2485641,"1193577397305881950")