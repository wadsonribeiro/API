-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1918540)
addappid(1918541,0,"11b06e31bd2ce947dbc2d943d6e973ae90926e7bed06a687ab4580d7396b42e2")
setManifestid(1918541,"504576007949127037")