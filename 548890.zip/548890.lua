-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(548890)
addtoken(548890,16230702072605333904)
addappid(548891,0,"6634280827b5126301137e580c0599d41549ff96cd8ec7ebf09f946379d11ff2")
setManifestid(548891,"4316521633773295034")
addappid(548892,0,"9e429ebe6e5bbf71cc25117e650f6ed055ca650cddf15ca52d281c24afb5bb72")
setManifestid(548892,"7466402673672281618")
addappid(548893,0,"e3e46d656931ffd2fa8b6c835fda1c46a478b8d1dc812b8b71a69a84994a4b60")
setManifestid(548893,"248985593560467873")
addappid(548894,0,"6d810df61a65a675edd7d64d1b5fa03c2b9dce6191ed2e3638deb21a58559855")
setManifestid(548894,"3302015323603764477")
addappid(548895,0,"2b4406c34ae612c96333e4ebfd818197dbe8c04d16521c41cea5e6f57f4cc588")
setManifestid(548895,"193952524515284904")