-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(548840)
addappid(548841,0,"0b6bbb1432bb4e531f29789ef3d032a9d33e6fac2d8023ae868c43e61a99fa84")
setManifestid(548841,"290538382615194322")
addappid(578280,0,"f99c91ccd66cbe044e4e4ab6df0acb01ff715d0ca8230c4adcc44855132f2b49")
setManifestid(578280,"8225790227387659252")
addappid(578281,0,"c90c4f7b4957d0035d8b27e2d21249bc5a2fbc3a5c583e503eb90b6630818918")
setManifestid(578281,"873214945671647779")