-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(363620)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(363621,0,"87dc36b7d52a11856febde9a4dbaa8cc7ca7a3cae7b923a948748a90094bc69a")
setManifestid(363621,"1964271679949488086")
addappid(363622,0,"8adc2ec5b8350baad024300f0233673c7d711a7a5f162bcd4ed877f6f4d9cee8")
setManifestid(363622,"7155690761785031895")
addappid(363623,0,"1995908688525c79279c01fdacfd49f5cf0e5976570c2fae5371ac72230692e6")
setManifestid(363623,"3931504606643665052")