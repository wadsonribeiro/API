-- 3124540's Lua and Manifest Created by Hubcap Manifest
-- Far Far West
-- Created: May 04, 2026 at 02:16:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3124540) -- Far Far West
-- MAIN APP DEPOTS
addappid(3124541, 1, "c09a55a6a88c0a10b672b6f544431641dafaf34a4f082c4798b3de9a59061cac") -- Depot 3124541
--setManifestid(3124541, "6698131625579330054", 5450473368)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)