-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1443660)
addappid(1443661,0,"73aaec4ed5218b012e23d0feb57a5c47a35bd1e7abf87361064c9f5042d9b19d")
setManifestid(1443661,"8038195698479584191")
addappid(1443662,0,"162991c5e1b3b8ffc076df0ed7690db951adac1577ce99e08f6327d99571526b")
setManifestid(1443662,"626551081079877071")