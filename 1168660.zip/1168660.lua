-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1168660)
addappid(1168661,0,"db613845f52a172384cdbfe80e2cff1d3342c45c3838a9e7e4e73eceea7d5c2c")
setManifestid(1168661,"5672388402372960459")
addappid(1168662,0,"dc13ff00770ff6992f565aa85531d760fccb2a61c54ec63ccf7a3dd6c0c1869b")
setManifestid(1168662,"2476258550225605495")