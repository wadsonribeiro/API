-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1248150)
addappid(1248151,0,"855e6a51e172df9711affc3600644d24767b5eaa270535f5f2d2ce09ff6a8557")
setManifestid(1248151,"8422293161447394538")
addappid(1248152)
addappid(1248153,0,"fa0797daeeca2bb07a0fc22ad249d7c65a130c6db1a8536700255d0243737eee")
setManifestid(1248153,"7422258679871652816")
addappid(1248154)