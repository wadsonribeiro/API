-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(585720)
addtoken(585720,1547853309717418567)
addappid(585721,0,"fbe2d1d116797915c12ac4cf8da13bfba6159fd662ca7897af7a0f9df0cdf59b")
setManifestid(585721,"7077461994118838937")