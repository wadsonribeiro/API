-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1491790)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1491791,0,"78d61475478bfa6f24c7b2b515143e9da241e30000da9077f1603eb31a7d76e0")
setManifestid(1491791,"6657951667784297617")
addappid(1491792,0,"98fbb9b2b003268155a33c98b8e3435baf28e06f167a50b36c9e8a4d0dbf6c76")
setManifestid(1491792,"2689478727074689890")