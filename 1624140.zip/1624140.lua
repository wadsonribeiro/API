-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1624140)
addtoken(1624140,8104549891645768444)
addappid(1624141,0,"b4f47e7461e5db30db6dfac43e9dcb9c7800d0145b0d398704176b081d0c55c2")
setManifestid(1624141,"6162392676552877310")