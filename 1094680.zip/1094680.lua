-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1094680)
addappid(1094681)
addappid(1094682,0,"0903ff5ced2d7102f189ff35b194f1ab281d8a13f71dd593844e19573742d4e3")
setManifestid(1094682,"4801327436290089390")
addappid(1094683)