-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(475430)
addtoken(475430,13458325645787120103)
addappid(475431,0,"db2784afc9cd936dd9d7f165bf6d597ef47fb8e7b62dc139a2fbad074866b868")
setManifestid(475431,"9193066890108823863")