-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(944490)
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
setManifestid(1004,"7747775778018907449")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
setManifestid(1005,"2135359612286175146")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
setManifestid(1006,"7138471031118904166")
addappid(944491,0,"c604882d06c3038cca287d481ca500d0684b41db42db9d1ddfbbc6182f5d7f3c")
setManifestid(944491,"8161842659279405083")
addappid(944492,0,"ee31fee428794a8abc9fb3324ec3d9f7b41ab7cf82357966997308521783b31e")
setManifestid(944492,"3583625578540650268")
addappid(944494,0,"fb0e123a6eefd158c05c4230ce1733704af8c8cbd1c8223f79b26b8ccd0b8881")
setManifestid(944494,"3732520844873104516")