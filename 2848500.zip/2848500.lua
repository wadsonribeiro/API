-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2848500)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(229001)
setManifestid(229001,"4049573910112143457")
addappid(2848501,0,"f4e3ad8ba6ad0b8660e82bd4f48d6f9014961c8be27a6035cd55c682708d39c4")
setManifestid(2848501,"809180714176069318")