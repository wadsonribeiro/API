-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(428750)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(428751,0,"36a7de627692cd960ef56153846ea243de884e56de4ca6fb0cf5a90a753166fe")
setManifestid(428751,"8579756546736533724")
addappid(428752,0,"d02825259cc9d4411260356a1523294175fcf5e07d35ef241dbda3d6457291e3")
setManifestid(428752,"142298954794648705")
addappid(428753,0,"7f3395501fcf9ad0b8f550e35ef6e26665f50de9ce6955938bc6d67dfcf91489")
setManifestid(428753,"6027247917930520055")
addappid(453250,0,"03f46c5f0ee0256f39f871c59f92c88cbd45d72d76881b45003d85517a85da1c")
setManifestid(453250,"351248175688382270")
addappid(568850)