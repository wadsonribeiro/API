-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1725760)
addappid(1725761,0,"eb9233620604afb52eca74935c8a812fd2583ec4f923c5db790a797c89f0eb8b")
setManifestid(1725761,"6988810734441050269")
addappid(1725762,0,"59d37872de4b2017085982272bbc410361bb7f8f42343abb2fabeb841c5413a2")
setManifestid(1725762,"1035488292583388137")