-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(622820)
addtoken(622820,15209995399036541322)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(622821,0,"5bc05d047103df1fcfe80d725f195af8aa741566bc431785a7b06fb744350d78")
setManifestid(622821,"4115002907818605136")