-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2333150)
addappid(2333151,0,"1fbc38ba3df1f04f20e1f156b29508e9a35c901d2a2e04c03bf96c7e4ae20098")
setManifestid(2333151,"3112389741518910760")