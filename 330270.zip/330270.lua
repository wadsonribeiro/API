-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(330270)
addappid(330271,0,"76ec63e65ee0ca9512b2cb1272c5740cf85abdaf81c475a3b848b8a0c5e3e773")
setManifestid(330271,"5651791203431375641")
addappid(330272,0,"5be97b8e6b50e08d20f281cfbe8e85cc08d203f47d43be04a139157e70158579")
setManifestid(330272,"1452779530008717571")
addappid(330273,0,"5e5d1e814b92f4b787e538866f470f121c64967f3f82da93560151b5b270642b")
setManifestid(330273,"6140856756043113393")