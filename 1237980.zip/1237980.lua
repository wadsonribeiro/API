addappid(1237980) -- STAR WARS™ Battlefront™
addappid(1237981, 1, "f4bc2bb3557f74240ae7b98217fbabd27d97e360efd7ddfe44fc57b3114dfd16") -- Telstar - SWB Content
addappid(1237982, 1, "377ace0daa80abf828215db5756d57a7bae7a3fe206d039855343f4baee463de") -- STAR WARS Battlefront - en_US
addappid(1237983, 1, "e94e5944d37815b6ace28189f734ac4a0226c46c7b8cb55f3e91bf455eee13c8") -- STAR WARS Battlefront - fr_FR
addappid(1237984, 1, "dc9cdaca876a5156058532702e97ba2a1ff614b9ebfdafe2edd92d32722e9e0d") -- STAR WARS Battlefront - de_DE
addappid(1237985, 1, "b782c19582f06efcf27c63266d25d473873cafff3c10e6c445ac3884b725d33e") -- STAR WARS Battlefront - es_ES
addappid(1237986, 1, "ff520f806885b48c4e15fd1195acb6cedccd994c7403c5e1edc7c554292616b9") -- STAR WARS Battlefront - it_IT
addappid(1237987, 1, "87f74c127d0a91f1c18f6d42ec4e259266537d38d63afacc5e205a9057bd5df5") -- STAR WARS Battlefront - ru_RU
addappid(1237988, 1, "76e450e245b4de2b1177c0e8f8d36591163922ebd7c72dd0cc4ee370e25a026a") -- STAR WARS Battlefront - pl_PL
addappid(1237989, 1, "e355e07a0df9d07d5916bd1b0bdeb419e9ed28c3d37e56963d6f4dc76f4a0dfe") -- STAR WARS Battlefront - ja_JP
addappid(1237991, 1, "8ea16a5f45fd84cd495da050b2359b49b3bdd9b00bb23e7852f56f9abd568ab5") -- STAR WARS Battlefront - zh_TW
addappid(1237992, 1, "7a1131dae21fed47ba29443250f90f2f8a1042ea7575a56d88a7e5a5b78f1bd1") -- STAR WARS Battlefront - pt_BR
addappid(1237993, 1, "26978bbc8eb22bc99f844b3335c77bd48ba22ce1492f05623e4bc9d997ea01f4") -- STAR WARS Battlefront - es_MX
addappid(1237994, 1, "000829397e508aae38cdce4047bcfd97f131096a9692f182fafb256d09aa1595") -- STAR WARS Battlefront - ar_SA
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
addappid(1237990) -- STAR WARS Battlefront Deluxe Edition Content
addappid(1254080) -- STAR WARS Battlefront Season Pass
addappid(1254081) -- STAR WARS Battlefront Outer Rim
addappid(1254082) -- STAR WARS Battlefront Bespin
addappid(1254083) -- STAR WARS Battlefront Death Star
addappid(1254084) -- STAR WARS Battlefront Rogue One Scarif
addappid(1254090) -- Star Wars Battlefront Ultimate Edition - Key