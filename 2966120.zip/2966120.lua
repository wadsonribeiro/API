-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2966120)
addappid(2966121,0,"459203137e2ac30011496a43fa932093087bf25503e01abddced9c3b7466f681")
setManifestid(2966121,"8601633920218373503")