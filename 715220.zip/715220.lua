-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(715220)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(715221,0,"dffd5f7375beac0e43e57741b348891612454c3d82e692a1b22574365a96ae2f")
setManifestid(715221,"6587660592574088135")