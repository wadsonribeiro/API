-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2560200)
addappid(2560201,0,"1fecc290f0a730d2069c046b97912316ebf6f897714ac518a5e35a5352327fd0")
setManifestid(2560201,"3307370254029137393")