-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(736570)
addappid(736571,0,"af3193bd621d54f4ad8d049e0af8a60d5a834149b44421c3c48042ce6460f115")
setManifestid(736571,"5584501188616991232")
addappid(736572,0,"f2162ca0c47b0ba12b171bedf77abaf413d81b2870615dc914485c7e1816265d")
setManifestid(736572,"6204077609488731720")
addappid(736573,0,"41416f65545eca70aa5643e74dbc9a1456c424f071db9b41016ac24530bb137e")
setManifestid(736573,"4464878210044623819")
addappid(736574,0,"4d221ae18d32a07c57b49cd6df264f9cd603fafe1d969d13ecfe4ea10fa2fff4")
setManifestid(736574,"2280903939158150599")
addappid(736575,0,"408c903cccea0eba197332cfc0b0bfceab7e162d43f6fc43dcf0a9b9d959f052")
setManifestid(736575,"512411419985314213")
addappid(736576,0,"8505289feb84f8ebe1259db14d5bd5d2b98284e480d9ab3bc9515dbfd0ca248b")
setManifestid(736576,"3925805087219637158")