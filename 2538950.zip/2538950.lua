-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2538950)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(229030)
setManifestid(229030,"1043465440436835055")
addappid(229031)
setManifestid(229031,"7746630274301172884")
addappid(229032)
setManifestid(229032,"3616495131483866412")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(2538951,0,"e9d6a792c180366cec3ffc2117efe7cd2d2fd103da38935fe9abeb6f9a2d04f4")