-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1231870)
addappid(1231871,0,"01edd634cf58401eec776e2042867262508a9ef8f33a7d09008f8a5123905b85")
setManifestid(1231871,"5714452255988631208")
addappid(1231872,0,"2c079c0606dbdcfcf9872603b434581a349385cebcd83246f8b8c0bd1c3045fb")
setManifestid(1231872,"6716200109219411654")