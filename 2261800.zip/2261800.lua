-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2261800)
addappid(2261801,0,"817f71b2ca36bd9d692794ac0f5aa5e9894e2a136cee4129c5ba67bcad932b7c")
setManifestid(2261801,"365158480203414205")
addappid(2261802,0,"ecf4dc06839afa302c677efed0ee4780ecd497a23af601240e1e9ab29741789f")
setManifestid(2261802,"5895513102273489919")