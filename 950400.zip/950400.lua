-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(950400)
addappid(950401,0,"abebdee05d57d7bff538be01db0c472222c5fd3e214a1532fc137f25f3d20da8")
setManifestid(950401,"7484443896825327840")
addappid(950402)