-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3027410)
addappid(3027411,0,"a72fe258aadf91d0619b2ddbea7045530d72158b95dc6ae3b7d76181adce0d1a")
setManifestid(3027411,"6615766725977959265")
addappid(3027412)
addappid(3027413,0,"68230f3bc1e4e34beba11beca2ae968d0e52feda4e2ca8de039902e60d88a4b5")
setManifestid(3027413,"7900635399219854282")