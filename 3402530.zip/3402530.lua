-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3402530)
addappid(3402531,0,"cd8a012bb6725a1443e905eb3686ed79accef272dddea835bdf0ca5fd9564d46")
setManifestid(3402531,"1371464567620138649")