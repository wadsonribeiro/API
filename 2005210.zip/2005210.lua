-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2005210)
addappid(2005211,0,"4956919eb84cc06a63abccaf682d62d1df63f29a6d7061344d154e3a30734e8e")
setManifestid(2005211,"4022719263836417648")
addappid(2005212,0,"119505e7a870cfc6e59188d6b94e2060415f6eb0e76204a89a745d25d03fc0aa")
setManifestid(2005212,"3177181415209558784")
addappid(2005213,0,"e47ccd99aca8d58372e7f3497594803d7079e0fd1d85ff28a7d5d4d5cb5fd7e3")
setManifestid(2005213,"1955236587603489988")