-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2312700)
addappid(2312701,0,"1bdf757c91d8c5629bcb19059ae7af8089dc6411ffc79c9cae9619b61be1ef66")
setManifestid(2312701,"5795430314442724099")