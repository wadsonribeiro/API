-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(302710)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(302711,0,"6bfc23663c95cb76be822f390402673c479ec96572aea3c5feff75e7894bf64e")
setManifestid(302711,"8155472579115704172")
addappid(302712,0,"3a3f3687ddd5a769a007fc1532e6a5f51866522b9b72551bda684028c563def4")
setManifestid(302712,"7144720777667403256")
addappid(302713,0,"87b81d62b5884c6f1230e2935866f67717784e879392a9b078515d4648f9e68b")
setManifestid(302713,"6373553222880318782")
addappid(302714,0,"19966858096a369057d12d8ad69fe0ac227ce1e6cef58781b37cdc573d42d671")
setManifestid(302714,"4145326063380582481")
addappid(2934580)