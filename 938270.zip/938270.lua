-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(938270)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(938271,0,"d842cf8cbd498b8fd2784779812e4e8b714a787b9a4efbf76b602bb7349edd0a")
setManifestid(938271,"6398803020542649847")
addappid(938272,0,"7a3f9d14f4903f51dc02e6c8ca13fbd7a0926e61ec2328a8adea54a6526c9ec0")
setManifestid(938272,"9019589292722672136")
addappid(1044160,0,"8c20455375316ba95ebb770d22cc52f274a4e96c55a3a699bbad0b732852225b")
setManifestid(1044160,"3114289249862022915")