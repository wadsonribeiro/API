-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2571010)
addappid(2571011,0,"be93dd3036875358bb371ba972c67da0e9170cb760181b6accecff420db1967f")
setManifestid(2571011,"4817597236985718183")