-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(644100)
addtoken(644100,2852916862926743522)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(229010)
setManifestid(229010,"3476809898398882586")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(229030)
setManifestid(229030,"1043465440436835055")
addappid(644101,0,"afcf6eb723f3f92158802b7ab7819a9f827119a850605604d97d284595280eb2")
setManifestid(644101,"1738179474679283620")