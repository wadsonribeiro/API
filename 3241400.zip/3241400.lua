-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3241400)
addappid(3241401,0,"4c7d7ea56be7802e225ecf9099121d71f3ad4dacd53e0b7ee1a7396650c3b1be")
setManifestid(3241401,"1866518618960072269")
addappid(3241402,0,"550f68fbed33983c1490feeebb6dc968e50270a6105a5c18d76fcb6e8ad101ee")
setManifestid(3241402,"840124105332328680")