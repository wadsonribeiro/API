-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(337420)
addappid(337421,0,"6292563e8b59777c2c0f0406019d209a585f39249d0bf7793d2b5676d514c0fd")
setManifestid(337421,"6880000810224348320")