-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(674960)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(674961,0,"679c50e2f2b687a5ec7067a5fc4ab45cb18606507e3aad610209163066ed2b8f")
setManifestid(674961,"112046724350610192")