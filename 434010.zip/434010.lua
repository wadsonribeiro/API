-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(434010)
addtoken(434010,3437684509419374810)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(434011,0,"bd1fa78bdeed76186b75ffa00259b2c67ef336286962e4fcda887efce8a8df29")
setManifestid(434011,"2890865111160819098")
addappid(434012,0,"ae1e4c0598c62204e697aa1539b14455be93282a777e81ce9a6c5b1ccc9da8b0")
setManifestid(434012,"1572207047994159610")