-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1648130)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(1648131,0,"0fdc09b16cfc6a5667743018c431a16b3b0ddf28e131df9f8471480f0af7f0a3")