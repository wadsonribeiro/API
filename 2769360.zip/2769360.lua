-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2769360)
addappid(2769361,0,"b576fb3ad38c2c7a3fba4c768f4132a7147ca3dd81f4c27d6a7df431efd7ddc8")
setManifestid(2769361,"2746019434849072642")
addappid(2769362,0,"d5b953fc6f7440743e12c1a4efbaf40166e1b076b842051c47f59b844ec62102")
setManifestid(2769362,"437305518607271134")