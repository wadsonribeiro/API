-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1272130)
addappid(1272131,0,"2ed2a89e4618bdd90bc8db46ac78e8877ea7edc5a33f962972668483bd8e3eb1")
setManifestid(1272131,"727038266896963793")
addappid(1272132,0,"fd19f83a2dcfc7482998dd0dfb2a3b69f4c8ccd842732326b481dc22a3c37e22")
setManifestid(1272132,"763578527147237916")