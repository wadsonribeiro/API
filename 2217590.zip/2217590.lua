-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2217590)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2217591,0,"fe36c3a6c1aaea7073d536732d6253565dd7741f167925033e19479df26c39cb")
setManifestid(2217591,"2162307012142065915")
addappid(2218390)
addappid(2233910)