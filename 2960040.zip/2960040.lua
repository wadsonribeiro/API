-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2960040)
addappid(2960041,0,"bdb98dbd1a34b69d8da2c36a9c5dd2554f25e60b158fda14f2a8bb8b14b755a8")
setManifestid(2960041,"8936796379005808529")