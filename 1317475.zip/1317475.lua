-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1317475)
addappid(1317475,0,"6c43d701dacf5240cae23fcd648a217c985d7f8f9054a90cf6997e9fc42aaa2a")
setManifestid(1317475,"8236867965520876510")
addappid(1317750,0,"9f8be666e918b5de361a6df0489f2e1853b05d65dd90ca964e12971b16927d44")
setManifestid(1317750,"9047385496120153291")
addappid(1317751,0,"7861cca36120b3c1303fad3d4d63f8a6bdcd772d424654e5dc62f827f3276f9a")
setManifestid(1317751,"4947352207769732549")
addappid(1317752,0,"fbffc861604b7ef224e6726f7097e70eac258210afa1d12b059b83d6eebf1839")
setManifestid(1317752,"2284545779884326289")
addappid(1317753,0,"0da812e38297ad4f9f67fb84b20d819b4aea3b254b52cad5e7054ae4b327c99b")
setManifestid(1317753,"6061759286501187811")
addappid(1317754,0,"8fdb56f35bf0839fea7fbc4bf49dd653af318be22fc8607ed6ad63b85032bc01")
setManifestid(1317754,"3939993380730863573")
addappid(1317755)
addappid(1317756)