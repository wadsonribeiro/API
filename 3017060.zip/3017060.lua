-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3017060)
addappid(3017061,0,"4688b220643cfffca45e495c2c16dede0488b0508c0ba96b9ba7614232544642")
setManifestid(3017061,"6074548110668334224")
addappid(3017062,0,"1d6e7594c3d27704149659df9f72fa6fcc7e460bb3d6b029854ad4dfd794bf17")
setManifestid(3017062,"9169382396231502078")