-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1099220)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1099221,0,"d78c1a5cb7820e28c04db7842ab82a5373fc61faf4de155a9e25a92f6d9b9f73")
setManifestid(1099221,"1398845502532200251")
addappid(1790910)