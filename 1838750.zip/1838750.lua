-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1838750)
addappid(1838751,0,"802c21518c05f219fe8cce3eff43d09ad71dc681f1e6941ae81ef4124682db07")
setManifestid(1838751,"2172216940969835123")
addappid(1838752,0,"723a2afe9f3d1c328df82a5ecc6d93a197a149f9063a425f718b9b0d5c9f8007")
setManifestid(1838752,"2498280722974097752")