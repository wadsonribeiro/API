-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1860960)
addappid(1860961,0,"e410dce151afddd7ffc912ea169b5e8a85f09ef47334e29c0dfe20a434160b50")
setManifestid(1860961,"5547876161403228026")