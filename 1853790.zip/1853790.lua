-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1853790)
addtoken(1853790,10612638653507213474)
addappid(1853791,0,"d3783fd9f22f9850863f4fcbec006a7ea01478ff3bda0e5faa3dd53fbfa90aee")
setManifestid(1853791,"7749893914386199282")