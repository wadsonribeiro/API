-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(207420)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(207422,0,"dd9057ddd6f34b763f82d6a7d92dc808ff91f18d9333e318d1bc113e0fb02043")
setManifestid(207422,"7943840251094107202")
addappid(207421,0,"fbdaf8e8360f4ac0ed85daf4bf57a502a62cadf5baf266adb7ff7938d1f7ed08")
setManifestid(207421,"8740811049748125664")
addappid(207423,0,"06222500fd2ef54c28b1d465d5ff70d751ab108565200578cbc547e51237b912")
setManifestid(207423,"8356219314951875569")