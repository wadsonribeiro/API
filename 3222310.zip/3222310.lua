-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3222310)
addappid(3222311,0,"d3cdb83191974bed2ae559d3157be6a62ff5307c5c3249d6df93b3af404f6ca4")
setManifestid(3222311,"4407258622921268276")
addappid(3222312,0,"ba197d4ad5002f6cf3373f4f97de37ef8004100bc576211d69caef4f17ebb59c")
setManifestid(3222312,"5344839402277350314")