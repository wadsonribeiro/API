-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2166290)
addtoken(2166290,15762994733699234385)
addappid(2166291,0,"d727ea227d6f5ef143e976fb86a02871452db9ff4336c071dfc1d1feb91a7571")
setManifestid(2166291,"1070722859856091647")