-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(585650)
addappid(585651,0,"4352976c76ad0ab6ec74683b26707eba7fd3d47e0875b644c113e685a6667d73")
setManifestid(585651,"7897184990859613067")
addappid(585652,0,"fa1919e9d8df478853d172d9197418c7c0651ce2adce0098a55e7aaa3685a69f")
setManifestid(585652,"6517259040131349395")