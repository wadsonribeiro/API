-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1940630)
addappid(1940631,0,"3ecc0aacb590f100dbecda8c511fc6c744658ee7c4b5d98ef07002f30cbed5ef")
setManifestid(1940631,"12812892322120458")
addappid(1940632,0,"116fd054946d0ed59f7345e73070b9102295892c848963d0777ff89397ee28d3")
setManifestid(1940632,"1136179739118025147")