-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3141670)
addappid(3141671,0,"594b438b5dcdba0c1dc833577d71e1c4f6ab1188cd6f9728e7d18b8aea365931")
setManifestid(3141671,"3569716362861333172")