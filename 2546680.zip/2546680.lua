-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2546680)
addappid(2546681,0,"9abd3c448fc8cfcc576a9c6daa55ab76f308d237e1cb696fb142b23938e93d27")
setManifestid(2546681,"3903623574732827005")