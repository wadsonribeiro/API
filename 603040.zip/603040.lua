-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(603040)
addtoken(603040,18158259113034822671)
addappid(603041,0,"1d947537a33d9cacf83885acc46dca1a317f264d6e84bfda4f120f28d90a6568")
setManifestid(603041,"8310300076071828786")