-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(227080)
addappid(227081,0,"ced0677b1c84f086354aebf2f8497e407af79f3fbe5d1a4476dea594d1139123")
setManifestid(227081,"7139592645588388774")
addappid(227090,0,"fd2a1daa0bbbe41a3cfc3f1a20fda388520ce47f68b16d941021c98d9b68258c")
setManifestid(227090,"3141948737585082973")
addappid(227082,0,"b0fc69533cc3128fb816a2c16401e16a21f9e97ce29b9420ecf0753c03f965cc")
setManifestid(227082,"7731499500327966311")
addappid(227083,0,"070409aecccb116da5c843acd926ab4e62e57d626298cda4a4a3543bd27b5450")
setManifestid(227083,"8422153802559784554")