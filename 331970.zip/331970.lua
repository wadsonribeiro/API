-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(331970)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(331971,0,"ee322aebf25c8bd834f2cd02d5ac9a84692122a11f366d1d6167fc1ac12bd77b")
setManifestid(331971,"7119509180075089374")
addappid(331972,0,"e306e604adbbb4b1cc3007f9b767852e94003addcae1bcd77102275c9d757517")
setManifestid(331972,"2498443194028163023")
addappid(331973,0,"2efac0444c269bf602cf1a7c3de70d3c33f0c73aaa7f7a9b1384b016c26ab917")
setManifestid(331973,"1440061358028503735")
addappid(331974,0,"203400d240809d849c5e51d1f84f3cd3d3d6774dbe55027f948b5adb3da82b80")
setManifestid(331974,"7095444086847419066")
addappid(331975,0,"7ee505f085f5394e46fd210d976d95d29aa55c7eeedecd9a8d72fb3575251126")
setManifestid(331975,"8123471003466096027")
addappid(331976,0,"1637a7593fcb0d42bfa68d4d3b30d5f4cc99b34ff9c51bb92a3aaacc4769f7eb")
setManifestid(331976,"6444753388546674731")