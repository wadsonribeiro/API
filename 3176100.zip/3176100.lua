-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3176100)
addappid(3176101,0,"882854fdec1e77c9c6adb2dd758891428934bea0f45376fe9d5bba778a9a0f7a")
setManifestid(3176101,"5881777556373620761")