-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1531270)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1531271,0,"081a71d7469f33af861d8b3aef9fb785b14f2f5b01ed90b2c8466f8b2e6e83f5")
setManifestid(1531271,"792128087080325968")