-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(375020)
addappid(375021,0,"1c5cb3ebfe1c41ddf73f64fb763d977fbec90df860afbc134126335471a0ca5b")
setManifestid(375021,"3390487218188224799")