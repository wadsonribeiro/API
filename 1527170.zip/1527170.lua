-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1527170)
addtoken(1527170,11231009738772675546)
addappid(1527171,0,"e80af75d1ed9903b80171db01d711f3f690d359d66fc53c3c61ed95493124663")
setManifestid(1527171,"7123827762730184921")
addappid(1528790)
addappid(1528791)