-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1661120)
addappid(1661121,0,"45dc325ffb241f270bc241eb326483cf3c532759fbca714231c58f70a866ae44")
setManifestid(1661121,"7195472581351413990")
addappid(1661122,0,"32059e723b9954006a9958f78d30241e1023f1322dff1f252dd3cf694b3d2287")
setManifestid(1661122,"2698224790159635306")