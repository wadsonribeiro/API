-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(699290)
addappid(699290,0,"7ce26d4ec4eb684f2e96f67fbe0da9f39b26cba4f8ca8d75636a43131bd9c34d")
setManifestid(699290,"9184690162311472330")
addappid(699291,0,"c69bd36118782f8151e6611b5c4b994e4c922093e34f2c01820e20f43a41cbdb")
setManifestid(699291,"6388892838416515633")