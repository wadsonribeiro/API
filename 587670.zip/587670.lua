-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(587670)
addappid(587671,0,"dbc53249930ba56741caf2d6a541841aeed150695317fbd1cc1e17df7b683f55")
setManifestid(587671,"8918164897592238053")
addappid(587672,0,"b4e08e958f6a6f97e8a7f5199936f0e38124d98178e51f19017ce06d984df41c")
setManifestid(587672,"9205955557771668507")
addappid(587673,0,"17e4fc27a31fb0edece99d7868db230c4d0e69a631246ac586de1777f9ced46b")
setManifestid(587673,"3594989039236155639")