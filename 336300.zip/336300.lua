-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(336300)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(336301,0,"8881858abe952c7a0e534f6d41869c123efb106bd1aa8ad978b5e48e6c617073")
setManifestid(336301,"8379453782550595736")
addappid(336302,0,"d1d8bde71fd3853c72c8d880911fe30220335c5875c422592c3bd3018753915e")
setManifestid(336302,"120716895196421741")
addappid(336303,0,"98f5c962f46b91c3cdd7f7d36f1244cdcad89eb6c9e9041217cbc4a710809bb1")
setManifestid(336303,"7731619137432011290")