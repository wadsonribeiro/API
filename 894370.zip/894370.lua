-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(894370)
addtoken(894370,11254177630639793515)
addappid(894371,0,"449f840133a74d8f7a1c7f63ecaf927716ce265caf862cb9ea54d3c4f94e3cd3")
setManifestid(894371,"3002018701783046736")