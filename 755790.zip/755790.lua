-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(755790)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(755791,0,"bc4906600d31988cd434d2673a231a2f915a8ff93a0247b4afbdec016979e5f8")
setManifestid(755791,"2693114935208016560")
addappid(938460)