-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2087700)
addappid(2087701,0,"d408a43bba1587c3c6af325d8e0ed27faafc33314db2dc7413b0214becd2e07d")
setManifestid(2087701,"5235336986932845760")
addappid(2087702,0,"d98be0ba6874f92ea2952d386c75bee457af51c9168cce34c08023077ea096cf")
setManifestid(2087702,"6758644122566898493")
addappid(2087703,0,"b1ecf91716a43d9cecbf52af0781c02dcfefc49bf6b2e4ad8deb51f3be2dd31f")
setManifestid(2087703,"713431132452237818")
addappid(2087704,0,"f84ad90508a76c9114c56ea559bfa55493cbc408f7069e0b7c876527bb3b0a68")
setManifestid(2087704,"4120587834554980274")
addappid(2087705,0,"e23bf59bc15c5d4b89a106ad259aaa87fd4e02d84b32474050392a2f2754c958")
setManifestid(2087705,"8993013023398728583")
addappid(2087706,0,"774338b60e44403b7440e5d58aa6643df520fa2167bd7c74c6864cb52cd384f6")
setManifestid(2087706,"4950309998891321099")