-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(584210)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(584211,0,"b147673499f505ee11747b2dcec7492fdab7c8e59c035a10cffb319cce8ab607")
setManifestid(584211,"8374794597897922450")