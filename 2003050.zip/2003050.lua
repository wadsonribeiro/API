-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2003050)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2003051,0,"8f2b8deb4126a734260ce7a467645c0bca05d2c8cbc87fd207faf63687084ee1")
setManifestid(2003051,"8452948786879214510")