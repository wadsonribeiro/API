-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(823130)
addappid(823131, 1, "7e190008c73c1ad83bd9b89becea2318a43d57e0a849b355377323220e91e791")
setManifestid(823131, "2460657781159960472", 0)