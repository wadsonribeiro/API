-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2516520)
addappid(2516521,0,"737212b4589b6321b9ac780124824d239fd71aa8c10c4e45637035bdbd6947b0")
setManifestid(2516521,"3223595313946254277")