-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(375230)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(375231,0,"6e47925cc8e4eef9313ac6f4b31f277676d99c70e470f851270bb837fcd1a3bc")
setManifestid(375231,"7489873792335166156")
addappid(377910)
addappid(377920)
addappid(377930)