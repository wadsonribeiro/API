-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2207200)
addappid(2207200,0,"d5a0f798b7aeb910399f0e998a867b98a88b6e57f1d71d1de6136d9f1e53d165")
setManifestid(2207200,"48643132519312943")
addappid(2207201,0,"6bbbeae6d61afc5d6d0420e580b6fe1cbc367846bd9c11342b3ed6f253a576bd")
setManifestid(2207201,"1690924402421527067")
addappid(2207202,0,"71f3af72c130a4778193ae19e8e2989e646256850532427968b0a037c587e0ed")
setManifestid(2207202,"2098788270913764072")