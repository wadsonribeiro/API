-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(683570)
addtoken(683570,11195244821970244535)
addappid(683571,0,"54d97a9eeb07b8338f32b8ae6d9412e4c3e752e149b21c51e0d7a57323e3c613")
setManifestid(683571,"3302712035454130686")