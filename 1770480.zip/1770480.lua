-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1770480)
addappid(1770480)
addappid(1770481,0,"da89b7918a466dc116fa3dc2ec780134e8829781ae3a8282aa0532994d34a068")
setManifestid(1770481,"4625979481897414804")